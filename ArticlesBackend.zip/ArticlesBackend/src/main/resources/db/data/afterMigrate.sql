-- ---------------------------------------------------------------
--       TRUNCATE ALL TABLES (without flyway_schema_history)
-- ---------------------------------------------------------------

DO $$
    DECLARE row RECORD;
    BEGIN
        FOR row IN SELECT table_name
                   FROM information_schema.tables
                   WHERE table_type='BASE TABLE'
                     AND table_schema='public'
                     AND table_name NOT IN ('flyway_schema_history')
            LOOP
                EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE;',row.table_name);
            END LOOP;
    END;
$$;

-- ---------------------------------------------------------------
--                    INITIAL DATABASE VALUES
-- ---------------------------------------------------------------


-- ---------------------------------------------------------------
--                            users
-- ---------------------------------------------------------------

insert into role (name)
values
    ('ADMINISTRATOR'),          -- id = 1
    ('EDITOR'),                 -- id = 2
    ('AUTHOR'),                 -- id = 3
    ('USER');                   -- id = 4

-- password for each user is 'pass'
insert into end_user (role_id, email, password, first_name, last_name)
values
    (1, 'admin@rg.com', '$2a$10$MGDWP10csyYD1K2zZzmMVOyfd76Bh3LpM3cxzdO7PjH9SJwSGuJpK', 'Jan', 'Kowalski'),                  -- id = 1
    (2, 'edytor@rg.com', '$2a$10$MGDWP10csyYD1K2zZzmMVOyfd76Bh3LpM3cxzdO7PjH9SJwSGuJpK', 'Mateusz', 'Kowalski'),             -- id = 2
    (3, 'jakub_autor@rg.com', '$2a$10$MGDWP10csyYD1K2zZzmMVOyfd76Bh3LpM3cxzdO7PjH9SJwSGuJpK', 'Jakub', 'Pies'),              -- id = 3
    (3, 'anita_autor@rg.com', '$2a$10$MGDWP10csyYD1K2zZzmMVOyfd76Bh3LpM3cxzdO7PjH9SJwSGuJpK', 'Anita', 'Lenkiewicz'),        -- id = 4
    (4, 'klient_a@rg.com', '$2a$10$MGDWP10csyYD1K2zZzmMVOyfd76Bh3LpM3cxzdO7PjH9SJwSGuJpK', 'Marcin', 'Lenkiewicz');          -- id = 5

-- ---------------------------------------------------------------
--                           articles
-- ---------------------------------------------------------------
insert into article_status(name)
values
    ('CREATED'),                -- id = 1
    ('WAITING_FOR_REVIEW'),     -- id = 2
    ('IN_REVIEW'),              -- id = 3
    ('PUBLISHED'),              -- id = 4
    ('ARCHIVED');               -- id = 5

insert into article_category(name)
values
    ('Polityka'),               -- id = 1
    ('Kultura'),                -- id = 2
    ('Sport'),                  -- id = 3
    ('Technologia'),            -- id = 4
    ('Gospodarka');             -- id = 5

insert into article_subcategory(category_id, name)
values
    (1, 'Polska'),              -- id = 1
    (1, 'Stany Zjednoczone'),   -- id = 2
    (1, 'Konflikt w Gazie'),    -- id = 3

    (2, 'Kino'),                -- id = 4
    (2, 'Sztuka'),              -- id = 5
    (2, 'Muzyka'),              -- id = 6

    (3, 'Piłka nożna'),         -- id = 7
    (3, 'Koszykówka'),          -- id = 8
    (3, 'Tenis'),               -- id = 9

    (4, 'Programowanie'),       -- id = 10
    (4, 'AI'),                  -- id = 11

    (5, 'Giełda');              -- id = 12


insert into article_tag(name)
values
    ('ZWIERZETA'),              -- id = 1
    ('KOTY'),                   -- id = 2
    ('PRZYRODA'),               -- id = 3
    ('INFORMATYKA'),            -- id = 4
    ('JAVA'),                   -- id = 5
    ('PROPGRAMOWANIE'),         -- id = 6
    ('APLIKACJE WEBOWE');       -- id = 7


insert into review_status(name)
values
    ('OPENED'),            -- id = 1
    ('REQ_CHANGES'),       -- id = 2
    ('CLOSED');            -- id = 3

-- first article
-- id = 1
insert into article (author_id, subcategory_id, title, introduction, thumbnail_url, created_timestamp)
values (3, 1, 'Artykuł o karakalach', 'W tym artykule poruszymy temat karakali', 'https://picsum.photos/id/238/800/600', to_timestamp('2021-05-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'));

insert into article_chapter (article_id, title, text, order_number)
values
    (1, null, 'Pierwszy rozdział bez nagłówka', 1),     -- id = 1
    (1, null, 'Drugi rozdział bez nagłówka', 2),        -- id = 2
    (1, null, 'Trzeci rozdział bez nagłówka', 3);       -- id = 3

insert into tags_to_articles(tag_id, article_id)
values
    (1, 1),
    (2, 1),
    (3, 1);


-- second article
-- id = 2
insert into article (article_status_id, author_id, subcategory_id, title, introduction, thumbnail_url)
values (4, 3, 2, 'Artykuł o Springu', 'W tym artykule poruszymy temat frameworka Spring Boot', 'https://picsum.photos/id/239/800/600');

insert into article_chapter (article_id, title, text, order_number)
values
    (2, 'Czym jest Spring Boot?', 'Spring to framework dla języka Java', 1),     -- id = 4
    (2, 'Do czego używa się Springa?', 'Spring dobrze sprawdza się ' ||
                                       'do pisania aplikacji webowych ', 2);     -- id = 5


insert into article (article_status_id, author_id, subcategory_id, title, introduction, thumbnail_url)
values (4, 3, 2, 'Lorem Ipsum', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu diam diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla tellus enim, tempus at mauris vel, ornare pharetra dui.', 'https://picsum.photos/id/240/800/600');

insert into article (article_status_id, author_id, subcategory_id, title, introduction, thumbnail_url)
values (4, 3,  1, 'Ipsum Lorem', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu diam diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla tellus enim, tempus at mauris vel, ornare pharetra dui.', 'https://picsum.photos/id/241/800/600');

insert into article (article_status_id, author_id, subcategory_id, title, introduction, thumbnail_url)
values (4, 3,  2, 'Nga vjen', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu diam diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla tellus enim, tempus at mauris vel, ornare pharetra dui.', 'https://picsum.photos/id/242/800/600');

insert into article (article_status_id, author_id, subcategory_id, title, introduction, thumbnail_url)
values (4, 3,  3, 'Czym jest Lorem Ipsum?', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu diam diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla tellus enim, tempus at mauris vel, ornare pharetra dui.', 'https://picsum.photos/id/243/800/600');


insert into tags_to_articles(article_id, tag_id)
values
    (2, 4),
    (2, 5),
    (2, 6),
    (2, 7);
