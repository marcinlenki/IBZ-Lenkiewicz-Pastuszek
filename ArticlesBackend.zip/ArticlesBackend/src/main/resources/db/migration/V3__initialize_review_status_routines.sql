create or replace function get_opened_review_status()
    returns review_status language sql as $$
select * from review_status where name = 'OPENED';
$$;

create or replace function get_requires_changes_review_status()
    returns review_status language sql as $$
select * from review_status where name = 'REQ_CHANGES';
$$;

create or replace function get_closed_review_status()
    returns review_status language sql as $$
select * from review_status where name = 'CLOSED';
$$;

create or replace function get_default_review_status()
    returns int language sql as $$
select id from get_opened_review_status();
$$;

alter table article_review
    alter column review_status_id set default get_default_review_status();

