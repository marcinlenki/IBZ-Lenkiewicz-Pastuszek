drop index if exists article_review_editor_id_uindex;

create index if not exists article_review_editor_id_index
    on article_review (editor_id);
