create or replace function get_default_article_status() returns integer
    language sql
as
$$
select id from article_status where name = 'CREATED';
$$;

create or replace function get_waiting_for_review_article_status() returns article_status
    language sql
as
$$
select * from article_status where name = 'WAITING_FOR_REVIEW';
$$;

create or replace function get_in_review_article_status() returns article_status
    language sql
as
$$
select * from article_status where name = 'IN_REVIEW';
$$;


create or replace function get_published_article_status() returns article_status
    language sql
as
$$
select * from article_status where name = 'PUBLISHED';
$$;

alter table article
    alter column article_status_id set default get_default_article_status();


