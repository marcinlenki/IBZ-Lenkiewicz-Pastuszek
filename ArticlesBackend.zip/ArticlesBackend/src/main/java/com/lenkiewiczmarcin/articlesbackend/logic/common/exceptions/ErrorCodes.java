package com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions;

public final class ErrorCodes {

    private ErrorCodes() {}

    public static final String MISSING_ATTACHMENT_EXCEPTION = "1a378b89-6a97-4e97-a3e2-3630161559fc";
    public static final String RESOURCE_UPLOAD_EXCEPTION = "6dc410ee-48a1-4255-a2f3-42474ebf6c35";
    public static final String RESOURCE_NOT_FOUND_EXCEPTION = "cc93a505-61c9-49b0-8b10-c9019ffa15de";
    public static final String ARTICLE_VALIDATION_EXCEPTION = "f58230df-9006-423d-9314-45f146db8860";
    public static final String INVALID_JWT_EXCEPTION = "2136b6ff-f03a-4cda-b8dd-6d51eac303d8";
    public static final String BAD_AUTH_EXCEPTION = "e69cfcc9-5171-404b-b5c2-98b6deb56375";
    public static final String UNAUTHORIZED_EXCEPTION = "aab521af-d68f-484f-95d9-e2054ac4efa3";
}
