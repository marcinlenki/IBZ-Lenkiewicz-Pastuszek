package com.lenkiewiczmarcin.articlesbackend.security;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public interface UserInfoService {
    Optional<User> getCurrentUser();
    boolean isAdmin();
}
