package com.lenkiewiczmarcin.articlesbackend.data.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.Chapter;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.Chapter_;
import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ArticleReview;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.utils.CollectionUtils;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;

import java.time.LocalDateTime;
import java.util.Set;

@Table(name = "article")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
@DynamicInsert  // try to use default database values if column is null
public class Article implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String title;
    private String introduction;
    private String thumbnailUrl;
    private Boolean parentalAdvisory;
    private LocalDateTime createdTimestamp;
    private Integer numberOfViews;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id")
    @ToString.Exclude
    private User author;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subcategory_id")
    @ToString.Exclude
    private Subcategory subcategory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "article_status_id")
    @ToString.Exclude
    private ArticleStatus status;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "review_id")
    @ToString.Exclude
    private ArticleReview review;

    // DATABASE RELATIONSHIPS
    @OneToMany(mappedBy = Chapter_.ARTICLE, cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy(Chapter_.ORDER_NUMBER)
    @ToString.Exclude
    private Set<Chapter> chapters;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "tags_to_articles",
            joinColumns = @JoinColumn(name = "article_id"),
            inverseJoinColumns = @JoinColumn(name = "tag_id")
    )
    @ToString.Exclude
    private Set<Tag> tags;
    
    public Set<Chapter> getChapters() {
        return CollectionUtils.getSet(chapters);
    }
    
    public void setChapters(Set<Chapter> chapters) {
        if (chapters != null && this.chapters != null) {
            prepareChapters(chapters);
            addChapters(chapters);
        } else if (chapters != null) {
            prepareChapters(chapters);
            this.chapters = chapters;
        } else if (this.chapters != null) {
            this.chapters.clear();
        }
    }
    
    private void prepareChapters(Set<Chapter> chapters) {
        int orderNum = 1;
        for (var chapter : chapters) {
            chapter.setOrderNumber(orderNum++);
            chapter.setArticle(this);
        }
    }
    
    private void addChapters(Set<Chapter> chapters) {
        this.chapters.clear();
        this.chapters.addAll(chapters);
    }

    public Set<Tag> getTags() {
        return CollectionUtils.getSet(tags);
    }
    public void setTags(Set<Tag> tags) {
        if (tags != null && this.tags != null) {
            this.tags.clear();
            this.tags.addAll(tags);
        } else if (tags != null) {
            this.tags = tags;
        } else if (this.tags != null) {
            this.tags.clear();
        }
    }

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return true;
    }

    @Override
    public String getNaturalIdentifier() {
        return title;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByNaturalKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeByNaturalId(this);
    }

}
