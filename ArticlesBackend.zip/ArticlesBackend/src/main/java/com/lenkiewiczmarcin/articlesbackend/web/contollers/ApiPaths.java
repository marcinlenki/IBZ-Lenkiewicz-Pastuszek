package com.lenkiewiczmarcin.articlesbackend.web.contollers;

public final class ApiPaths {
    private ApiPaths() {}
    public static final String ARTICLES = "articles";
    public static final String CATEGORIES = "categories";
    public static final String TAGS = "tags";
    public static final String AUTH = "auth";
    public static final String HEALTHCHECK = "healthcheck";
}
