package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.out.ArticleResponse;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.ArticleService;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.definition.ArticleController;
import com.lenkiewiczmarcin.articlesbackend.web.specifications.ArticleSearchSpecification;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ArticleControllerImpl implements ArticleController {
    private final ArticleService articleService;

    @Override
    public ResponsePage<ArticleResponse> getArticles(ArticleSearchSpecification specification, Pageable pageable) {
        return articleService.getArticles(specification, pageable);
    }

    @Override
    public ArticleResponse getArticle(int articleId) {
        return articleService.getArticle(articleId);
    }

    @Override
    public ArticleResponse createArticle(
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        return articleService.createArticle(
                articleChangeRequest,
                files,
                allowResourceUploadFailure
        );
    }

    @Override
    public ArticleResponse editArticle(
            int articleId,
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        return articleService.editArticle(
                articleId,
                articleChangeRequest,
                files,
                allowResourceUploadFailure
        );
    }

    @Override
    public ArticleResponse submitArticle(
            int articleId,
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        return articleService.submitArticleForReview(
                articleId,
                articleChangeRequest,
                files,
                allowResourceUploadFailure
        );
    }

    @Override
    public ArticleResponse pickArticleForReview(int articleId) {
        return articleService.pickArticleForReview(articleId);
    }

    @Override
    public ArticleResponse publishArticle(
            int articleId,
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        return articleService.publishArticle(
                articleId,
                articleChangeRequest,
                files,
                allowResourceUploadFailure
        );
    }

    @Override
    public ArticleResponse rollbackArticle(int articleId) {
        // not implemented
        throw new UnsupportedOperationException("Not implemented");
    }

    @Override
    public void deleteArticle(int articleId) {
        articleService.deleteArticle(articleId);
    }

}
