package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ArticleReview;

public interface ArticleReviewRepository extends DataRepository<ArticleReview> {
}
