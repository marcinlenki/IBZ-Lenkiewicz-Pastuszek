package com.lenkiewiczmarcin.articlesbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticlesBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArticlesBackendApplication.class, args);
    }

}
