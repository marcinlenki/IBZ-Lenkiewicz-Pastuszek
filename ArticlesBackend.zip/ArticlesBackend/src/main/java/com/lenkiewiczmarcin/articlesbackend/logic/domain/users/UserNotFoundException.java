package com.lenkiewiczmarcin.articlesbackend.logic.domain.users;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User_;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;

public class UserNotFoundException extends ResourceNotFoundException {
    private static final String USER = "user";

    public UserNotFoundException(String email) {
        super(USER, User_.EMAIL, email);
    }
}
