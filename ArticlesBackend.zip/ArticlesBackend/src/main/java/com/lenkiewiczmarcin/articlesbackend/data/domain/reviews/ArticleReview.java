package com.lenkiewiczmarcin.articlesbackend.data.domain.reviews;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;

import java.time.LocalDateTime;

@Table(name = "article_review")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
@DynamicInsert  // try to use default database values if column is null
public class ArticleReview implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private LocalDateTime openedTimestamp;
    private LocalDateTime closedTimestamp;
    private LocalDateTime lastModifiedTimestamp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "editor_id")
    @ToString.Exclude
    private User editor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "review_status_id")
    @ToString.Exclude
    private ReviewStatus reviewStatus;

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return false;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByPrimaryKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcode(this);
    }

}