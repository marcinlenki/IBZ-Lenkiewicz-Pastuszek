package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources;

import lombok.extern.slf4j.Slf4j;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.mime.MimeTypeException;
import org.apache.tika.mime.MimeTypes;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
public final class MultipartFileUtils {
    private MultipartFileUtils() {}

    private static final TikaConfig tikaConfig = TikaConfig.getDefaultConfig();
    private static final MimeTypes mimeTypes = tikaConfig.getMimeRepository();

    // return file extension (without the dot)
    public static String getOriginalExtension(MultipartFile resourceFile) {
        var extBasedOnMimeType = getExtensionBasedOnMimeType(resourceFile);
        return extBasedOnMimeType != null ? extBasedOnMimeType : getExtensionBasedOnOriginalFileExtension(resourceFile);
    }

    private static String getExtensionBasedOnMimeType(MultipartFile resourceFile) {
        var contentType = resourceFile.getContentType();
        if (contentType == null) {
            return null;
        }
        try {
            var mimeType = mimeTypes.forName(contentType);
            return mimeType.getExtension().substring(1);
        } catch (MimeTypeException e) {
            handleMimeTypeException(resourceFile, e);
            return null;
        }
    }

    private static String getExtensionBasedOnOriginalFileExtension(MultipartFile resourceFile) {
        var originalFilename = resourceFile.getOriginalFilename();
        if (originalFilename == null) {
            return null;
        }
        int lastDotIndex = originalFilename.lastIndexOf(".");
        if (lastDotIndex < 0) {
            return null;
        }
        return originalFilename.substring(lastDotIndex + 1);
    }

    private static void handleMimeTypeException(MultipartFile resourceFile, MimeTypeException e) {
        var errorMessage = "Error while processing temporary file [" + resourceFile.getOriginalFilename() + "]" +
                ", unknown mime type";
        log.error(errorMessage, e);
    }
}
