package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.data.dto.HealthcheckResponse;
import com.lenkiewiczmarcin.articlesbackend.utils.Time;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.definition.HealthcheckController;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckControllerImpl implements HealthcheckController {
    @Override
    public HealthcheckResponse healthcheck() {
        return new HealthcheckResponse("Service is up and running", Time.currentTime());
    }
}
