package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct;

import com.lenkiewiczmarcin.articlesbackend.config.EntityMapperConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.out.ArticleResponse;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.annotations.ArticleChangeRequestMapping;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.annotations.ArticleResponseMapping;
import jakarta.transaction.Transactional;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;

//FIXME: Some mapping methods are not getting resolved correctly so you need to inject them and manually tell mapstruct
// to use them with @Mapping annotation, eg. @Mapping(target = "subcategory", expression = "java(...)").
// For now using custom annotations to make the code cleaner.

@Mapper(
        config = EntityMapperConfig.class,
        uses = {TagMapper.class, CategoryMapper.class, UserMapper.class, ChapterResourceMapper.class}
)
@Transactional
public abstract class ArticleMapper {
    protected TagMapper tagMapper;
    protected CategoryMapper categoryMapper;

    @Autowired
    public void setCategoryMapper(CategoryMapper categoryMapper) {
        this.categoryMapper = categoryMapper;
    }

    @Autowired
    public void setTagMapper(TagMapper tagMapper) {
        this.tagMapper = tagMapper;
    }

    // MAPPING METHODS

    // dto to article
    @ArticleChangeRequestMapping
    public abstract void updateArticleFromArticleChangeRequest(ArticleChangeRequest articleChangeRequest,
                                                               @MappingTarget Article article);

    // article to dto
    @ArticleResponseMapping
    public abstract ArticleResponse convertArticleToArticleResponse(Article article);

}