package com.lenkiewiczmarcin.articlesbackend.data.dto.categories.in;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;

public record ArticleCategoryChangeRequest(
        int categoryId,
        int subcategoryId,
        String name
) {
    @JsonIgnore
    @SuppressWarnings("unused") // used during validation
    @AssertTrue(message = "Category change request is invalid, it must either contain valid subcategory id or " +
            "valid category id and name")
    public boolean isValid() {
        return subcategoryId > 0 || (categoryId > 0 && !name.isBlank() && name.length() <= 32);
    }
}
