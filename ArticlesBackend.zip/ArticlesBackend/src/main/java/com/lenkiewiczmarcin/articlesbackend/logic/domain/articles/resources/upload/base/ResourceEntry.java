package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import java.net.URL;

/**
 * Represents a temporary resource waiting for upload to a remote server.
 */
public interface ResourceEntry {
    /**
     * Returns a valid upload URL which should be used to upload this resource.
     * @return valid upload URL
     */
    URL getUploadUrl();
    String getOriginalFilename();
    String getTemporaryFilename();
}
