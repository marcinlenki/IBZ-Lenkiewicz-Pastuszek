package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Fetch database entities by their natural ids. For now supports one natural id per entity.
 */
@Repository
@RequiredArgsConstructor
public class BusinessKeyRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public <E extends DatabaseEntity, N> Optional<E> findByNaturalId(@NonNull N naturalId, @NonNull Class<E> entityType) {
        return entityManager
                .unwrap(Session.class)
                .bySimpleNaturalId(entityType)
                .setSynchronizationEnabled(false)
                .loadOptional(naturalId);
    }

    @Transactional
    public <E extends DatabaseEntity, N> Set<E> findAllByNaturalIds(@NonNull Set<N> naturalIds, @NonNull Class<E> entityType) {
        return naturalIds
                .stream()
                .map(naturalId -> findByNaturalId(naturalId, entityType))
                .flatMap(Optional::stream)
                .collect(Collectors.toSet());
    }

}
