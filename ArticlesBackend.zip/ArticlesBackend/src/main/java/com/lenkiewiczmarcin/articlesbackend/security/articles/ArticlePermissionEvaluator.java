package com.lenkiewiczmarcin.articlesbackend.security.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.SimpleUserDetails;
import com.lenkiewiczmarcin.articlesbackend.security.PermissionEvaluator;
import com.lenkiewiczmarcin.articlesbackend.security.SystemRoles;

public abstract class ArticlePermissionEvaluator implements PermissionEvaluator<Article> {
    protected boolean isArticleAuthor(User user, Article article) {
        return article.getAuthor().equals(user);
    }

    protected boolean isArticleEditor(User user, Article article) {
        var review = article.getReview();
        return review != null && review.getEditor().equals(user);
    }

    protected boolean hasPermissionOnStatus(Article article, ArticleStatusProcessor<Boolean> articleStatusProcessor) {
        return articleStatusProcessor.process(article);
    }

    protected boolean isEmployee(SimpleUserDetails userDetails) {
        return userDetails != null && !userDetails.getRoleName().equals(SystemRoles.CLIENT);
    }

}
