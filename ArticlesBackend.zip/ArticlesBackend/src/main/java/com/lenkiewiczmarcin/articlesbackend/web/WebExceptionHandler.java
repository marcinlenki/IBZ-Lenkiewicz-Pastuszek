package com.lenkiewiczmarcin.articlesbackend.web;

import com.lenkiewiczmarcin.articlesbackend.data.dto.exceptions.out.ExceptionMessage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.exceptions.out.SimpleExceptionMessage;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.FailedAuthenticationRequestException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.security.UnauthorizedException;
import com.lenkiewiczmarcin.articlesbackend.utils.Time;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class WebExceptionHandler {
    private static final String MESSAGE_TEMPLATE =
            "An exception has been intercepted by exception handler, original message: [{}].";

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BackendException.class)
    public ExceptionMessage handleApplicationExceptions(BackendException e) {
        logException(e);
        return ExceptionMessage.build(e);
    }

    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ExceptionHandler(UnauthorizedException.class)
    public ExceptionMessage handleAuthorizationExceptions(BackendException e) {
        logException(e);
        return ExceptionMessage.build(e);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BadCredentialsException.class)
    public ExceptionMessage handleAuthExceptions(BadCredentialsException e) {
        logException(e);
        return ExceptionMessage.build(new FailedAuthenticationRequestException());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public SimpleExceptionMessage handleDataValidationExceptions(MethodArgumentNotValidException e) {
        var validationErrors = e.getBindingResult().getAllErrors();
        return new SimpleExceptionMessage(validationErrors.stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toSet()),
                Time.currentTime());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ConstraintViolationException.class)
    public SimpleExceptionMessage handleClassConstraintValidationExceptions(ConstraintViolationException e) {
        logException(e);
        return new SimpleExceptionMessage(e.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.toSet()),
                Time.currentTime());
    }

    private void logException(RuntimeException e) {
        log.error(MESSAGE_TEMPLATE, e.getMessage(), e);
    }

}
