package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model;

public abstract class AbstractFileUploadResult implements FileUploadResult {
    protected final String originalFilename;

    protected AbstractFileUploadResult(String originalFilename) {
        this.originalFilename = originalFilename;
    }

    @Override
    public String uploadFilename() {
        return originalFilename;
    }
}
