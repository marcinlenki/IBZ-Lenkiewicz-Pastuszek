package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct;

import com.lenkiewiczmarcin.articlesbackend.config.EntityMapperConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Category;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Subcategory;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.in.ArticleCategoryChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.ArticleResponseCategoryDto;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.CategoryDto;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.CategoryMappingService;
import jakarta.transaction.Transactional;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(config = EntityMapperConfig.class)
public abstract class CategoryMapper {
    private CategoryMappingService mappingLogic;

    @Autowired
    public void setMappingLogic(CategoryMappingService mappingLogic) {
        this.mappingLogic = mappingLogic;
    }

    // MAPPING METHODS

    // dto to entity
    // (used in article change request mapping)
    public Subcategory convertCategoryToSubcategory(ArticleCategoryChangeRequest category) {
        return mappingLogic.getSubcategory(category);
    }

    // entity to dto
    @Transactional
    public abstract CategoryDto convertCategoryToCategoryDto(Category category);

    // helper
    // (used in article response mapping)
    public ArticleResponseCategoryDto convertSubcategoryToCategoryDto(Subcategory subcategory) {
        return mappingLogic.toCategoryDto(subcategory);
    }

}
