package com.lenkiewiczmarcin.articlesbackend.data.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.NaturalId;

@Table(name = "article_subcategory")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class Subcategory implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NaturalId
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @ToString.Exclude
    private Category category;

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return true;
    }

    @Override
    public String getNaturalIdentifier() {
        return name;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByNaturalKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeByNaturalId(this);
    }

}