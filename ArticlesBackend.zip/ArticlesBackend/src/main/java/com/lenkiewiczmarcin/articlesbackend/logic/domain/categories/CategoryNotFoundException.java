package com.lenkiewiczmarcin.articlesbackend.logic.domain.categories;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;

public class CategoryNotFoundException extends ResourceNotFoundException {
    private static final String ARTICLE_CATEGORY = "article category";

    public CategoryNotFoundException(Integer identifier) {
        super(ARTICLE_CATEGORY, identifier);
    }
}
