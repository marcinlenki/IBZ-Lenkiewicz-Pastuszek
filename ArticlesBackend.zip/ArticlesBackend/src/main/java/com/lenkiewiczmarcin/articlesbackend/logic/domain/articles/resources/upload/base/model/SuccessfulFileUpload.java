package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model;

import lombok.Getter;

@Getter
public final class SuccessfulFileUpload extends AbstractFileUploadResult {
    private final String uploadUrl;

    public SuccessfulFileUpload(String originalFilename, String uploadUrl) {
        super(originalFilename);
        this.uploadUrl = uploadUrl;
    }

    @Override
    public boolean successful() {
        return true;
    }

}
