package com.lenkiewiczmarcin.articlesbackend.security;

import java.util.*;

public final class SystemRoles {
    private SystemRoles() {}

    public static final String CLIENT = "USER";
    public static final String AUTHOR = "AUTHOR";
    public static final String EDITOR = "EDITOR";
    public static final String ADMINISTRATOR = "ADMINISTRATOR";

    // ADMINISTRATOR > (AUTHOR | EDITOR) > CLIENT
    // consider EDITOR > AUTHOR hierarchy in the future?
    public static List<String> createHierarchies() {
        var hierarchies = new LinkedList<String>();
        addHierarchy(hierarchies, ADMINISTRATOR, AUTHOR);
        addHierarchy(hierarchies, ADMINISTRATOR, EDITOR);
        addHierarchy(hierarchies, EDITOR, CLIENT);
        addHierarchy(hierarchies, AUTHOR, CLIENT);
        return hierarchies;
    }

    private static void addHierarchy(Collection<String> hierarchies, String baseRole, String inheritedRole) {
        var hierarchy = createHierarchy(baseRole, inheritedRole);
        hierarchies.add(hierarchy);
    }

    private static String createHierarchy(String baseRole, String inheritedRole) {
        return baseRole + " > " + inheritedRole;
    }

}
