package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Tag;

public interface TagRepository extends DataRepository<Tag> {
}
