package com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions;

public class WrappedException extends RuntimeException {
    public WrappedException(Throwable cause) {
        super(cause);
    }

}
