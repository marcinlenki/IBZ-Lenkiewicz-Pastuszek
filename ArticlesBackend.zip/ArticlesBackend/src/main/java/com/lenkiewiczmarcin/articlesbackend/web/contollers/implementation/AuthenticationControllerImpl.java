package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.in.AuthenticationRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.out.AuthenticationResponse;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.AuthenticationService;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.definition.AuthenticationController;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class AuthenticationControllerImpl implements AuthenticationController {
    private final AuthenticationService authService;

    @Override
    public AuthenticationResponse login(AuthenticationRequest authenticationRequest) {
        return authService.authenticate(authenticationRequest);
    }

}
