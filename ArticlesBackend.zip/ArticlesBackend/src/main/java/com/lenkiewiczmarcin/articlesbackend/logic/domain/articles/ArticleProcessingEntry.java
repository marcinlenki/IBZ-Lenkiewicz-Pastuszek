package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public record ArticleProcessingEntry(
        ArticleChangeRequest articleChangeRequest,
        List<MultipartFile> files,
        boolean allowResourceFailure
) {}
