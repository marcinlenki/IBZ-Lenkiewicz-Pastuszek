package com.lenkiewiczmarcin.articlesbackend.data.domain.reviews;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.utils.Time;

public final class ReviewFactory {
    private ReviewFactory() {}

    public static ArticleReview create(User editor) {
        return ArticleReview
                .builder()
                .editor(editor)
                .reviewStatus(null) // use default status from database
                .openedTimestamp(Time.currentTime())
                .lastModifiedTimestamp(Time.currentTime())
                .closedTimestamp(null)
                .build();
    }
}
