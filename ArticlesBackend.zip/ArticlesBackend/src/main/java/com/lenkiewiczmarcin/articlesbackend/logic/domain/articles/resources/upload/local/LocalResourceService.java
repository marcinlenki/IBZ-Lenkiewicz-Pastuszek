package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.local;

import com.lenkiewiczmarcin.articlesbackend.logic.common.Result;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.AbstractResourceService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.ResourceEntry;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.TemporaryResourceSpace;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.AbstractFileUploadResult;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.SuccessfulFileUpload;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.UnsuccessfulFileUpload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
//@Primary
public class LocalResourceService extends AbstractResourceService {

    private final Path uploadDirectory = Path.of("uploads");

    public LocalResourceService(TemporaryResourceSpace temporaryResourceSpace) {
        super(temporaryResourceSpace);
        try {
            Files.createDirectories(uploadDirectory);
        } catch (IOException e) {
            log.error("Unable to create upload directory", e);
        }
    }

    @Override
    protected int getNumberOfFileDeleteAttempts() {
        return 1;
    }

    @Override
    protected ResourceEntry createResourceEntry(MultipartFile multipartFile, File temporaryFile) {
        log.info("Creating resource entry for file {}", multipartFile.getOriginalFilename());
        return new ResourceEntry() {
            @Override
            public URL getUploadUrl() {
                try {
                    return uploadDirectory.resolve(temporaryFile.getName()).toUri().toURL();
                } catch (MalformedURLException e) {
                    log.error("error" + e.getMessage());
                    return null;
                }
            }

            @Override
            public String getOriginalFilename() {
                return multipartFile.getOriginalFilename();
            }

            @Override
            public String getTemporaryFilename() {
                return temporaryFile.getName();
            }
        };
    }

    @Override
    protected Set<AbstractFileUploadResult> uploadRemotely(Set<InternalResource> uploadResources) {
        return uploadResources
                .stream()
                .map(r -> {
                    var newFile = writeFile(r.temporaryFile()).getOrNull();
                    if (newFile != null) {
                        return new SuccessfulFileUpload(
                                r.resourceEntry().getOriginalFilename(),
                                newFile.toFile().toURI().toString());
                    } else {
                        return new UnsuccessfulFileUpload(
                                r.resourceEntry().getOriginalFilename(),
                                new RuntimeException("UPS!"));
                    }

                })
                .collect(Collectors.toSet());
    }

    @Override
    protected String removeRemotely(String url) {
        var file = getFile(url);
        Result.of(() -> Files.deleteIfExists(file.toPath())).getOrThrow();
        return file.getAbsolutePath();
    }

    @Override
    protected Set<String> removeRemotely(Set<String> urls) {
        return urls.stream().map(this::removeRemotely).collect(Collectors.toSet());
    }

    private Result<Path> writeFile(File file) {
        return Result.of(() -> {
            var target = uploadDirectory.resolve(file.getName());
            return Files.write(target, Files.readAllBytes(file.toPath()));
        }).onFailure(e -> log.error("Error in file upload", e));
    }

    private File getFile(String url) {
        return getFile(Result.of(() -> URI.create(url)));
    }

    private File getFile(Result<URI> uriResult) {
        return new File(uriResult.getOrThrow());
    }
}
