package com.lenkiewiczmarcin.articlesbackend.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class JwtConfig {
    @Value("${auth.jwt.secret}")
    private String signingKey;

    @Value("${auth.jwt.expiration-time}")
    private Integer jwtExpirationTime;

    @Value("${auth.jwt.refresh-time}")
    private Integer refreshTokenExpirationTime;
}
