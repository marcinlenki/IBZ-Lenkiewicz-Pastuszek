package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.Chapter;
import org.springframework.stereotype.Repository;

@Repository
public interface ChapterRepository extends DataRepository<Chapter> {
}
