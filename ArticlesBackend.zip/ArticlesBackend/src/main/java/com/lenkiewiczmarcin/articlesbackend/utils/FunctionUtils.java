package com.lenkiewiczmarcin.articlesbackend.utils;

import com.lenkiewiczmarcin.articlesbackend.logic.common.ExceptionalSupplier;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.WrappedException;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public final class FunctionUtils {

    private static final long WAIT_TIME_IN_MILLIS = 10;

    private FunctionUtils() {}

    public static boolean tryNTimes(int numberOfAttempts, Runnable function) {
        for (int attempt = 1; attempt <= numberOfAttempts; attempt++) {
            try {
                function.run();
                return true;
            } catch (Exception ex) {
                handleFailure(ex, attempt, numberOfAttempts);
            }
        }
        return false;
    }

    public static <T> T tryCalculateNTimes(int numberOfAttempts, ExceptionalSupplier<T> supplier) {
        for (int attempt = 1; attempt <= numberOfAttempts; attempt++) {
            try {
                return supplier.get();

            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                throw new WrappedException(ex);

            } catch (Exception ex) {
                // rethrows the exception if it was the last attempt
                handleFailure(ex, attempt, numberOfAttempts);
            }
        }

        throw new IllegalStateException("Should never happen");
    }

    private static void handleFailure(
            Exception ex,
            int attemptNumber,
            int maxNumberOfAttempts
    ) {
        if (attemptNumber == maxNumberOfAttempts) {
            throw new WrappedException(ex);
        }
        logFailedAttempt(ex, attemptNumber);
        waitInCaseOfFailure();
    }

    private static void logFailedAttempt(Exception ex, int attemptNumber) {
        log.error("An exception occurred during method execution, attempt: " + attemptNumber, ex);
    }

    private static void waitInCaseOfFailure() {
        try {
            TimeUnit.MILLISECONDS.sleep(WAIT_TIME_IN_MILLIS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new WrappedException(ex);
        }
    }

}
