package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserRepository extends DataRepository<User> {
    @Query("SELECT u FROM User u JOIN FETCH u.role WHERE u.email = (:email)")
    Optional<User> findByEmail(String email);

}
