package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom;

import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Subcategory;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.in.ArticleCategoryChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.ArticleResponseCategoryDto;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.SubcategoryDto;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.CategoryRepository;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.SubcategoryRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CategoryMappingService {
    private final CategoryRepository categoryRepository;
    private final SubcategoryRepository subcategoryRepository;

    public ArticleResponseCategoryDto toCategoryDto(Subcategory subcategory) {
        var category = subcategory.getCategory();
        return new ArticleResponseCategoryDto(
                category.getId(),
                category.getName(),
                new SubcategoryDto(subcategory.getId(), subcategory.getName())
        );
    }

    @Transactional
    public Subcategory getSubcategory(ArticleCategoryChangeRequest categoryDto) {
        return isNewSubcategory(categoryDto) ?
                createNewSubcategory(categoryDto.name(), categoryDto.categoryId()) : getFromRepository(categoryDto.subcategoryId());
    }

    private boolean isNewSubcategory(ArticleCategoryChangeRequest categoryDto) {
        return ModelUtils.isNew(categoryDto::subcategoryId);
    }

    private Subcategory getFromRepository(int subcategoryId) {
        return subcategoryRepository.findByIdOrThrow(subcategoryId);
    }

    private Subcategory createNewSubcategory(String name, int categoryId) {
        return subcategoryRepository.save(
                Subcategory
                    .builder()
                    .name(name)
                    .category(categoryRepository.findByIdOrThrow(categoryId))
                    .build()
        );
    }
}
