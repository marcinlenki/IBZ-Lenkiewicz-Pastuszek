package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.ResourceUploadResults;
import com.lenkiewiczmarcin.articlesbackend.logic.common.Result;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collection;
import java.util.Set;

public interface ResourceService {
    ResourceEntrySet allocateResourceSpace(Collection<MultipartFile> files);
    void clearLocalResources(ResourceEntrySet uploadResources);
    ResourceUploadResults uploadResources(ResourceEntrySet uploadResources);
    Result<String> clearRemoteResource(String deleteUrl);
    Result<Set<String>> clearRemoteResources(Set<String> deleteUrls);
}
