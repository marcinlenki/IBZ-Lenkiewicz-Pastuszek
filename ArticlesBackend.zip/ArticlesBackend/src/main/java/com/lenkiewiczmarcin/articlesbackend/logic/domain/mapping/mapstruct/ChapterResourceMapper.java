package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct;

import com.lenkiewiczmarcin.articlesbackend.config.EntityMapperConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ChapterResource;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ChapterResourceChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.ChapterResourceMappingService;
import org.mapstruct.AfterMapping;
import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;

//TODO: Test
@Mapper(config = EntityMapperConfig.class)
public abstract class ChapterResourceMapper {
    private ChapterResourceMappingService mappingLogic;

    @Autowired
    public void setMappingLogic(ChapterResourceMappingService mappingLogic) {
        this.mappingLogic = mappingLogic;
    }

    @BeforeMapping
    protected ChapterResource verifyTypeChange(ChapterResourceChangeRequest chapterResourceChangeRequest) {
        return mappingLogic.verifyTypeChange(chapterResourceChangeRequest);
    }

    @Mapping(target = "type", expression = "java(getType(chapterResourceChangeRequest))")
    protected abstract ChapterResource chapterResourceChangeRequestToChapterResource(
            ChapterResourceChangeRequest chapterResourceChangeRequest);

    @AfterMapping
    protected void verifyUrlChange(ChapterResourceChangeRequest changedResource) {
        mappingLogic.verifyChanges(changedResource);
    }

    // use this method to keep the mapping logic private
    protected String getType(ChapterResourceChangeRequest chapterResourceChangeRequest) {
        return mappingLogic.getResourceType(chapterResourceChangeRequest);
    }
}
