package com.lenkiewiczmarcin.articlesbackend.security.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;

public abstract class ArticleStatusProcessor<T> {
    public T process(Article article) {
        var status = ArticleStatus.fromArticle(article);
        return switch (status) {
            case CREATED -> onCreated(article);
            case WAITING_FOR_REVIEW -> onWaitingForReview(article);
            case IN_REVIEW -> onInReview(article);
            case PUBLISHED -> onPublished(article);
        };
    }

    protected T onCreated(Article article) {
        throw new UnsupportedOperationException("onCreated");
    }

    protected T onWaitingForReview(Article article) {
        throw new UnsupportedOperationException("onWaitingForReview");
    }

    protected T onInReview(Article article) {
        throw new UnsupportedOperationException("onInReview");
    }

    protected T onPublished(Article article) {
        throw new UnsupportedOperationException("onPublished");
    }

    protected enum ArticleStatus {
        CREATED,
        WAITING_FOR_REVIEW,
        IN_REVIEW,
        PUBLISHED;

        public static ArticleStatus fromArticle(Article article) {
            var statusName = article.getStatus().getName();
            return valueOf(statusName.toUpperCase());
        }
    }

}
