package com.lenkiewiczmarcin.articlesbackend.logic.common;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.WrappedException;

import java.util.Optional;
import java.util.function.Consumer;

public final class Result<R> {
    private final R value;
    private final boolean successful;
    private final Throwable thrownException;

    private Result(R value, boolean successful, Throwable thrownException) {
        this.value = value;
        this.successful = successful;
        this.thrownException = thrownException;
    }

    public static <R> Result<R> of(ExceptionalSupplier<R> supplier) {
        R res = null;
        Throwable throwable = null;
        boolean success;

        try {
            res  = supplier.get();
            success = true;
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new WrappedException(ex);
        } catch (Exception ex) {
            throwable = ex;
            success = false;
        }

        return new Result<>(res, success, throwable);
    }

    @SuppressWarnings("UnusedReturnValue")
    public Result<R> onSuccess(Consumer<R> resultConsumer) {
        if (successful) {
            resultConsumer.accept(value);
        }
        return this;
    }

    @SuppressWarnings("UnusedReturnValue")
    public Result<R> onFailure(Consumer<Throwable> exceptionConsumer) {
        if (!successful) {
            exceptionConsumer.accept(thrownException);
        }
        return this;
    }

    public boolean successful() {
        return successful;
    }

    public R get() {
        return value;
    }

    public R getOrNull() {
        return successful ? value : null;
    }

    public Optional<R> asOptional() {
        return successful ? Optional.of(value) : Optional.empty();
    }

    public R getOrThrow() {
        if (!successful) {
            throw new WrappedException(thrownException);
        }

        return value;
    }

}
