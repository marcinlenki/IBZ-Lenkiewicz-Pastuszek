package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import com.lenkiewiczmarcin.articlesbackend.config.ResourceFilesConfig;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.MultipartFileUtils;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.WrappedIoException;
import com.lenkiewiczmarcin.articlesbackend.utils.UuidGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
@Slf4j
public class TemporaryResourceSpace implements ResourceSpace {
    // set to true if the upload directory was successfully created
    private final boolean isActive;

    private final Map<String, File> resources;
    private final UuidGenerator generator;
    private final ResourceFilesConfig resourceFilesConfig;
    private final File uploadDirectory;

    public TemporaryResourceSpace(UuidGenerator generator, ResourceFilesConfig resourceFilesConfig) {
        this.generator = generator;
        this.resourceFilesConfig = resourceFilesConfig;
        this.uploadDirectory = new File(resourceFilesConfig.getResourceDirectory());
        this.resources = new ConcurrentHashMap<>();
        this.isActive = createUploadDirectory();
    }

    @Override
    public File save(MultipartFile resourceFile) {
        checkEnabled();
        try {
            var originalExtension = getOriginalExtension(resourceFile);
            var generatedFilename = generateFilename(originalExtension);
            var temporaryFile = new File(uploadDirectory, generatedFilename);
            return saveEntry(resourceFile, temporaryFile);
        } catch (IOException e) {
            throw new WrappedIoException(e);
        }
    }

    @Override
    public File get(String filename) {
        checkEnabled();
        return resources.get(filename);
    }

    @Override
    public void remove(String filename) {
        checkEnabled();
        try {
            if (!resources.containsKey(filename)) {
                return;
            }
            var entry = resources.get(filename);
            deleteEntry(entry);
        } catch (IOException e) {
            throw new WrappedIoException(e);
        }
    }

    private String getOriginalExtension(MultipartFile resourceFile) {
        var fileExtension = MultipartFileUtils.getOriginalExtension(resourceFile);
        return fileExtension == null ? resourceFilesConfig.getDefaultFileExtension() : fileExtension;
    }

    private String generateFilename(String fileExtension) {
        var uuid = generator.createUUID();
        return uuid + "." + fileExtension;
    }

    private File saveEntry(MultipartFile resourceFile, File temporaryFile) throws IOException {
        Files.write(temporaryFile.toPath(), resourceFile.getBytes());
        resources.put(temporaryFile.getName(), temporaryFile);
        return temporaryFile;
    }

    private void deleteEntry(File entry) throws IOException {
        var temporaryFilename = entry.getName();
        Files.deleteIfExists(entry.toPath());
        resources.remove(temporaryFilename);
    }

    private boolean createUploadDirectory() {
        try {
            var dir = Files.createDirectories(uploadDirectory.toPath());
            log.info("Created upload directory at {}", dir.toAbsolutePath());
            return true;
        } catch (IOException e) {
            log.error("Unable to create upload directory, the feature will be disabled", e);
            return false;
        }
    }

    private void checkEnabled() {
        if (!isActive) {
            throw new UnsupportedOperationException();
        }
    }
}
