package com.lenkiewiczmarcin.articlesbackend.data.dto.auth.in;

import jakarta.validation.constraints.NotBlank;

public record AuthenticationRequest(@NotBlank String email, @NotBlank String password) {}
