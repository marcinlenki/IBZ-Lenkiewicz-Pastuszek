package com.lenkiewiczmarcin.articlesbackend.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Configuration
public class ResourceFilesConfig {

    @Value("${articles.uploads.directory}")
    @Getter
    private String resourceDirectory;

    @Value("${articles.uploads.default-file-ext}")
    @Getter
    private String defaultFileExtension;

    @Value("${articles.uploads.allowed-extensions}")
    private String acceptedFileExtensionsString;

    public Set<String> getAcceptedFileExtensions() {
        return Arrays.stream(
                acceptedFileExtensionsString.split(","))
                .collect(Collectors.toSet());
    }
}
