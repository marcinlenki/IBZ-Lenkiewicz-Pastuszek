package com.lenkiewiczmarcin.articlesbackend.data.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.NaturalId;

@Table(name = "article_status")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class ArticleStatus implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NaturalId
    private String name;

    @Override
    public Integer getIdentifier() {
        return getId();
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return true;
    }

    @Override
    public String getNaturalIdentifier() {
        return name;
    }

    @Override
    public final boolean equals(Object o) {
        return ModelUtils.testEqualityByNaturalKey(this, o);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeByNaturalId(this);
    }
}
