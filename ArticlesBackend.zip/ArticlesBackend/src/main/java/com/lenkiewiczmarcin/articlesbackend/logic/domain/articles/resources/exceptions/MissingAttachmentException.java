package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.exceptions;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;

import java.text.MessageFormat;
import java.util.Map;

public final class MissingAttachmentException extends BackendException {
    private static final MessageFormat messageFormat =
            new MessageFormat("Missing attachment [{0}] in article [{1}].");
    private final String attachmentName;
    private final String articleTitle;

    public MissingAttachmentException(String attachmentName, String articleTitle) {
        this.attachmentName = attachmentName;
        this.articleTitle = articleTitle;
    }

    @Override
    public String getErrorCode() {
        return ErrorCodes.MISSING_ATTACHMENT_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return messageFormat.format(new Object[] {attachmentName, articleTitle});
    }

    @Override
    public Object getExceptionItem() {
        return Map.of("Article title", articleTitle, "Attachment name", attachmentName);
    }
}
