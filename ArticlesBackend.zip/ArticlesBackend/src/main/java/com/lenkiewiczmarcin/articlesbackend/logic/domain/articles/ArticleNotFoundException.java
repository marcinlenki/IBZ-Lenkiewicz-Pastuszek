package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;

public class ArticleNotFoundException extends ResourceNotFoundException {
    private static final String ARTICLE = "article";

    public ArticleNotFoundException(Integer identifier) {
        super(ARTICLE, identifier);
    }
}
