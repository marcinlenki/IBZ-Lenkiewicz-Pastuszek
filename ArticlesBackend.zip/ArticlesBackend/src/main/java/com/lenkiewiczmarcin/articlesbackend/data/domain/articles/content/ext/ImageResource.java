package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class ImageResource extends AbstractChapterResource {
    private String url;
    private String contentType;
    private double resizeModifier;

    @Override
    public boolean shouldBeHandled() {
        return true;
    }

    @Override
    public void setUploadUrl(@NonNull String url) {
        this.setUrl(url);
    }

    @Override
    public String getUploadUrl() {
        return url;
    }
}
