package com.lenkiewiczmarcin.articlesbackend.security;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Map;

public class UnauthorizedException extends BackendException {
    @Override
    public String getErrorCode() {
        return ErrorCodes.UNAUTHORIZED_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return "You are unauthorized to perform this action";
    }

    @Override
    public Object getExceptionItem() {
        var path = getPath();
        return path == null ? null : Map.of("path", path);
    }

    private String getPath() {
        return ServletUriComponentsBuilder
                .fromCurrentRequestUri()
                .build()
                .getPath();
    }

}
