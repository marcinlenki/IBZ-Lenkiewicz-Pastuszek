package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext.AbstractChapterResource;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Table(name = "chapter_resource")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class ChapterResource implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String description;
    private Integer orderNumber;
    private String type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chapter_id")
    @ToString.Exclude
    private Chapter chapter;

    @JdbcTypeCode(SqlTypes.JSON)
    private AbstractChapterResource content;

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return false;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByPrimaryKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeFromFields(id, description, orderNumber);
    }

}