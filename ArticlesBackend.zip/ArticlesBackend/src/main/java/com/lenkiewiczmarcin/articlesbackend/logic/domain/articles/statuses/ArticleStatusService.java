package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.statuses;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.ArticleStatus;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ArticleStatusRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Transactional
public class ArticleStatusService {
    private final ArticleStatusRepository repository;

    public ArticleStatus getWaitingForReviewStatus() {
        return repository
                .getWaitingForReviewStatus()
                .orElseThrow(() -> new ArticleStatusNotFoundException("waiting for review"));
    }

    public ArticleStatus getInReviewStatus() {
        return repository
                .getInReviewStatus()
                .orElseThrow(() -> new ArticleStatusNotFoundException("in review"));
    }

    public ArticleStatus getPublishedStatus() {
        return repository
                .getPublishedStatus()
                .orElseThrow(() -> new ArticleStatusNotFoundException("published"));
    }
}
