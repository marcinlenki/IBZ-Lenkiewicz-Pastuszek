package com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions;

import java.text.MessageFormat;
import java.util.Map;

public class ResourceNotFoundException extends BackendException {
    private static final MessageFormat messageFormat =
            new MessageFormat("Unable to find {0} with {1} = [{2}]");

    private final String entityType;
    private final String field;
    private final String identifier;

    protected ResourceNotFoundException(String entityType, String field, String identifier) {
        this.entityType = entityType;
        this.field = field;
        this.identifier = identifier;
    }

    protected ResourceNotFoundException(String entityType, String field, Integer identifier) {
        this(entityType, field, String.valueOf(identifier));
    }

    protected ResourceNotFoundException(String entityType, Integer identifier) {
        this(entityType, "id", identifier);
    }

    @Override
    public String getErrorCode() {
        return ErrorCodes.RESOURCE_NOT_FOUND_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return messageFormat.format(new Object[] {entityType, field, identifier});
    }

    @Override
    public Object getExceptionItem() {
        return Map.of("Object", entityType, "Field", field, "Identifier", identifier);
    }
}
