package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.s3;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.model.UploadResult;
import com.lenkiewiczmarcin.articlesbackend.config.S3Config;
import com.lenkiewiczmarcin.articlesbackend.logic.common.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class S3Utility {
    private final S3Config s3Config;
    private final AmazonS3 amazonS3;
    private final TransferManager transferManager;

    URL getUploadUrl(File file) {
        var bucket = s3Config.getBucketName();
        var filename = file.getName();
        return getUploadUrl(filename, bucket);
    }

    String getUploadUrl(UploadResult uploadResult) {
        var bucket = uploadResult.getBucketName();
        var key = uploadResult.getKey();
        return getUploadUrl(key, bucket).toString();
    }

    String getUploadUrl(String key) {
        var bucket = s3Config.getBucketName();
        return getUploadUrl(key, bucket).toString();
    }

    // async
    Upload startFileUpload(File uploadFile) {
        var bucket = s3Config.getBucketName();
        var filename = uploadFile.getName();
        return transferManager.upload(bucket, filename, uploadFile);
    }

    // blocks until upload is done
    Result<UploadResult> getFileUploadResult(Upload upload) {
        return Result.of(upload::waitForUploadResult);
    }

    String deleteResource(String resourceUrl) {
        var keyToDelete = getResourceKey(resourceUrl);
        deleteRemoteFile(keyToDelete);
        return resourceUrl;
    }

    DeleteObjectsResult deleteResources(Set<String> resourcesUrls) {
        var keysToDelete = getResourceKeys(resourcesUrls);
        return deleteRemoteFiles(keysToDelete);
    }

    private URL getUploadUrl(String key, String bucket) {
        return amazonS3.getUrl(bucket, key);
    }

    private Set<String> getResourceKeys(Set<String> resourceUrls) {
        return resourceUrls
                .stream()
                .map(this::getResourceKey)
                .collect(Collectors.toSet());
    }

    private String getResourceKey(String resourceUrl) {
        return new AmazonS3URI(resourceUrl).getKey();
    }

    private void deleteRemoteFile(String keyToDelete) {
        var bucket = s3Config.getBucketName();
        amazonS3.deleteObject(bucket, keyToDelete);
    }

    private DeleteObjectsResult deleteRemoteFiles(Set<String> keys) {
        var bucket = s3Config.getBucketName();
        var versionedKeys = toVersionedKeys(keys);
        var deleteRequest = new DeleteObjectsRequest(bucket);
        deleteRequest.setKeys(versionedKeys);
        return amazonS3.deleteObjects(deleteRequest);
    }

    private List<DeleteObjectsRequest.KeyVersion> toVersionedKeys(Set<String> keys) {
        return keys
                .stream()
                .map(DeleteObjectsRequest.KeyVersion::new)
                .toList();
    }

}
