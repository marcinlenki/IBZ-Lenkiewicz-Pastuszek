package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation;

import com.lenkiewiczmarcin.articlesbackend.config.ResourceFilesConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ArticleRepository;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.SubcategoryRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.ArticleProcessingEntry;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.MultipartFileUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DefaultArticleValidationService implements ArticleValidationService {
    private final ArticleRepository articleRepository;
    private final SubcategoryRepository subcategoryRepository;
    private final ResourceFilesConfig resourceFilesConfig;

    @Override
    public ValidationResult validate(ArticleProcessingEntry articleProcessingEntry) {
        return new ArticleTitleValidationStep(articleRepository)
                .and(new ArticleCategoryValidationStep(subcategoryRepository))
                .and(new FilesValidationStep(resourceFilesConfig))
                .validate(articleProcessingEntry);
    }

    @RequiredArgsConstructor
    private static final class ArticleTitleValidationStep extends ValidationStep<ArticleProcessingEntry> {
        private final ArticleRepository articleRepository;

        @Override
        public ValidationResult validate(ArticleProcessingEntry toValidate) {
            var articleToValidate = toValidate.articleChangeRequest();
            var title =  articleToValidate.getTitle();
            return articleRepository
                    .findArticleByTitle(title)
                    .filter(article -> !article.getId().equals(articleToValidate.getId()))
                    .isPresent() ?
                    ValidationResult.invalid(String.format("Article title [%s] already exists", title)) : checkNext(toValidate);
        }

    }

    @RequiredArgsConstructor
    private static final class ArticleCategoryValidationStep extends ValidationStep<ArticleProcessingEntry> {
        private final SubcategoryRepository subcategoryRepository;

        @Override
        public ValidationResult validate(ArticleProcessingEntry toValidate) {
            var category = toValidate.articleChangeRequest().getCategory();
            if (ModelUtils.isNew(category::subcategoryId)) {
                var newSubcategoryName = category.name();
                if (subcategoryRepository.existsByName(newSubcategoryName)) {
                    return ValidationResult
                            .invalid(String.format("A subcategory with name [%s] already exists", newSubcategoryName));
                }
            }

            return checkNext(toValidate);
        }
    }

    @RequiredArgsConstructor
    private static final class FilesValidationStep extends ValidationStep<ArticleProcessingEntry> {
        private final ResourceFilesConfig resourceFilesConfig;

        @Override
        public ValidationResult validate(ArticleProcessingEntry toValidate) {
            var acceptedExtensions = resourceFilesConfig.getAcceptedFileExtensions();
            var files = toValidate.files();

            for (var file : files) {
                var fileExt = MultipartFileUtils.getOriginalExtension(file);
                if (!acceptedExtensions.contains(fileExt)) {
                    var originalFilename = file.getOriginalFilename();
                    return ValidationResult.invalid("Resource file [" + originalFilename + "] is of invalid type [" +
                            fileExt + "], accepted types are: " + acceptedExtensions);
                }
            }

            return checkNext(toValidate);
        }
    }
}
