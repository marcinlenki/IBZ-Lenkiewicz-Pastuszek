package com.lenkiewiczmarcin.articlesbackend.data.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;

public interface DatabaseEntity extends Serializable {
    @JsonIgnore
    Integer getIdentifier();

    @JsonIgnore
    Boolean hasNaturalIdentifier();

    @JsonIgnore
    default String getNaturalIdentifier() {
        var className = this.getClass().getSimpleName();
        throw new UnsupportedOperationException("Entity of type [" + className + "] doesn't have a natural id!");
    }
}
