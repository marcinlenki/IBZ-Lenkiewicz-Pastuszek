package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ChapterResource;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.ResourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.event.spi.PreDeleteEvent;
import org.hibernate.event.spi.PreDeleteEventListener;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * This class listens for different events which occur when a resource is scheduled for deletion and
 * delegates deletion request.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ResourceDeleteEventListener implements PreDeleteEventListener, ApplicationListener<ResourceDeleteEvent> {
    private final ResourceService resourceService;

    @Override
    public boolean onPreDelete(PreDeleteEvent event) {
        return handleDelete(event);
    }

    @Override
    public void onApplicationEvent(ResourceDeleteEvent event) {
        resourceService.clearRemoteResource(event.getResourceUrl())
                .onSuccess(ignored -> event.setResult(true));
    }

    private boolean handleDelete(PreDeleteEvent event) {
        if (!shouldBeHandled(event)) {
            return false;
        }
        var chapterResource = (ChapterResource) event.getEntity();
        deleteRemoteResource(chapterResource);
        return false;
    }

    private boolean shouldBeHandled(PreDeleteEvent event) {
        return event.getEntity() instanceof ChapterResource cr && cr.getContent().shouldBeHandled();
    }

    protected void deleteRemoteResource(ChapterResource chapterResource) {
        var resourceContent = chapterResource.getContent();
        var resourceUrl = resourceContent.getUploadUrl();
        resourceService
                .clearRemoteResource(resourceUrl)
                .onSuccess(this::logResourceDeletion)
                .onFailure(ex -> log.error("Unable to delete resource " + chapterResource.getId()));
    }

    protected void logResourceDeletion(String url) {
        log.info("Successfully deleted resource of url [{}]", url);
    }
}
