package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.function.Supplier;

@NoRepositoryBean
public interface DataRepository<T extends DatabaseEntity> extends JpaRepository<T, Integer>, JpaSpecificationExecutor<T> {

    default T findByIdOrThrow(final Integer id) {
        return findById(id).orElseThrow(getExceptionSupplier(id));
    }

    default Supplier<ResourceNotFoundException> getExceptionSupplier(final Integer id) {
        return null;
    }
}
