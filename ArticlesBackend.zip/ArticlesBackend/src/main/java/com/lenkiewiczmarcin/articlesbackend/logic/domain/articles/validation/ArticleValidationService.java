package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation;

import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.ArticleProcessingEntry;

public interface ArticleValidationService {
    ValidationResult validate(ArticleProcessingEntry articleProcessingEntry);
}
