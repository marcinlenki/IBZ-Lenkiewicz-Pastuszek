package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom;

import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.ArticleFactory;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.out.ArticleResponse;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ArticleRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct.ArticleMapper;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.function.Function;

@Service
@RequiredArgsConstructor
public class ArticleMappingService {
    private final ArticleRepository articleRepository;
    private final ArticleMapper mapperHelper;

    public Function<Article, ArticleResponse> getDefaultMapper() {
        return this::toDto;
    }

    @Transactional
    public Article toArticle(@NonNull ArticleChangeRequest articleChangeRequest) {
        var articleId = articleChangeRequest.getId();
        var article = isCreateRequest(articleChangeRequest) ?
                ArticleFactory.createArticleWithDefaults() : getFromRepository(articleId);

        mapperHelper.updateArticleFromArticleChangeRequest(articleChangeRequest, article);
        return article;
    }

    public ArticleResponse toDto(Article article) {
        return mapperHelper.convertArticleToArticleResponse(article);
    }

    private boolean isCreateRequest(ArticleChangeRequest articleChangeRequest) {
        return ModelUtils.isNew(articleChangeRequest::getId);
    }

    private Article getFromRepository(int articleId) {
        return articleRepository.findByIdOrThrow(articleId);
    }

}
