package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

// Implementation of UserDetails interface that allows only one role and does not implement methods that are not needed
public interface SimpleUserDetails extends UserDetails {
    String getRoleName();

    @Override
    default Collection<? extends GrantedAuthority> getAuthorities() {
        // each user has one role
        return List.of(new SimpleGrantedAuthority(getRoleName()));
    }

    // not implemented

    @Override
    default boolean isAccountNonExpired() {
        return true;
    }

    @Override
    default boolean isAccountNonLocked() {
        return true;
    }

    @Override
    default boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    default boolean isEnabled() {
        return true;
    }
}
