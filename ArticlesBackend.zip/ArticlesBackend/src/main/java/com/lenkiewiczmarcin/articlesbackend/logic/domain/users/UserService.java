package com.lenkiewiczmarcin.articlesbackend.logic.domain.users;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.BusinessKeyRepository;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.UserRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.SimpleUserDetails;
import com.lenkiewiczmarcin.articlesbackend.security.SystemRoles;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService implements UserDetailsService {
    private final UserRepository repository;
    private final BusinessKeyRepository businessKeyRepository;

    // makes use of first level cache by using entity manager
    @Override
    @Transactional
    public User loadUserByUsername(final @NonNull String email) throws UsernameNotFoundException {
        return businessKeyRepository
                .findByNaturalId(email, User.class)
                .orElseThrow(() ->
                        new UsernameNotFoundException(String.format("Unable to find user with email [%s]", email)));
    }

    // doesn't use first level cache (direct SQL query) but fetches the user with corresponding role
    @Transactional
    public User loadUserByUsernameWithRole(final @NonNull String email) throws UsernameNotFoundException {
        return repository
                .findByEmail(email)
                .orElseThrow(() ->
                        new UsernameNotFoundException(String.format("Unable to find user with email [%s]", email)));
    }


    public boolean isAdmin(SimpleUserDetails userDetails) {
        return userDetails != null && userDetails.getRoleName().equals(SystemRoles.ADMINISTRATOR);
    }

}
