package com.lenkiewiczmarcin.articlesbackend.logic.domain.tags;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Tag;
import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.tags.out.TagDto;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.TagRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct.TagMapper;
import com.lenkiewiczmarcin.articlesbackend.utils.PageUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TagService {
    private final TagRepository repository;
    private final TagMapper mapper;

    public ResponsePage<TagDto> getTags(Pageable pageable) {
        var page = repository.findAll(pageable);
        var tags = mapPagedResponse(page);
        return PageUtils.from(tags, pageable, page.getTotalElements(), page.getTotalPages());
    }

    private List<TagDto> mapPagedResponse(Page<Tag> page) {
        return page
                .stream()
                .map(mapper::convertTagToTagDto)
                .toList();
    }

}
