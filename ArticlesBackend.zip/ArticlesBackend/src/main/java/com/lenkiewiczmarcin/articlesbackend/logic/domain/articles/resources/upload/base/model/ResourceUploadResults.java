package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;

public record ResourceUploadResults(
        Set<SuccessfulFileUpload> successfulFileUploads,
        Set<UnsuccessfulFileUpload> unsuccessfulFileUploads
) implements Serializable {
    public static final ResourceUploadResults EMPTY_RESULTS
            = new ResourceUploadResults(Collections.emptySet(), Collections.emptySet());

    public boolean allUploadsFailed() {
        return successfulFileUploads.isEmpty() && wasUnsuccessful();
    }

    public boolean wasUnsuccessful() {
        return !unsuccessfulFileUploads.isEmpty();
    }
}
