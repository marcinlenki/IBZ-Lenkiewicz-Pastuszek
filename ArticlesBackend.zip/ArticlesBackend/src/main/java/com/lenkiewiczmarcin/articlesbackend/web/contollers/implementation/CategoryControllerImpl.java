package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.CategoryDto;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.categories.CategoryService;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.definition.CategoryController;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CategoryControllerImpl implements CategoryController {
    private final CategoryService service;

    @Override
    public ResponsePage<CategoryDto> getCategories(Pageable pageable) {
        return service.getCategories(pageable);
    }

    @Override
    public CategoryDto getCategory(Integer id) {
        return service.getCategory(id);
    }

}
