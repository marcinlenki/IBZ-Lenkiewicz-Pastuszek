package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct;

import com.lenkiewiczmarcin.articlesbackend.config.EntityMapperConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.data.dto.users.AuthorDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(config = EntityMapperConfig.class)
public abstract class UserMapper {

    // MAPPING METHODS

    // entity to dto
    // (used in article response mapping)
    @Mapping(target = "name", expression = "java(author.getFullName())")
    public abstract AuthorDto convertAuthorToAuthorDto(User author);

}
