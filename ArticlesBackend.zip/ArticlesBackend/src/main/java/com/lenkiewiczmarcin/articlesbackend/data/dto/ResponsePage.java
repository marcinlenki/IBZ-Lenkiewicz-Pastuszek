package com.lenkiewiczmarcin.articlesbackend.data.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
@Getter
public class ResponsePage<T> {
    private final List<T> content;
    private final long totalPages;
    private final DefaultPageable page;

    public record DefaultPageable(
            int number,
            int size,
            int elements,
            boolean first,
            boolean last
    ) {}
}
