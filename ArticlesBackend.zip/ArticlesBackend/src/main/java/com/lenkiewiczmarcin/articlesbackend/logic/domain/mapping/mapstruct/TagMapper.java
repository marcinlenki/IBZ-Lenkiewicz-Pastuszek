package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct;

import com.lenkiewiczmarcin.articlesbackend.config.EntityMapperConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Tag;
import com.lenkiewiczmarcin.articlesbackend.data.dto.tags.out.TagDto;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.TagMappingService;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

@Mapper(config = EntityMapperConfig.class)
public abstract class TagMapper {
    private TagMappingService mappingLogic;

    @Autowired
    public void setTagService(TagMappingService tagService) {
        this.mappingLogic = tagService;
    }

    // MAPPING METHODS

    // dto to entity
    // (used in article change request mapping)
    public Set<Tag> convertTagNamesToTags(Set<String> tagNames) {
        return mappingLogic.associateOrCreateTags(tagNames);
    }

    // entity to dto
    public abstract TagDto convertTagToTagDto(Tag tag);

    // helper
    // (used in article change request mapping)
    public abstract Set<String> convertTagToTag(Set<Tag> tags);
    public String convertTagToTag(Tag tag) {
        return mappingLogic.getReadableTagName(tag);
    }

}
