package com.lenkiewiczmarcin.articlesbackend.security;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;

@FunctionalInterface
public interface PermissionEvaluator<T extends DatabaseEntity> {
    boolean hasPermission(User user, T entity);
}
