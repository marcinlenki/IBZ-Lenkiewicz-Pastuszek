package com.lenkiewiczmarcin.articlesbackend.utils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public final class CollectionUtils {
    private CollectionUtils() {}

    // helper methods which return empty collections rather than nulls to avoid null pointer exception

    public static <T> List<T> getList(List<T> originalCollection) {
        return Objects.requireNonNullElse(originalCollection, Collections.emptyList());
    }

    public static <T> Set<T> getSet(Set<T> originalCollection) {
        return Objects.requireNonNullElse(originalCollection, Collections.emptySet());
    }

}
