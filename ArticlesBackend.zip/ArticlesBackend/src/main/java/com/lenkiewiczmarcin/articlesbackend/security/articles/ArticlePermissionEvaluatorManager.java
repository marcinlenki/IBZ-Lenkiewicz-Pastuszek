package com.lenkiewiczmarcin.articlesbackend.security.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.WebContext;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.users.UserService;
import com.lenkiewiczmarcin.articlesbackend.security.PermissionEvaluator;
import com.lenkiewiczmarcin.articlesbackend.security.articles.permissions.*;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
@Transactional
public class ArticlePermissionEvaluatorManager {
    private final UserService userService;

    public boolean hasReadPermission(Article article) {
        return checkPermission(article, ReadPermissionEvaluator::new);
    }

    public boolean hasEditPermission(Article article) {
        return checkPermission(article, OwnershipPermissionEvaluator::new);
    }

    public boolean hasSubmitPermission(Article article) {
        return checkPermission(article, SubmitPermissionEvaluator::new);
    }

    public boolean hasReviewPermission(Article article) {
        return checkPermission(article, ReviewPermissionEvaluator::new);
    }

    public boolean hasPublishPermission(Article article) {
        return checkPermission(article, PublishPermissionEvaluator::new);
    }

    public boolean hasDeletePermission(Article article) {
        return checkPermission(article, OwnershipPermissionEvaluator::new);
    }

    private boolean checkPermission(Article article, Supplier<PermissionEvaluator<Article>> supplier) {
        var permissionEvaluator = supplier.get();
        var currentUser = WebContext.currentUser();
        if (userService.isAdmin(currentUser)) {
            return true;
        }
        return permissionEvaluator.hasPermission(currentUser, article);
    }
}
