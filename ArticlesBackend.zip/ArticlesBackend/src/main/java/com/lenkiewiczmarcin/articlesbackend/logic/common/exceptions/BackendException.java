package com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions;

import com.lenkiewiczmarcin.articlesbackend.utils.Time;
import lombok.Getter;

import java.time.LocalDateTime;

/**
 * Base class for all exceptions in the application. Each exception should return an error code and a readable message.
 */
@Getter
public abstract class BackendException extends RuntimeException {

    private final LocalDateTime timestamp = Time.currentTime();

    protected BackendException() {}

    protected BackendException(String message, Throwable cause) {
        super(message, cause);
    }

    protected BackendException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getMessage() {
        return getReadableMessage();
    }

    public abstract String getErrorCode();

    public Object getExceptionItem() {
        return null;
    }

    public final String exceptionIdentifier() {
        return getClass().getSimpleName();
    }

    protected abstract String getReadableMessage();
}
