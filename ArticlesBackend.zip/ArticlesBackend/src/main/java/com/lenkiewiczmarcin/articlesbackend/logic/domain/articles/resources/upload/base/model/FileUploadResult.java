package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model;

import java.io.Serializable;

public interface FileUploadResult extends Serializable {
    boolean successful();
    String uploadFilename();
}
