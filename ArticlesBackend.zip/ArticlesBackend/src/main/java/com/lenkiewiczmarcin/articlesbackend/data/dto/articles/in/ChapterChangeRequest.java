package com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in;

import com.lenkiewiczmarcin.articlesbackend.utils.CollectionUtils;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;

public record ChapterChangeRequest(
        @Min(value = 1, message = "Chapter id must be greater than 0")
        Integer id,
        @Size(max = 32, message = "Chapter title must be between 8 and 32 characters long")
        String title,
        @NotBlank @Size(max = 2048, message = "Chapter text cannot be blank or be longer than 2048 characters long")
        String text,
        @Valid
        List<ChapterResourceChangeRequest> chapterResources
) {
    @Override
    public List<ChapterResourceChangeRequest> chapterResources() {
        return CollectionUtils.getList(chapterResources);
    }
}
