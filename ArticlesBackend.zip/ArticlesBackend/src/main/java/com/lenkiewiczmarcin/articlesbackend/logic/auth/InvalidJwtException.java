package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;

public class InvalidJwtException extends BackendException {
    public InvalidJwtException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getErrorCode() {
        return ErrorCodes.INVALID_JWT_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return String.format("Passed token is invalid. %s.", getCause().getMessage());
    }

}
