package com.lenkiewiczmarcin.articlesbackend.data.domain;

import org.hibernate.proxy.HibernateProxy;

import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

public final class ModelUtils {
    private ModelUtils() {}

    public static <T extends DatabaseEntity> boolean testEqualityByPrimaryKey(T firstEntity, Object secondObject) {
        return testEquality(firstEntity, secondObject, ModelUtils::haveTheSamePrimaryKeys);
    }

    public static <T extends DatabaseEntity> boolean testEqualityByNaturalKey(T firstEntity, Object secondObject) {
        return testEquality(firstEntity, secondObject, ModelUtils::haveTheSameNaturalsIds);
    }

    public static int calculateHashcode(Object entity) {
        return entity instanceof HibernateProxy proxy ?
                proxy.getHibernateLazyInitializer().getPersistentClass().hashCode() : entity.getClass().hashCode();
    }

    public static int calculateHashcodeFromFields(Object ... fields) {
        return Objects.hash(fields);
    }

    public static <T extends DatabaseEntity> int calculateHashcodeByNaturalId(T entity) {
        return Objects.hashCode(entity.getNaturalIdentifier());
    }

    public static boolean isNew(Integer id) {
        return id == null || id == 0;
    }

    // need to check for null and 0 as both are possible
    public static boolean isNew(Supplier<Integer> idRetriever) {
        var id = idRetriever.get();
        return isNew(id);
    }

    public static boolean isNew(DatabaseEntity databaseEntity) {
        return isNew(databaseEntity::getIdentifier);
    }

    @SuppressWarnings("unchecked")
    private static <T extends DatabaseEntity> boolean testEquality(T firstEntity, Object secondObject,
                                                                   BiPredicate<T, T> compareFunction) {

        if (firstEntity == secondObject) return true;
        if (nullOrNotTheSameClass(firstEntity, secondObject)) return false;

        // this is a safe cast
        T otherEntity = (T) secondObject;

        return compareFunction.test(firstEntity, otherEntity);
    }

    private static boolean nullOrNotTheSameClass(Object firstEntity, Object secondEntity) {
        if (secondEntity == null) return true;

        Class<?> firstEntitiesEffectiveClass = firstEntity instanceof HibernateProxy proxy ?
                proxy.getHibernateLazyInitializer().getPersistentClass() : firstEntity.getClass();

        Class<?> secondEntitesEffectiveClass = secondEntity instanceof HibernateProxy proxy ?
                proxy.getHibernateLazyInitializer().getPersistentClass() : secondEntity.getClass();

        return firstEntitiesEffectiveClass != secondEntitesEffectiveClass;
    }

    private static <T extends DatabaseEntity> boolean haveTheSamePrimaryKeys(T first, T second) {
        return Objects.equals(first.getIdentifier(), second.getIdentifier());
    }

    private static <T extends DatabaseEntity> boolean haveTheSameNaturalsIds(T first, T second) {
        return first.getNaturalIdentifier().equals(second.getNaturalIdentifier());
    }

}
