package com.lenkiewiczmarcin.articlesbackend.config;

import org.mapstruct.Builder;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.MapperConfig;
import org.mapstruct.ReportingPolicy;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@MapperConfig(
        // disable builders to automatically use setters in all auto generated mappings
        builder = @Builder(disableBuilder = true),
        componentModel = SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        collectionMappingStrategy = CollectionMappingStrategy.TARGET_IMMUTABLE
)
public interface EntityMapperConfig {
}
