package com.lenkiewiczmarcin.articlesbackend.data.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.utils.Time;

public final class ArticleFactory {

    private ArticleFactory() {}

    public static Article createArticleWithDefaults() {
        return Article
                .builder()
                .createdTimestamp(Time.currentTime())
                .numberOfViews(0)
                .parentalAdvisory(false)
                .build();
    }
}
