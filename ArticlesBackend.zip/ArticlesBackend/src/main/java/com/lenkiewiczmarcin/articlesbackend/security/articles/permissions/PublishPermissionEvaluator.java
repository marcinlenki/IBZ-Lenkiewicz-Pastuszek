package com.lenkiewiczmarcin.articlesbackend.security.articles.permissions;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.security.articles.ArticlePermissionEvaluator;
import com.lenkiewiczmarcin.articlesbackend.security.articles.ArticleStatusPredicateProcessor;

public class PublishPermissionEvaluator extends ArticlePermissionEvaluator {
    @Override
    public boolean hasPermission(User user, Article article) {
        return hasPermissionOnStatus(article, new ArticleStatusPredicateProcessor() {
            @Override
            protected Boolean onInReview(Article article) {
                return isArticleEditor(user, article);
            }
        });
    }
}
