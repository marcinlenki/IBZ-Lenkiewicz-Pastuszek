package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.s3;

import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.MultiObjectDeleteException;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.model.UploadResult;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.AbstractResourceService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.ResourceEntry;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.TemporaryResourceSpace;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.AbstractFileUploadResult;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.SuccessfulFileUpload;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.UnsuccessfulFileUpload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Primary
public class S3ResourceServiceImpl extends AbstractResourceService {
    private static final int NUMBER_OF_FILE_DELETE_ATTEMPTS = 3;
    private final S3Utility s3Utility;

    public S3ResourceServiceImpl(TemporaryResourceSpace temporaryResourceSpace, S3Utility s3Utility) {
        super(temporaryResourceSpace);
        this.s3Utility = s3Utility;
    }

    @Override
    protected int getNumberOfFileDeleteAttempts() {
        return NUMBER_OF_FILE_DELETE_ATTEMPTS;
    }

    @Override
    protected ResourceEntry createResourceEntry(MultipartFile multipartFile, File temporaryFile) {
        return new S3ResourceEntry(multipartFile, temporaryFile);
    }

    @Override
    protected Set<AbstractFileUploadResult> uploadRemotely(Set<InternalResource> uploadResources) {
        var uploads = initiateUpload(uploadResources);
        return getUploadResults(uploads);
    }

    @Override
    protected String removeRemotely(String url) {
        return s3Utility.deleteResource(url);
    }

    @Override
    protected Set<String> removeRemotely(Set<String> urls) {
        try {
            var deleteResults = s3Utility.deleteResources(urls);
            return getDeletedObjectsUrls(deleteResults);
        } catch (MultiObjectDeleteException e) {
            throw rethrowAsBusinessException(e);
        }
    }

    // start async uploads for all entries
    private Map<String, Upload> initiateUpload(Set<InternalResource> uploadResources) {
        var filenameToUploadMap = new LinkedHashMap<String, Upload>();
        for (var uploadEntry : uploadResources) {
            var resourceEntry = uploadEntry.resourceEntry();
            var originalFilename = resourceEntry.getOriginalFilename();
            var temporaryFile = uploadEntry.temporaryFile();
            var upload = s3Utility.startFileUpload(temporaryFile);
            filenameToUploadMap.put(originalFilename, upload);
        }
        return filenameToUploadMap;
    }

    // retrieve upload results and block on waiting for result if necessary
    private Set<AbstractFileUploadResult> getUploadResults(Map<String, Upload> uploads) {
        var uploadResults = new LinkedHashSet<AbstractFileUploadResult>();
        for (var entry : uploads.entrySet()) {
            var filename = entry.getKey();
            var upload = entry.getValue();
            s3Utility.getFileUploadResult(upload)
                    .onSuccess(res -> uploadResults.add(createSuccessfulFileUpload(filename, res)))
                    .onFailure(ex -> uploadResults.add(new UnsuccessfulFileUpload(filename, ex)));
        }

        return uploadResults;
    }

    private AbstractFileUploadResult createSuccessfulFileUpload(String originalFilename, UploadResult uploadResult) {
        return new SuccessfulFileUpload(originalFilename, s3Utility.getUploadUrl(uploadResult));
    }

    private Set<String> getDeletedObjectsUrls(DeleteObjectsResult deleteResults) {
        return deleteResults
                .getDeletedObjects()
                .stream()
                .map(DeleteObjectsResult.DeletedObject::getKey)
                .map(s3Utility::getUploadUrl)
                .collect(Collectors.toSet());
    }

    private MultiResourceDeletionException rethrowAsBusinessException(MultiObjectDeleteException e) {
        return new MultiResourceDeletionException(
                getDeletedObjectsUrls(e.getDeletedObjects()),
                getUnsuccessfulDeletions(e.getErrors())
        );
    }

    private Set<String> getDeletedObjectsUrls(List<DeleteObjectsResult.DeletedObject> deletedObjects) {
        return deletedObjects
                .stream()
                .map(o -> s3Utility.getUploadUrl(o.getKey()))
                .collect(Collectors.toSet());
    }

    private Set<MultiResourceDeletionException.FailedUpload> getUnsuccessfulDeletions(List<MultiObjectDeleteException.DeleteError> deleteErrors) {
        return deleteErrors
                .stream()
                .map(e ->
                        new MultiResourceDeletionException.FailedUpload(
                                s3Utility.getUploadUrl(e.getKey()),
                                e.getMessage()
                        )
                )
                .collect(Collectors.toSet());
    }


    private class S3ResourceEntry implements ResourceEntry {
        private final MultipartFile multipartFile;
        private final File temporaryFile;

        public S3ResourceEntry(MultipartFile multipartFile, File temporaryFile) {
            this.multipartFile = multipartFile;
            this.temporaryFile = temporaryFile;
        }

        @Override
        public String getOriginalFilename() {
            return multipartFile.getOriginalFilename();
        }

        @Override
        public String getTemporaryFilename() {
            return temporaryFile.getName();
        }

        @Override
        public URL getUploadUrl() {
            return s3Utility.getUploadUrl(temporaryFile);
        }
    }
}
