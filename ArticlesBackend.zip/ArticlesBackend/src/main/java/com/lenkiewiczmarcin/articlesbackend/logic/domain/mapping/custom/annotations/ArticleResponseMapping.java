package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.annotations;

import org.mapstruct.Mapping;

// Helps with mapping article to article response.
@Mapping(target = "category", expression = "java(categoryMapper.convertSubcategoryToCategoryDto(article.getSubcategory()))")
@Mapping(target = "tags", expression = "java(tagMapper.convertTagToTag(article.getTags()))")
public @interface ArticleResponseMapping {
}
