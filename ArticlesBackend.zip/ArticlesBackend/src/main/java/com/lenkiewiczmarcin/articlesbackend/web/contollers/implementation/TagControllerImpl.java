package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.tags.out.TagDto;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.tags.TagService;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.definition.TagController;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class TagControllerImpl implements TagController {
    private final TagService service;

    @Override
    public ResponsePage<TagDto> getTags(Pageable pageable) {
        return service.getTags(pageable);
    }

}
