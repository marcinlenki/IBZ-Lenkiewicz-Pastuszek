package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import org.springframework.lang.Nullable;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;

import java.util.Optional;

import static org.springframework.security.core.context.SecurityContextHolder.getContext;

public final class WebContext {
    private WebContext() {}

    // returns null when user is anonymous
    @Nullable
    public static User currentUser() {
        if (isAnonymous()) {
            return null;
        }
        return getAuthentication()
                .map(Authentication::getPrincipal)
                .map(User.class::cast)
                .orElse(null);
    }

    public static boolean isAnonymous() {
        return getAuthentication().isEmpty() ||
                getAuthentication().filter(AnonymousAuthenticationToken.class::isInstance).isPresent();
    }

    public static Optional<Authentication> getAuthentication() {
        return Optional.ofNullable(getContext().getAuthentication());
    }

    public static void setAuthentication(Authentication authentication) {
        getContext().setAuthentication(authentication);
    }

}
