package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext;

/**
 * Contains all possible chapter resource types. Define new types here.
 * Remember to register them in {@link AbstractChapterResource}.
 */
public final class ChapterResourceType {
    private ChapterResourceType() {}

    /**
     * Image displayed under the chapter.
     */
    public static final String IMAGE_VALUE = "image";

    /**
     * Twitter post displayed under the chapter.
     */
    public static final String TWITTER_POST_VALUE = "twitter-post";
}
