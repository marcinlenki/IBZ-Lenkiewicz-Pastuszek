package com.lenkiewiczmarcin.articlesbackend.logic.domain.reviews.statuses;

import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ReviewStatus_;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;

public class ReviewStatusNotFoundException extends ResourceNotFoundException {
    private static final String REVIEW_STATUS = "review status";
    public ReviewStatusNotFoundException(String statusName) {
        super(REVIEW_STATUS, ReviewStatus_.NAME, statusName);
    }
}
