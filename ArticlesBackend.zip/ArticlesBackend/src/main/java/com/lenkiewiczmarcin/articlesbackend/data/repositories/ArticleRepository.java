package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.ArticleNotFoundException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.function.Supplier;

@Repository
public interface ArticleRepository extends DataRepository<Article> {
    Optional<Article> findArticleByTitle(String title);

    @Override
    default Supplier<ResourceNotFoundException> getExceptionSupplier(final Integer id) {
        return () -> new ArticleNotFoundException(id);
    }
}
