package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.in.AuthenticationRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.out.AuthenticationResponse;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.users.UserService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class DefaultAuthenticationService implements AuthenticationService {
    private final AuthenticationManager authenticationManager;
    private final UserService userService;
    private final JwtService jwtService;

    @Override
    @Transactional
    public AuthenticationResponse authenticate(AuthenticationRequest authRequest) throws BadCredentialsException {
        // throws exception if email or password are invalid
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(authRequest.email(), authRequest.password()));

        var user = userService.loadUserByUsername(authRequest.email());
        var token = jwtService.generateToken(user);
        return new AuthenticationResponse(token, null);
    }

}
