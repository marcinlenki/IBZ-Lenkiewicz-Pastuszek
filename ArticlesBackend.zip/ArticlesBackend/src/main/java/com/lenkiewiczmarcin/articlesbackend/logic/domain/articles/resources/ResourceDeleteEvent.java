package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEvent;

import java.io.Serializable;

@Getter
public class ResourceDeleteEvent extends ApplicationEvent {
    private final String resourceUrl;
    private final EventResult result;

    public ResourceDeleteEvent(Object source, String resourceUrl) {
        super(source);
        this.resourceUrl = resourceUrl;
        this.result = new EventResult();
    }

    public void setResult(boolean success) {
        result.success = success;
    }

    public boolean wasSuccessful() {
        return result.success;
    }

    @RequiredArgsConstructor
    private static class EventResult implements Serializable {
        private boolean success;
    }

}
