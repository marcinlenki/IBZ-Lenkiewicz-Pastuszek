package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation;

import jakarta.validation.constraints.NotNull;

public abstract class ValidationStep <T> {
    private ValidationStep<T> next;

    public ValidationStep<T> and(@NotNull ValidationStep<T> next) {
        if (this.next == null) {
            this.next = next;
            return this;
        }
        var previousStep = this.next;
        while (previousStep.next != null) {
            previousStep = previousStep.next;
        }
        previousStep.next = next;
        return this;
    }

    public abstract ValidationResult validate(T toValidate);

    protected ValidationResult checkNext(T toValidate) {
        if (next == null) {
            return ValidationResult.valid();
        }

        return next.validate(toValidate);
    }
}
