package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Tag;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.BusinessKeyRepository;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TagMappingService {

    private final BusinessKeyRepository businessKeyRepository;

    public String getReadableTagName(Tag tag) {
        return StringUtils.capitalize(tag.getName().toLowerCase());
    }

    // Returns managed set of tags. The tags are fetched from database by name. Non-existing tags are created.
    @NonNull
    @Transactional
    public Set<Tag> associateOrCreateTags(@NonNull Set<String> tagNames) {
        var uppercaseTagNames = prepare(tagNames);
        var emptyTags = mapToEmptyTags(uppercaseTagNames);
        return merge(uppercaseTagNames, emptyTags);
    }

    private Set<String> prepare(Set<String> tagNames) {
        return tagNames
                .stream()
                .map(String::trim)
                .map(String::toUpperCase)
                .collect(Collectors.toSet());
    }

    private Set<Tag> mapToEmptyTags(Set<String> tagNames) {
        return tagNames
                .stream()
                .map(this::createEmptyTag)
                .collect(Collectors.toSet());
    }

    private Tag createEmptyTag(String tagName) {
        return Tag.builder()
                .name(tagName)
                .build();
    }

    private Set<Tag> merge(Set<String> preparedTagsNames, Set<Tag> emptyTags) {
        var tagsFromDatabase = businessKeyRepository.findAllByNaturalIds(preparedTagsNames, Tag.class);
        // tag equals and hashcode are based on name so this is going to add only new tags
        tagsFromDatabase.addAll(emptyTags);
        return tagsFromDatabase;
    }

}
