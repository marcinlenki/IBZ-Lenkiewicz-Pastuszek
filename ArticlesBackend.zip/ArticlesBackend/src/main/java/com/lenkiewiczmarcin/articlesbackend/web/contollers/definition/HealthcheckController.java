package com.lenkiewiczmarcin.articlesbackend.web.contollers.definition;

import com.lenkiewiczmarcin.articlesbackend.data.dto.HealthcheckResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.lenkiewiczmarcin.articlesbackend.web.contollers.ApiPaths.HEALTHCHECK;

@RequestMapping(HEALTHCHECK)
public interface HealthcheckController {
    @GetMapping
    HealthcheckResponse healthcheck();
}
