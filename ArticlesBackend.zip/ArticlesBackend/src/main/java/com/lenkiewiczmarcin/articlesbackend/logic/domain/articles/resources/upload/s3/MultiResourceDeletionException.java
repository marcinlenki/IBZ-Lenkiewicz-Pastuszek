package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.s3;

import lombok.Getter;

import java.io.Serializable;
import java.util.Set;

/**
 * Wrapper class for aws s3 {@link com.amazonaws.services.s3.model.MultiObjectDeleteException}. Thrown when at least one
 * remote resource deletion fails.
 */
@Getter
public class MultiResourceDeletionException extends RuntimeException {
    private static final String MESSAGE = "An exception occurred while deleting remote files, unsuccessful deletions: ";

    private final Set<String> successfulDeletions;
    private final Set<FailedUpload> unsuccessfulDeletions;

    MultiResourceDeletionException(Set<String> successfulDeletions, Set<FailedUpload> unsuccessfulDeletions) {
        this.successfulDeletions = successfulDeletions;
        this.unsuccessfulDeletions = unsuccessfulDeletions;
    }

    @Override
    public String getMessage() {
        return MESSAGE + unsuccessfulDeletions;
    }

    record FailedUpload(String url, String exceptionMessage) implements Serializable {}
}
