package com.lenkiewiczmarcin.articlesbackend.web.contollers.definition;

import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.in.AuthenticationRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.out.AuthenticationResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.lenkiewiczmarcin.articlesbackend.web.contollers.ApiPaths.AUTH;

@RequestMapping(AUTH)
public interface AuthenticationController {
    @PutMapping("login")
    AuthenticationResponse login(@Valid @RequestBody AuthenticationRequest authenticationRequest);

}
