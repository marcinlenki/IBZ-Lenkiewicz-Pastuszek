package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.exceptions;

import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.ResourceUploadResults;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.UnsuccessfulFileUpload;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;
import lombok.Getter;

import java.util.Set;
import java.util.stream.Collectors;

@Getter
public final class ResourceUploadException extends BackendException {
    private final ResourceUploadResults uploadResults;

    public ResourceUploadException(ResourceUploadResults uploadResults) {
        this.uploadResults = uploadResults;
    }

    @Override
    public String getErrorCode() {
        return ErrorCodes.RESOURCE_UPLOAD_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return "Unsuccessful uploads of files: " + getUploadNames();
    }

    @Override
    public Object getExceptionItem() {
        return getUploadNames();
    }

    private Set<String> getUploadNames() {
        return uploadResults
                .unsuccessfulFileUploads()
                .stream()
                .map(UnsuccessfulFileUpload::uploadFilename)
                .collect(Collectors.toSet());
    }
}
