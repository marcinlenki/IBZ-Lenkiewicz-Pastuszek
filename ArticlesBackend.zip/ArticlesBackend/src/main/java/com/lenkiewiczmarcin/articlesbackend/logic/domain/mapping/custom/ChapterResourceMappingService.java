package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom;

import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ChapterResource;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ChapterResourceChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ChapterResourceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ChapterResourceMappingService {
    private final ChapterResourceRepository repository;

    // TODO: maybe change this in the future
    public String getResourceType(ChapterResourceChangeRequest chapterResourceChangeRequest) {
        var content = chapterResourceChangeRequest.content();
        return content.getClass().getSimpleName();
    }

    // Disallow changing the type of the resource
    // If the type has changed then ignore any changes on this resource
    public ChapterResource verifyTypeChange(ChapterResourceChangeRequest changedResource) {
        if (ModelUtils.isNew(changedResource::id)) {
            return null;
        }
        var previousResource = repository.findByIdOrThrow(changedResource.id());
        var previousType = previousResource.getType();
        var newType = getResourceType(changedResource);

        // comply with mapstruct generation mechanism - return null if mapping should continue
        return previousType.equals(newType) ? null : previousResource;
    }

    public void verifyChanges(ChapterResourceChangeRequest changedResource) {
        if (shouldSkipVerification(changedResource)) {
            return;
        }
        var previousResource = repository.findByIdOrThrow(changedResource.id());
        var previousContent = previousResource.getContent();
        var newContent = changedResource.content();

        newContent.setUploadUrl(previousContent.getUploadUrl());
    }

    // If the resource is new then upload url has just been set by the application, so it is safe to skip verification
    private boolean shouldSkipVerification(ChapterResourceChangeRequest changedResource) {
        var content = changedResource.content();
        return !content.shouldBeHandled() || ModelUtils.isNew(changedResource::id);
    }

}
