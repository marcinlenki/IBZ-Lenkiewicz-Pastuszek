package com.lenkiewiczmarcin.articlesbackend.web.filters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.InvalidJwtException;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.JwtService;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.users.UserService;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.WebContext;
import com.lenkiewiczmarcin.articlesbackend.data.dto.exceptions.out.ExceptionMessage;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.function.Function;

import static com.lenkiewiczmarcin.articlesbackend.logic.auth.WebContext.getAuthentication;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@RequiredArgsConstructor
@Slf4j
public class JwtAuthFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UserService userService;
    private final ObjectMapper objectMapper;

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        // should not use the filter if security context is already present or the request doesn't contain jwt
        return getAuthentication().isPresent() || !containsJwtToken(request);
    }

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException
    {
        var authHeader = getAuthHeader(request);
        var token = getJwt(authHeader);
        try {
            jwtService
                    .getUsername(token)
                    .map(userService::loadUserByUsernameWithRole)
                    .ifPresent(userDetails -> setAuthentication(userDetails, request));

            filterChain.doFilter(request, response);

        } catch (JwtException | UsernameNotFoundException e) {
            log.error("Spring Security Filter Chain Exception", e);
            writeException(e, response, InvalidJwtException::new);
        }
    }

    private boolean containsJwtToken(HttpServletRequest request) {
        var authHeader = getAuthHeader(request);
        return authHeader != null && hasDeclaredToken(authHeader);
    }

    private String getAuthHeader(HttpServletRequest request) {
        return request.getHeader("Authorization");
    }

    private boolean hasDeclaredToken(String authHeader) {
        return authHeader.startsWith("Bearer ");
    }

    private String getJwt(String authHeader) {
        return authHeader.substring(7); // start of the JWT
    }

    private void setAuthentication(UserDetails userDetails, HttpServletRequest request) {
        var authenticationToken = new UsernamePasswordAuthenticationToken(
                userDetails, null, userDetails.getAuthorities());
        authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        WebContext.setAuthentication(authenticationToken);
    }

    private <T, R extends BackendException> void writeException(T e, HttpServletResponse response,
                                                                Function<T, R> domainExceptionMapper
    ) throws IOException {
        var responseWriter = response.getWriter();
        var domainException = domainExceptionMapper.apply(e);
        writeException(responseWriter, domainException);
        response.setContentType(APPLICATION_JSON_VALUE);
        response.setStatus(BAD_REQUEST.value());
    }

    private <R extends BackendException> void writeException(PrintWriter writer, R e) throws IOException {
        var exceptionMessage = ExceptionMessage.build(e);
        var json = objectMapper
                .writerWithDefaultPrettyPrinter()
                .writeValueAsString(exceptionMessage);

        writer.println(json);
    }
}
