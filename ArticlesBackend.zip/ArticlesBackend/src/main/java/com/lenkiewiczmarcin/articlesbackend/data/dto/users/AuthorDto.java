package com.lenkiewiczmarcin.articlesbackend.data.dto.users;

public record AuthorDto(Integer id, String name) {
}
