package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.in.AuthenticationRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.auth.out.AuthenticationResponse;

public interface AuthenticationService {
    AuthenticationResponse authenticate(AuthenticationRequest loginRequest);
}
