package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import com.lenkiewiczmarcin.articlesbackend.logic.common.Result;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.WrappedIoException;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.*;
import com.lenkiewiczmarcin.articlesbackend.utils.FunctionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Slf4j
public abstract class AbstractResourceService implements ResourceService {
    private final ResourceSpace resourceSpace;

    @Override
    public ResourceEntrySet allocateResourceSpace(Collection<MultipartFile> files) {
        var entries = saveAsTemporaryResources(files);
        return new ResourceEntrySet(entries);
    }

    // This function suppresses any exceptions thrown during the upload process and marks the upload as unsuccessful
    @Override
    public ResourceUploadResults uploadResources(ResourceEntrySet uploadResources) {
        if (uploadResources.isEmpty()) {
            return ResourceUploadResults.EMPTY_RESULTS;
        }
        var internalResources = mapToInternalResources(uploadResources);
        var uploadResults = uploadRemotely(internalResources);
        var successfulUploads = getSuccessfulUploads(uploadResults);
        var unsuccessfulUploads = getUnsuccessfulUploads(uploadResults);
        return new ResourceUploadResults(successfulUploads, unsuccessfulUploads);
    }

    @Override
    public void clearLocalResources(ResourceEntrySet uploadResources) {
        uploadResources
                .stream()
                .map(ResourceEntry::getTemporaryFilename)
                .forEach(this::tryRemoveLocally);
    }

    @Override
    public Result<String> clearRemoteResource(String deleteUrl) {
        return Result.of(() -> tryRemoveRemotely(deleteUrl));
    }

    @Override
    public Result<Set<String>> clearRemoteResources(Set<String> deleteUrls) {
        return Result.of(() -> tryRemoveRemotely(deleteUrls));
    }

    protected abstract int getNumberOfFileDeleteAttempts();

    protected abstract ResourceEntry createResourceEntry(MultipartFile multipartFile, File temporaryFile);

    protected abstract Set<AbstractFileUploadResult> uploadRemotely(Set<InternalResource> uploadResources);

    protected abstract String removeRemotely(String url);

    protected abstract Set<String> removeRemotely(Set<String> urls);

    private int getRealNumberOfFileDeleteAttempts() {
        return Math.max(getNumberOfFileDeleteAttempts(), 1);
    }

    private HashSet<ResourceEntry> saveAsTemporaryResources(Collection<MultipartFile> files) {
        return files.stream()
                .map(this::save)
                .flatMap(Optional::stream)
                .collect(Collectors.toCollection(HashSet::new));
    }

    private Optional<ResourceEntry> save(MultipartFile multipartFile) {
        try {
            var temporaryFile = resourceSpace.save(multipartFile);
            return Optional.of(createResourceEntry(multipartFile, temporaryFile));
        } catch (WrappedIoException e) {
            return handleFailure(multipartFile, e);
        }
    }

    private Optional<ResourceEntry> handleFailure(MultipartFile multipartFile, WrappedIoException e) {
        log.error("Could not save multipart file [" + multipartFile.getOriginalFilename() + "] as temporary resource." , e);
        return Optional.empty();
    }

    private Set<InternalResource> mapToInternalResources(ResourceEntrySet uploadResources) {
        return uploadResources
                .stream()
                .map(this::fromResourceEntry)
                .collect(Collectors.toSet());
    }

    private InternalResource fromResourceEntry(ResourceEntry entry) {
        var file = resourceSpace.get(entry.getTemporaryFilename());
        return new InternalResource(file, entry);
    }

    private Set<SuccessfulFileUpload> getSuccessfulUploads(Set<? extends FileUploadResult> uploadResults) {
        return uploadResults
                .stream()
                .filter(FileUploadResult::successful)
                // this is a safe cast
                .map(SuccessfulFileUpload.class::cast)
                .collect(Collectors.toSet());
    }

    private Set<UnsuccessfulFileUpload> getUnsuccessfulUploads(Set<? extends FileUploadResult> uploadResults) {
        return uploadResults
                .stream()
                .filter(fileUploadResult -> !fileUploadResult.successful())
                // this is a safe cast
                .map(UnsuccessfulFileUpload.class::cast)
                .collect(Collectors.toSet());
    }

    private void tryRemoveLocally(String filename) {
        var numberOfFileDeleteAttempts = getRealNumberOfFileDeleteAttempts();
        var successful = FunctionUtils
                .tryNTimes(numberOfFileDeleteAttempts, () -> resourceSpace.remove(filename));

        if (!successful)
            log.warn("Could not remove temporary file: {}, the file must be removed manually", filename);
    }

    private String tryRemoveRemotely(String url) {
        var numberOfFileDeleteAttempts = getRealNumberOfFileDeleteAttempts();
        return FunctionUtils
                .tryCalculateNTimes(numberOfFileDeleteAttempts, () -> removeRemotely(url));
    }

    private Set<String> tryRemoveRemotely(Set<String> urls) {
        var numberOfFileDeleteAttempts = getRealNumberOfFileDeleteAttempts();
        return FunctionUtils.tryCalculateNTimes(
                numberOfFileDeleteAttempts, () -> removeRemotely(urls));
    }

    protected record InternalResource(
            File temporaryFile,
            ResourceEntry resourceEntry
    ) {}
}
