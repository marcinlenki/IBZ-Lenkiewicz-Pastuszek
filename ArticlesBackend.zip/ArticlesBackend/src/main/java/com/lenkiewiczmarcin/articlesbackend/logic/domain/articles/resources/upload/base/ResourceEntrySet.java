package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import java.util.Set;
import java.util.stream.Stream;

public class ResourceEntrySet {
    private final Set<ResourceEntry> entries;

    public ResourceEntrySet(Set<ResourceEntry> entries) {
        this.entries = entries;
    }

    public Stream<ResourceEntry> stream() {
        return entries.stream();
    }

    public boolean isEmpty() {
        return entries == null || entries.isEmpty();
    }

}
