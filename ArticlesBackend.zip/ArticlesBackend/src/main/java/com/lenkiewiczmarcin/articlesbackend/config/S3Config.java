package com.lenkiewiczmarcin.articlesbackend.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class S3Config {

    @Value("${access.key.id}")
    private String accessKeyId;

    @Value("${access.key.secret}")
    private String accessKeySecret;

    @Value("${s3.region.name}")
    private String s3RegionName;

    @Value("${s3.url:#{null}}")
    private String s3Url;


    @Getter
    @Value("${s3.bucket.name}")
    private String bucketName;

    @Bean
    AmazonS3 s3Client() {
        final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKeyId, accessKeySecret);
        var builder =  AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials));

        // use custom endpoint if provided
        if (s3Url != null) {
            builder.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(s3Url, s3RegionName));
        } else {
            builder.withRegion(s3RegionName);
        }

        return builder.build();
    }

    @Bean
    TransferManager transferManager(AmazonS3 amazonS3) {
        return TransferManagerBuilder
                .standard()
                .withS3Client(amazonS3)
                .build();
    }
}
