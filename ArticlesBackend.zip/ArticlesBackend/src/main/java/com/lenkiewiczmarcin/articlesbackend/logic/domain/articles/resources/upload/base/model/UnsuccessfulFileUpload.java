package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;

@Getter
public final class UnsuccessfulFileUpload extends AbstractFileUploadResult {
    @JsonIgnore
    private final Throwable cause;

    public UnsuccessfulFileUpload(String originalFilename, Throwable cause) {
        super(originalFilename);
        this.cause = cause;
    }

    @Override
    public boolean successful() {
        return false;
    }

}
