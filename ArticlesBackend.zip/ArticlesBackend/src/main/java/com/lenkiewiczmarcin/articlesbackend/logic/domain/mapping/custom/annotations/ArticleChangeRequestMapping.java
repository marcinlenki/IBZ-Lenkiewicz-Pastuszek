package com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.annotations;

import org.mapstruct.Mapping;

// Helps with mapping article change request to article.
@Mapping(target = "id", ignore = true)
@Mapping(
        target = "subcategory",
        expression = "java(categoryMapper.convertCategoryToSubcategory(articleChangeRequest.getCategory()))"
)
public @interface ArticleChangeRequestMapping {
}
