package com.lenkiewiczmarcin.articlesbackend.web.specifications;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import net.kaczmarzyk.spring.data.jpa.domain.Equal;
import net.kaczmarzyk.spring.data.jpa.domain.In;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Join;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Or;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Spec;
import org.springframework.data.jpa.domain.Specification;

@Join(path = "status", alias = "s")
@Join(path = "author", alias = "a")
@Join(path = "review", alias = "r")
@Join(path = "r.editor", alias = "e")
@Join(path = "tags", alias = "t")
@Join(path = "subcategory", alias = "sc")
@Join(path = "sc.category", alias = "c")
@Or({
        @Spec(path = "s.id", params = "statusId", paramSeparator = ',', spec = In.class),
        @Spec(path = "a.id", params = "authorId", spec = Equal.class),
        @Spec(path = "e.id", params = "editorId", spec = Equal.class),
        @Spec(path = "t.name", params = "tags", paramSeparator = ',', spec = In.class),
        @Spec(path = "c.id", params = "categoryId", spec = Equal.class),
        @Spec(path = "sc.id", params = "subcategoryId", spec = Equal.class)
})
public interface ArticleSearchSpecification extends Specification<Article> {}