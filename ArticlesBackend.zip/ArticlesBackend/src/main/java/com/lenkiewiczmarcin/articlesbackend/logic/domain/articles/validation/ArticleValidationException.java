package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;
import lombok.RequiredArgsConstructor;

import java.text.MessageFormat;

@RequiredArgsConstructor
public class ArticleValidationException extends BackendException {
    private static final MessageFormat messageFormat
            = new MessageFormat("Article validation failed with message: {0}");

    private final String message;

    @Override
    public String getErrorCode() {
        return ErrorCodes.ARTICLE_VALIDATION_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return messageFormat.format(new Object[] {message});
    }
}
