package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Category;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.categories.CategoryNotFoundException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.function.Supplier;

@Repository
public interface CategoryRepository extends DataRepository<Category> {
    @Override
    default Supplier<ResourceNotFoundException> getExceptionSupplier(final Integer id) {
        return () -> new CategoryNotFoundException(id);
    }
}
