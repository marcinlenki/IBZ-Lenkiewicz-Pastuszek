package com.lenkiewiczmarcin.articlesbackend.data.domain.users;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.SimpleUserDetails;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.NaturalId;

@Table(name = "end_user")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class User implements DatabaseEntity, SimpleUserDetails {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NaturalId
    private String email;

    private String password;
    private String firstName;
    private String lastName;
    private String nickname;
    private Boolean suspended;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    @ToString.Exclude
    private Role role;

    public String getFullName() {
        return firstName + " " + lastName;
    }

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return true;
    }

    @Override
    public String getNaturalIdentifier() {
        return email;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByNaturalKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeByNaturalId(this);
    }

    // user details
    @Override
    public String getUsername() {
        return getNaturalIdentifier();
    }

    @Override
    public String getRoleName() {
        return getRole().getName();
    }
}