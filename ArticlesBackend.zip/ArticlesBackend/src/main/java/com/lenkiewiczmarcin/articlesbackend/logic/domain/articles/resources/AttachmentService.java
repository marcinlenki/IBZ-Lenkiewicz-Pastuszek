package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources;

import com.google.common.base.Strings;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ChapterChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ChapterResourceChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.exceptions.MissingAttachmentException;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.AbstractFileUploadResult;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.ResourceUploadResults;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.SuccessfulFileUpload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttachmentService {
    private final ApplicationEventPublisher resourceDeleteEventPublisher;

    public Collection<MultipartFile> getAssociatedFiles(@NonNull ArticleChangeRequest article,
                                                        @NonNull List<MultipartFile> files) throws MissingAttachmentException {

        // can contain nulls
        var resourceMapping = createResourceMapping(article, files);
        // check for nulls and throw exception if there are any
        checkMissingResources(article, resourceMapping);
        return resourceMapping.values();
    }

    // works through side effects
    public void correctAttachmentsAfterResourceUpload(
            @NonNull ArticleChangeRequest article,
            @NonNull ResourceUploadResults uploadResults
    ) {
        var attachmentNamesToUrls = createAttachmentNameToUploadUrlMap(uploadResults);
        correctAttachments(article, attachmentNamesToUrls);
    }


    // private helper methods

    private Map<String, MultipartFile> createResourceMapping(ArticleChangeRequest article, List<MultipartFile> files) {
        var nameFileMap = createNameMap(files);
        var attachments = getAttachments(article);
        // map attachment names to actual files
        // if file is missing then null returned
        return attachments
                .stream()
                // workaround for Collectors.toMap() not accepting null values
                .collect(HashMap::new, (m, v) -> m.put(v, nameFileMap.get(v)), HashMap::putAll);
    }

    private Map<String, MultipartFile> createNameMap(List<MultipartFile> files) {
        return files
                .stream()
                .collect(Collectors.toMap(
                        MultipartFile::getOriginalFilename,
                        Function.identity()
                ));
    }

    private Set<String> getAttachments(ArticleChangeRequest articleChangeRequest) {
        var attachments = getResourcesWithDeclaredAttachments(articleChangeRequest)
                .stream()
                .map(ChapterResourceChangeRequest::attachment)
                .collect(Collectors.toSet());

        var articleThumbnail = articleChangeRequest.getThumbnailUrl();
        if (indicatesAttachment(articleThumbnail)) {
            attachments.add(articleThumbnail);
        }

        return attachments;
    }

    private Set<ChapterResourceChangeRequest> getResourcesWithDeclaredAttachments(ArticleChangeRequest articleChangeRequest) {
        // return all uploadable (!) chapter resources with declared attachment
        return articleChangeRequest
                .getChapters()
                .stream()
                .map(ChapterChangeRequest::chapterResources)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .filter(this::hasDeclaredAttachment)
                .filter(this::isUploadable)
                .collect(Collectors.toSet());
    }

    private boolean hasDeclaredAttachment(ChapterResourceChangeRequest chapterResource) {
        return chapterResource.attachment() != null && !chapterResource.attachment().isEmpty();
    }

    private boolean isUploadable(ChapterResourceChangeRequest chapterResource) {
        if (chapterResource.content().shouldBeHandled()) {
            return true;
        }
        log.warn("Chapter resource with declared attachment {} is not uploadable!", chapterResource.attachment());
        return false;
    }

    private void checkMissingResources(final ArticleChangeRequest article, Map<String, MultipartFile> resourceMapping) {
        resourceMapping.entrySet()
                .stream()
                .filter(entry -> entry.getValue() == null)
                .map(Map.Entry::getKey)
                .findAny()
                .ifPresent(attachment -> {
                    var articleTitle = article.getTitle();
                    throw new MissingAttachmentException(attachment, articleTitle);
                });
    }

    private boolean indicatesAttachment(String articleThumbnail) {
        if (Strings.isNullOrEmpty(articleThumbnail)) {
            return false;
        }

        try {
            // if this doesn't throw an exception then thumbnail is a valid url and is not considered an attachment
            new URL(articleThumbnail);
            return false;

        } catch (MalformedURLException ignored) {
            return true;
        }
    }

    private Map<String, String> createAttachmentNameToUploadUrlMap(ResourceUploadResults uploadResults) {
        return uploadResults
                .successfulFileUploads()
                .stream()
                .collect(Collectors.toMap(
                        AbstractFileUploadResult::uploadFilename,
                        SuccessfulFileUpload::getUploadUrl
                ));
    }

    private void correctAttachments(ArticleChangeRequest article, final Map<String, String> attachmentNamesToUrls) {
        // replace thumbnail if the new thumbnail was successfully uploaded
        handleTitleChange(article, attachmentNamesToUrls);

        // replace chapter resources
        var chapters = article.getChapters();
        // update urls of successfully uploaded resources and delete resources for which upload was unsuccessful
        chapters.forEach(chapter -> updateOrDeleteChapterResources(chapter, attachmentNamesToUrls));
    }

    private void handleTitleChange(ArticleChangeRequest article, Map<String, String> attachmentNamesToUrls) {
        var articleThumbnail = article.getThumbnailUrl();
        var uploadUrl = attachmentNamesToUrls.get(articleThumbnail);
        if (indicatesAttachment(articleThumbnail) && attachmentNamesToUrls.containsKey(articleThumbnail)) {
            article.setThumbnailUrl(uploadUrl);

//            var deleteEvent = new ResourceDeleteEvent(this, articleThumbnail);
//            resourceDeleteEventPublisher.publishEvent(deleteEvent); // this is a synchronous call
//            if (deleteEvent.wasSuccessful()) {
//                article.setThumbnailUrl(uploadUrl);
//            }
        }
    }

    private void updateOrDeleteChapterResources(ChapterChangeRequest chapter, final Map<String, String> attachmentNamesToUrls ) {
        var chapterResources = chapter.chapterResources();
        // use iterator to avoid ConcurrentModificationException
        for (var iterator = chapterResources.iterator(); iterator.hasNext(); ) {
            var resource = iterator.next();
            if (!hasDeclaredAttachment(resource) || !isUploadable(resource)) {
                continue;
            }
            var resourceContent = resource.content();
            var attachment = resource.attachment();
            var uploadUrl = attachmentNamesToUrls.get(attachment);
            // if upload url is missing than the upload of this attachment must have failed
            if (uploadUrl == null) {
                iterator.remove();
            } else {
                resourceContent.setUploadUrl(uploadUrl);
            }
        }
    }

}
