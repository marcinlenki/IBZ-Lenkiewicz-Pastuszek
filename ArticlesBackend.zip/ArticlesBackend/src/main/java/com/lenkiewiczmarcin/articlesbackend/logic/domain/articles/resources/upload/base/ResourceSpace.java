package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;

public interface ResourceSpace {
    File save(MultipartFile resourceFile);
    File get(String key);
    void remove(String key);
}
