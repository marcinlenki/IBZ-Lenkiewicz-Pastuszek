package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ReviewStatus;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ReviewStatusRepository extends DataRepository<ReviewStatus> {

    @Query(value = "SELECT * FROM get_opened_review_status()", nativeQuery = true)
    Optional<ReviewStatus> getOpenedStatus();

    @Query(value = "SELECT * FROM get_requires_changes_review_status()", nativeQuery = true)
    Optional<ReviewStatus> getRequiresChangesStatus();

    @Query(value = "SELECT * FROM get_closed_review_status()", nativeQuery = true)
    Optional<ReviewStatus> getClosedStatus();

}
