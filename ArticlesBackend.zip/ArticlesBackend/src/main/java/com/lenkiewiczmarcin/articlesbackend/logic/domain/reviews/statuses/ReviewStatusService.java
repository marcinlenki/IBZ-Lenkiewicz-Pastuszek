package com.lenkiewiczmarcin.articlesbackend.logic.domain.reviews.statuses;

import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ReviewStatus;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ReviewStatusRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ReviewStatusService {
    private final ReviewStatusRepository repository;

    public ReviewStatus getOpenedStatus() {
        return repository
                .getOpenedStatus()
                .orElseThrow(() -> new ReviewStatusNotFoundException("opened"));
    }

    public ReviewStatus getRequiresChangesStatus() {
        return repository
                .getRequiresChangesStatus()
                .orElseThrow(() -> new ReviewStatusNotFoundException("requires changes"));
    }

    public ReviewStatus getClosedStatus() {
        return repository
                .getClosedStatus()
                .orElseThrow(() -> new ReviewStatusNotFoundException("closed"));
    }

}
