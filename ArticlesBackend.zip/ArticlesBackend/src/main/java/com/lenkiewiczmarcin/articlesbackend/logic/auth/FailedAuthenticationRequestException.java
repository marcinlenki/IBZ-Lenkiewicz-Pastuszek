package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.BackendException;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ErrorCodes;

public class FailedAuthenticationRequestException extends BackendException {
    @Override
    public String getErrorCode() {
        return ErrorCodes.BAD_AUTH_EXCEPTION;
    }

    @Override
    protected String getReadableMessage() {
        return "Provided email or password are invalid";
    }
}
