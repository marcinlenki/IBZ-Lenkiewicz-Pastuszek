package com.lenkiewiczmarcin.articlesbackend.utils;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.MINUTES;

public final class Time {
    private Time() {}

    public static LocalDateTime currentTime() {
        return LocalDateTime.now(Clock.systemUTC());
    }

    public static Date currentDate() {
        return new Date();
    }

    public static Date minutesFromNow(int time) {
        return fromNow(time, MINUTES);
    }

    public static Date fromNow(int time, TimeUnit timeUnit) {
        var millis = MILLISECONDS.convert(time, timeUnit);
        return new Date(System.currentTimeMillis() + millis);
    }

}
