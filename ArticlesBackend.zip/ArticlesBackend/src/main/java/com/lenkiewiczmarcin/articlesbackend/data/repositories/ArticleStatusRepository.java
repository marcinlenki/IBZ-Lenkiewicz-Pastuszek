package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.ArticleStatus;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ArticleStatusRepository extends DataRepository<ArticleStatus> {
    @Query(value = "SELECT * FROM get_waiting_for_review_article_status()", nativeQuery = true)
    Optional<ArticleStatus> getWaitingForReviewStatus();

    @Query(value = "SELECT * FROM get_in_review_article_status()", nativeQuery = true)
    Optional<ArticleStatus> getInReviewStatus();

    @Query(value = "SELECT * FROM get_published_article_status()", nativeQuery = true)
    Optional<ArticleStatus> getPublishedStatus();
}
