package com.lenkiewiczmarcin.articlesbackend.logic.domain.reviews;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.domain.reviews.ReviewFactory;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ArticleReviewRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.reviews.statuses.ReviewStatusService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ReviewService {
    private final ArticleReviewRepository repository;
    private final ReviewStatusService reviewStatusService;

    @Transactional
    public void startReview(Article article, User editor) {
        var review = ReviewFactory.create(editor);
        article.setReview(review);
        repository.save(review);
    }

    @Transactional
    public void closeReview(Article article) {
        var newStatus = reviewStatusService.getClosedStatus();
        var review = article.getReview();
        if (review != null) {
            review.setReviewStatus(newStatus);
            repository.save(review);
        }
    }

}
