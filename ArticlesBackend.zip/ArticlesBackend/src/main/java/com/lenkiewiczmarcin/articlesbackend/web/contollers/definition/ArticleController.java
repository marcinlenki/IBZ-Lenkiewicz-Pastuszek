package com.lenkiewiczmarcin.articlesbackend.web.contollers.definition;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.out.ArticleResponse;
import com.lenkiewiczmarcin.articlesbackend.security.annotations.MustBeEmployee;
import com.lenkiewiczmarcin.articlesbackend.security.annotations.RequiresAuthorPermission;
import com.lenkiewiczmarcin.articlesbackend.security.annotations.RequiresEditorPermission;
import com.lenkiewiczmarcin.articlesbackend.web.specifications.ArticleSearchSpecification;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import static com.lenkiewiczmarcin.articlesbackend.web.contollers.ApiPaths.ARTICLES;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

@RequestMapping(ARTICLES)
@Validated
public interface ArticleController {

    @GetMapping
    ResponsePage<ArticleResponse> getArticles(ArticleSearchSpecification specification, Pageable pageable);

    @GetMapping("{id}")
    ArticleResponse getArticle(
            @PathVariable("id") @Min(value = 1, message = "Article id must be greater than 0!")   int articleId);

    @PostMapping(consumes = MULTIPART_FORM_DATA_VALUE)
    @RequiresAuthorPermission
    @ResponseStatus(CREATED)
    ArticleResponse createArticle(
            @Valid @RequestPart(name = "article") ArticleChangeRequest articleChangeRequest,
            @RequestPart(required = false) List<MultipartFile> files,
            @RequestParam(required = false, defaultValue = "false") boolean allowResourceUploadFailure
    );

    @PutMapping(value = "{id}", consumes = MULTIPART_FORM_DATA_VALUE)
    @MustBeEmployee
    ArticleResponse editArticle(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId,
            @Valid @RequestPart(name = "article") ArticleChangeRequest articleChangeRequest,
            @RequestPart(required = false) List<MultipartFile> files,
            @RequestParam(required = false, defaultValue = "false") boolean allowResourceUploadFailure
    );

    @PutMapping(value = "{id}/submit", consumes = MULTIPART_FORM_DATA_VALUE)
    @RequiresAuthorPermission
    ArticleResponse submitArticle(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId,
            @Valid @RequestPart(name = "article") ArticleChangeRequest articleChangeRequest,
            @RequestPart(required = false) List<MultipartFile> files,
            @RequestParam(required = false, defaultValue = "false") boolean allowResourceUploadFailure
    );

    @PatchMapping(value = "{id}/review")
    @RequiresEditorPermission
    ArticleResponse pickArticleForReview(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId);

    @PutMapping(value = "{id}/publish", consumes = MULTIPART_FORM_DATA_VALUE)
    @RequiresEditorPermission
    ArticleResponse publishArticle(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId,
            @Valid @RequestPart(name = "article") ArticleChangeRequest articleChangeRequest,
            @RequestPart(required = false) List<MultipartFile> files,
            @RequestParam(required = false, defaultValue = "false") boolean allowResourceUploadFailure
    );

    @PatchMapping(value = "{id}/rollback")
    @RequiresEditorPermission
    ArticleResponse rollbackArticle(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId);

    @DeleteMapping("{id}")
    @ResponseStatus(NO_CONTENT)
    @MustBeEmployee
    void deleteArticle(
            @Min(value = 1, message = "Article id must be greater than 0!") @PathVariable("id") int articleId);
}
