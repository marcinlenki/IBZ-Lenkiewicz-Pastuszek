package com.lenkiewiczmarcin.articlesbackend.security.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;

public abstract class ArticleStatusPredicateProcessor extends ArticleStatusProcessor<Boolean> {
    @Override
    protected Boolean onCreated(Article article) {
        return false;
    }

    @Override
    protected Boolean onWaitingForReview(Article article) {
        return false;
    }

    @Override
    protected Boolean onInReview(Article article) {
        return false;
    }

    @Override
    protected Boolean onPublished(Article article) {
        return false;
    }
}
