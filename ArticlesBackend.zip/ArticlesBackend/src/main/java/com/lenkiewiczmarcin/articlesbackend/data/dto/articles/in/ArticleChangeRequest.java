package com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in;

import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.in.ArticleCategoryChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.utils.CollectionUtils;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.List;
import java.util.Set;

// thumbnail can change through processing before being saved to database that's why it's not final
@Data
public class ArticleChangeRequest {
    private Integer id;

    @NotBlank(message = "Title cannot be blank")
    @Size(min = 8, max = 32, message = "Title must be between 8 and 32 characters long")
    private final String title;

    @Size(max = 128, message = "Thumbnail cannot be longer than 64 characters")
    private String thumbnailUrl;

    @Valid
    @NotNull(message = "Category cannot be null")
    private final ArticleCategoryChangeRequest category;

    private final Set<String> tags;

    @Size(max = 256, message = "Introduction cannot be longer than 256 characters")
    private final String introduction;

    @Valid
    private final List<ChapterChangeRequest> chapters;

    public Set<String> getTags() {
        return CollectionUtils.getSet(tags);
    }

    public List<ChapterChangeRequest> getChapters() {
        return CollectionUtils.getList(chapters);
    }
}
