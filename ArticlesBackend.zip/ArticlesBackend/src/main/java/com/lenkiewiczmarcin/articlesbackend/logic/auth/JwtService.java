package com.lenkiewiczmarcin.articlesbackend.logic.auth;

import com.lenkiewiczmarcin.articlesbackend.config.JwtConfig;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.InvalidKeyException;
import io.jsonwebtoken.security.Keys;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.*;
import java.util.function.Function;

import static com.lenkiewiczmarcin.articlesbackend.utils.Time.currentDate;
import static com.lenkiewiczmarcin.articlesbackend.utils.Time.minutesFromNow;
import static java.util.Optional.ofNullable;

@Service
@RequiredArgsConstructor
public class JwtService {
    private final JwtConfig jwtConfig;

    @Transactional
    public String generateToken(User user) throws InvalidKeyException {
        return generateToken(user, defaultClaims(user));
    }

    @Transactional
    public String generateToken(SimpleUserDetails userDetails, Map<String, Object> extraClaims)
            throws InvalidKeyException
    {
        return Jwts
                .builder()
                .claims(extraClaims)
                .subject(userDetails.getUsername())
                .issuedAt(currentDate())
                .expiration(minutesFromNow(jwtConfig.getJwtExpirationTime()))
                .signWith(getSignInKey(), Jwts.SIG.HS256)   // use HS256 signing algorithm
                .compact();
    }

    public Optional<String> getUsername(String token) {
        return ofNullable(getClaim(token, Claims::getSubject));
    }

    public <T> T getClaim(String token, Function<Claims, T> claimsResolver) throws JwtException {
        final Claims claims = getAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Map<String, Object> defaultClaims(User userDetails) {
        var claims = new HashMap<String, Object>();
        claims.put("id", userDetails.getId());
        claims.put("role", userDetails.getRoleName());
        return claims;
    }

    // throws exception if passed token is invalid (e.g. is expired)
    private Claims getAllClaims(String token) throws JwtException {
        return Jwts
                .parser()
                .verifyWith(getSignInKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private SecretKey getSignInKey() {
        byte [] keyBytes = Decoders.BASE64.decode(jwtConfig.getSigningKey());
        return Keys.hmacShaKeyFor(keyBytes);
    }

}