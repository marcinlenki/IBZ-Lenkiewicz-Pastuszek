package com.lenkiewiczmarcin.articlesbackend.security;

import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor
public class MockedUserInfo implements UserInfoService {
    private static final int STATIC_USER_ID = 1;

    private final UserRepository repository;

    @Override
    public Optional<User> getCurrentUser() {
        return repository.findById(STATIC_USER_ID);
    }

    @Override
    public boolean isAdmin() {
        return false;
    }

}
