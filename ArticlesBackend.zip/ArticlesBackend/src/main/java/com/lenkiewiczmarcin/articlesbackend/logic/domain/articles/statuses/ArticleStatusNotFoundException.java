package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.statuses;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.ArticleStatus_;
import com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions.ResourceNotFoundException;

class ArticleStatusNotFoundException extends ResourceNotFoundException {
    private static final String ARTICLE_STATUS = "article status";

    public ArticleStatusNotFoundException(String statusName) {
        super(ARTICLE_STATUS, ArticleStatus_.NAME, statusName);
    }
}
