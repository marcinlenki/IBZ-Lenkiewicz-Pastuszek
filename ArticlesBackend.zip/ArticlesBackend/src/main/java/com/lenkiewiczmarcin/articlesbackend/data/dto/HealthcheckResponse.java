package com.lenkiewiczmarcin.articlesbackend.data.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

public record HealthcheckResponse(String message, @JsonFormat(pattern="yyyy-MM-dd HH:mm") LocalDateTime date) {
}
