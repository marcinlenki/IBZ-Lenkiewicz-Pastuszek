package com.lenkiewiczmarcin.articlesbackend.logic.common;

import java.io.IOException;

@FunctionalInterface
public interface ExceptionalSupplier<R> {
    R get() throws InterruptedException, IOException;
}
