package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.utils.CollectionUtils;
import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Table(name = "article_chapter")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class Chapter implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String title;
    private String text;
    private Integer orderNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "article_id")
    @ToString.Exclude
    private Article article;

    @OneToMany(mappedBy = ChapterResource_.CHAPTER, cascade = CascadeType.ALL, orphanRemoval = true)
    @ToString.Exclude
    @OrderBy(ChapterResource_.ORDER_NUMBER)
    private Set<ChapterResource> chapterResources;

    public Set<ChapterResource> getChapterResources() {
        return CollectionUtils.getSet(chapterResources);
    }

    public void setChapterResources(Set<ChapterResource> chapterResources) {
        if (chapterResources != null && this.chapterResources != null) {
            prepareChapterResources(chapterResources);
            addChapterResources(chapterResources);
        } else if (chapterResources != null) {
            prepareChapterResources(chapterResources);
            this.chapterResources = chapterResources;
        } else if (this.chapterResources != null) {
            this.chapterResources.clear();
        }
    }

    private void prepareChapterResources(Set<ChapterResource> chapterResources) {
        int orderNum = 1;
        for (var chapterResource : chapterResources) {
            chapterResource.setOrderNumber(orderNum++);
            chapterResource.setChapter(this);
        }
    }

    private void addChapterResources(Set<ChapterResource> chapterResources) {
        this.chapterResources.clear();
        this.chapterResources.addAll(chapterResources);
    }

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return false;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByPrimaryKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeFromFields(id, title, text, orderNumber);
    }

}
