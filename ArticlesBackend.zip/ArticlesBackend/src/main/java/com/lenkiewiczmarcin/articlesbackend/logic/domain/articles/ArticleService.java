package com.lenkiewiczmarcin.articlesbackend.logic.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Article;
import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.ArticleStatus;
import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in.ArticleChangeRequest;
import com.lenkiewiczmarcin.articlesbackend.data.dto.articles.out.ArticleResponse;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.ArticleRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.WebContext;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.AttachmentService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.exceptions.ResourceUploadException;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.ResourceEntrySet;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.ResourceService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.ResourceUploadResults;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.resources.upload.base.model.SuccessfulFileUpload;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.statuses.ArticleStatusService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation.ArticleValidationException;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.articles.validation.ArticleValidationService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.custom.ArticleMappingService;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.reviews.ReviewService;
import com.lenkiewiczmarcin.articlesbackend.security.UnauthorizedException;
import com.lenkiewiczmarcin.articlesbackend.security.articles.ArticlePermissionEvaluatorManager;
import com.lenkiewiczmarcin.articlesbackend.utils.CollectionUtils;
import com.lenkiewiczmarcin.articlesbackend.utils.PageUtils;
import com.lenkiewiczmarcin.articlesbackend.web.specifications.ArticleSearchSpecification;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ArticleService {
    private final ArticleRepository repository;
    private final ArticleValidationService validationService;
    private final ArticlePermissionEvaluatorManager permissionEvaluator;
    private final AttachmentService attachmentService;
    private final ResourceService resourceService;
    private final ArticleMappingService mapper;
    private final ArticleStatusService articleStatusService;
    private final ReviewService reviewService;

    @Transactional
    public ResponsePage<ArticleResponse> getArticles(ArticleSearchSpecification specification, Pageable pageable) {
        // For now all the results are filtered after they have been fetched from the database. This solution is acceptable
        // because most of the articles are published, so they are available for the public anyway. If for some reason
        // the amount of articles that should not be available for the public increases, this mechanism should be changed.
        var page = repository.findAll(specification, pageable);
        var articles = mapPagedResponse(page);
        return PageUtils.from(articles, pageable, page.getTotalElements(), page.getTotalPages());
    }

    @Transactional
    public ArticleResponse getArticle(int articleId) {
        assertExist(articleId);
        verifyPermissions(articleId, permissionEvaluator::hasReadPermission);
        return mapResponse( repository.findByIdOrThrow(articleId) );
    }

    @Transactional
    public ArticleResponse createArticle(
            @NonNull ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        // permission check is already taken care of by Spring Security at this point
        ensureNewArticle(articleChangeRequest);
        var entry = toProcessingEntry(articleChangeRequest, files, allowResourceUploadFailure);
        return mapResponse( editAnd(entry, this::setAuthorToCurrentUser) );
    }

    @Transactional
    public ArticleResponse editArticle(
            @NonNull Integer articleId,
            @NonNull ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        ensureExistingArticle(articleChangeRequest, articleId);
        verifyPermissions(articleId, permissionEvaluator::hasEditPermission);
        var entry = toProcessingEntry(articleChangeRequest, files, allowResourceUploadFailure);
        return mapResponse( edit(entry) );
    }

    @Transactional
    public ArticleResponse submitArticleForReview(
            int articleId,
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        ensureExistingArticle(articleChangeRequest, articleId);
        verifyPermissions(articleId, permissionEvaluator::hasSubmitPermission);
        var entry = toProcessingEntry(articleChangeRequest, files, allowResourceUploadFailure);
        return mapResponse( editAndChangeStatus(entry, articleStatusService::getWaitingForReviewStatus) );
    }

    @Transactional
    public ArticleResponse pickArticleForReview(int articleId) {
        assertExist(articleId);
        verifyPermissions(articleId, permissionEvaluator::hasReviewPermission);
        var article = repository.findByIdOrThrow(articleId);
        var newStatus = articleStatusService.getInReviewStatus();
        article.setStatus(newStatus);
        var editor = WebContext.currentUser();
        reviewService.startReview(article, editor);
        return mapResponse(article);
    }

    @Transactional
    public ArticleResponse publishArticle(
            int articleId,
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        ensureExistingArticle(articleChangeRequest, articleId);
        verifyPermissions(articleId, permissionEvaluator::hasPublishPermission);
        var entry = toProcessingEntry(articleChangeRequest, files, allowResourceUploadFailure);
        var persistedArticle = editAndChangeStatus(entry, articleStatusService::getPublishedStatus);
        reviewService.closeReview(persistedArticle);
        return mapResponse(persistedArticle);
    }

    @Transactional
    public void deleteArticle(int articleId) {
        assertExist(articleId);
        verifyPermissions(articleId, permissionEvaluator::hasDeletePermission);
        var article = repository.findByIdOrThrow(articleId);
        var thumbnailUrl = article.getThumbnailUrl();
        repository.deleteById(articleId);
        if (thumbnailUrl != null) {
            resourceService
                    .clearRemoteResource(thumbnailUrl)
                    .onFailure(ex -> log.error(ex.getMessage(), ex));
        }
    }

    // private methods

    private List<ArticleResponse> mapPagedResponse(Page<Article> page) {
        return page
                .stream()
                .filter(permissionEvaluator::hasReadPermission)
                .map(this::mapResponse)
                .toList();
    }

    private void verifyPermissions(Integer articleId, Predicate<Article> permissionEvaluator) {
        var article = repository.findByIdOrThrow(articleId);
        if (!permissionEvaluator.test(article)) {
            throw new UnauthorizedException();
        }
    }

    private ArticleProcessingEntry toProcessingEntry(
            ArticleChangeRequest articleChangeRequest,
            List<MultipartFile> files,
            boolean allowResourceUploadFailure
    ) {
        // if files is null, then an empty list is returned to avoid null issues
        return new ArticleProcessingEntry(
                articleChangeRequest,
                CollectionUtils.getList(files),
                allowResourceUploadFailure);
    }

    private void ensureNewArticle(ArticleChangeRequest articleChangeRequest) {
        articleChangeRequest.setId(null);
    }

    private void ensureExistingArticle(ArticleChangeRequest articleChangeRequest, Integer articleId) {
        assertExist(articleId);
        articleChangeRequest.setId(articleId);
    }

    private void assertExist(Integer articleId) {
        if (!repository.existsById(articleId)) {
            throw new ArticleNotFoundException(articleId);
        }
    }

    private void setAuthorToCurrentUser(Article article) {
        // at this point of execution user must be present
        var currentUser = WebContext.currentUser();
        article.setAuthor(currentUser);
    }

    private ArticleResponse mapResponse(Article editedArticle) {
        var defaultMapper = mapper.getDefaultMapper();
        return mapResponse(editedArticle, defaultMapper);
    }

    private ArticleResponse mapResponse(Article editedArticle, Function<Article, ArticleResponse> mapper) {
        return mapper.apply(editedArticle);
    }

    private Article editAndChangeStatus(ArticleProcessingEntry entry, Supplier<ArticleStatus> newStatusSupplier) {
        var newStatus = newStatusSupplier.get();
        return editAnd(entry, article -> article.setStatus(newStatus));
    }

    private Article edit(ArticleProcessingEntry entry) {
        return editAnd(entry, null);
    }

    private Article editAnd(ArticleProcessingEntry entry, Consumer<Article> additionalArticleChanges) {
        assertValid(entry);

        var articleChangeRequest = entry.articleChangeRequest();
        var attachedFiles = entry.files();

        // Try to first associate attachments with files to check if there are any missing files
        // This will throw an exception if there are missing attachments and stop method execution
        var associatedFiles = attachmentService
                .getAssociatedFiles(articleChangeRequest, attachedFiles);

        ResourceUploadResults uploadResults = null;
        try {
            var allowUploadFailure = entry.allowResourceFailure();

            // Upload resources and attach urls to article change request
            // Some uploads may fail. If this happens two things can happen:
            // -> if allowUploadFailure flag is set to true, then corresponding chapter resources are deleted
            //    from article change request
            // -> if allowUploadFailure flag is set to false or all uploads have failed,
            //    then a ResourceUploadException is thrown
            if (!associatedFiles.isEmpty()) {
                uploadResults = processAndUploadArticleAttachments(
                        articleChangeRequest, associatedFiles, allowUploadFailure);
            }

            var article = mapper.toArticle(articleChangeRequest);
            if (additionalArticleChanges != null) {
                additionalArticleChanges.accept(article);
            }
            return repository.save(article);
        }
        catch (ResourceUploadException e) {
            clearRemoteResources(e);
            throw e;
        }
        catch (RuntimeException e) {
            clearRemoteResources(uploadResults);
            throw e;
        }
    }

    private void assertValid(ArticleProcessingEntry entry) {
        var validationResult = validationService.validate(entry);
        if (!validationResult.isValid()) {
            throw new ArticleValidationException(validationResult.message());
        }
    }

    private ResourceUploadResults processAndUploadArticleAttachments(
            ArticleChangeRequest articleChangeRequestWithAttachments,
            Collection<MultipartFile> uploadFiles,
            boolean allowUploadFailure
    ) {
        ResourceEntrySet resources = null;
        try {
            resources = resourceService.allocateResourceSpace(uploadFiles);
            var uploadResults = uploadArticleResources(resources, allowUploadFailure);
            attachmentService.correctAttachmentsAfterResourceUpload(
                    articleChangeRequestWithAttachments, uploadResults);
            return uploadResults;
        } finally {
            clearLocalResources(resources);
        }
    }

    private ResourceUploadResults uploadArticleResources(
            ResourceEntrySet resources,
            boolean allowResourceUploadFailure
    ) {
        var uploadResults = resourceService.uploadResources(resources);
        if (shouldInvalidateUpload(uploadResults, allowResourceUploadFailure)) {
            throw new ResourceUploadException(uploadResults);
        }
        return uploadResults;
    }

    private boolean shouldInvalidateUpload(
            ResourceUploadResults uploadResults,
            boolean allowResourceUploadFailure
    ) {
        return allowResourceUploadFailure ?
                uploadResults.allUploadsFailed() : uploadResults.wasUnsuccessful();
    }

    private void clearLocalResources(ResourceEntrySet resources) {
        if (resources != null) {
            resourceService.clearLocalResources(resources);
        }
    }

    private void clearRemoteResources(ResourceUploadException e) {
        var uploadResults = e.getUploadResults();
        clearRemoteResources(uploadResults);
    }

    private void clearRemoteResources(ResourceUploadResults uploadResults) {
        if (uploadResults == null) {
            return;
        }
        var deleteUrls = getDeleteUrls(uploadResults);
        resourceService.clearRemoteResources(deleteUrls)
                .onFailure(ex -> log.error(ex.getMessage(), ex));
    }

    private Set<String> getDeleteUrls(ResourceUploadResults uploadResults) {
        return uploadResults
                .successfulFileUploads()
                .stream()
                .map(SuccessfulFileUpload::getUploadUrl)
                .collect(Collectors.toSet());
    }
}
