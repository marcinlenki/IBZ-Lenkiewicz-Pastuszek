package com.lenkiewiczmarcin.articlesbackend.data.domain.articles;

import com.lenkiewiczmarcin.articlesbackend.data.domain.DatabaseEntity;
import com.lenkiewiczmarcin.articlesbackend.data.domain.ModelUtils;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.NaturalId;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;

@Table(name = "article_category")
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class Category implements DatabaseEntity {

    // DATABASE FIELDS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NaturalId
    private String name;

    // DATABASE RELATIONSHIPS

    @OneToMany(mappedBy = Subcategory_.CATEGORY)
    @ToString.Exclude
    private Set<Subcategory> subcategories;

    public Set<Subcategory> getSubcategories() {
        return Objects.requireNonNullElse(subcategories, Collections.emptySet());
    }

    @Override
    public Integer getIdentifier() {
        return id;
    }

    @Override
    public Boolean hasNaturalIdentifier() {
        return true;
    }

    @Override
    public String getNaturalIdentifier() {
        return name;
    }

    @Override
    public final boolean equals(Object other) {
        return ModelUtils.testEqualityByNaturalKey(this, other);
    }

    @Override
    public final int hashCode() {
        return ModelUtils.calculateHashcodeByNaturalId(this);
    }

}
