package com.lenkiewiczmarcin.articlesbackend.utils;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.List;

public final class PageUtils {
    private PageUtils() {}

    public static <T> ResponsePage<T> from(
            List<T> content,
            Pageable pageable,
            long totalElements,
            long totalPages
    ) {
        return map(new PageImpl<>(content, pageable, totalElements), totalPages);
    }

    private static <T> ResponsePage<T> map(PageImpl<T> page, long totalPages) {
        return new ResponsePage<>(
                page.getContent(),
                totalPages,
                new ResponsePage.DefaultPageable(
                        page.getNumber(),
                        page.getSize(),
                        page.getNumberOfElements(),
                        page.isFirst(),
                        page.isLast())
        );
    }
}
