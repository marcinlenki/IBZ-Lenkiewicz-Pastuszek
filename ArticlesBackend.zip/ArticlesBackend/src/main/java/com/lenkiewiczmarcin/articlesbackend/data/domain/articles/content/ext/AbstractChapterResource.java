package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.lang.NonNull;

import java.io.Serializable;

/**
 * Base class for all resources contained within the article.
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
        // register new types here
        @JsonSubTypes.Type(value = ImageResource.class, name = ChapterResourceType.IMAGE_VALUE),
        @JsonSubTypes.Type(value = TwitterPostResource.class, name = ChapterResourceType.TWITTER_POST_VALUE)
})
public abstract class AbstractChapterResource implements Serializable {

    /**
     * Indicates if resource lifecycle should be handled (uploaded and deleted) by the application.
     * For example removing all chapter images should be handled by the application when referenced chapter is deleted.
     * Another example would be if the resource is a twitter post. The lifecycle of a twitter post is completely separated
     * from the lifecycle of the referenced chapter.
     *
     * @return true if upload and deletion of referenced resource should be handled, false otherwise.
     */
    public boolean shouldBeHandled() {
        return false;
    }

    /**
     * Sets upload url.
     * @param url upload url for the resource.
     */
    @JsonIgnore
    public void setUploadUrl(@NonNull String url) {
        throw new UnsupportedOperationException("This resource doesn't support additional upload!");
    }

    /**
     * Retrieves upload url.
     */
    @JsonIgnore
    public String getUploadUrl() {
        throw new UnsupportedOperationException("This resource doesn't support additional upload!");
    }
}
