package com.lenkiewiczmarcin.articlesbackend.logic.common.exceptions;

import java.io.IOException;

public class WrappedIoException extends RuntimeException {
    private static final String MESSAGE = "Wrapped IO exception";

    public WrappedIoException(IOException originalException) {
        super(MESSAGE, originalException);
    }
}
