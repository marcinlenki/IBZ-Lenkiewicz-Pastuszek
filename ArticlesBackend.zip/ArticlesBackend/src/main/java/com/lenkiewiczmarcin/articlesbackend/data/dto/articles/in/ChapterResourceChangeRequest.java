package com.lenkiewiczmarcin.articlesbackend.data.dto.articles.in;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext.AbstractChapterResource;
import jakarta.validation.constraints.*;

public record ChapterResourceChangeRequest(
        @Min(value = 1, message = "Chapter resource id must be greater than 0")
        Integer id,
        @NotBlank @Size(max = 32, message = "Chapter resource title must be over 32 characters long")
        String description,
        @Size(message = "Invalid attachment size")
        String attachment,
        @NotNull(message = "Chapter resource content cannot be null")
        AbstractChapterResource content
) {
}
