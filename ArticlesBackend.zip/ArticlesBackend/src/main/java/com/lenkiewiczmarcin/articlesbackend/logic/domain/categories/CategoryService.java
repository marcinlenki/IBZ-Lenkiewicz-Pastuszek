package com.lenkiewiczmarcin.articlesbackend.logic.domain.categories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Category;
import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.CategoryDto;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.CategoryRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.mapping.mapstruct.CategoryMapper;
import com.lenkiewiczmarcin.articlesbackend.utils.PageUtils;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {
    private final CategoryRepository repository;
    private final CategoryMapper mapper;

    @Transactional
    public ResponsePage<CategoryDto> getCategories(Pageable pageable) {
        var page = repository.findAll(pageable);
        var categories = mapPagedResponse(page);
        return PageUtils.from(categories, pageable, page.getTotalElements(), page.getTotalPages());
    }

    @Transactional
    public CategoryDto getCategory(@NonNull Integer id) {
        return mapper.convertCategoryToCategoryDto(repository.findByIdOrThrow(id));
    }

    private List<CategoryDto> mapPagedResponse(Page<Category> page) {
        return page
                .stream()
                .map(mapper::convertCategoryToCategoryDto)
                .toList();
    }
}
