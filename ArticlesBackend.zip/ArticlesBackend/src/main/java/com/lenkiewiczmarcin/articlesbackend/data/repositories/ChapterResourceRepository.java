package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ChapterResource;

public interface ChapterResourceRepository extends DataRepository<ChapterResource> {
}
