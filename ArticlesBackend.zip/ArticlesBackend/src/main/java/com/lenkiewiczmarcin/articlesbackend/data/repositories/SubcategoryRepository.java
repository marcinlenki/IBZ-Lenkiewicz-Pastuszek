package com.lenkiewiczmarcin.articlesbackend.data.repositories;

import com.lenkiewiczmarcin.articlesbackend.data.domain.articles.Subcategory;

public interface SubcategoryRepository extends DataRepository<Subcategory> {
    boolean existsByName(String name);

}