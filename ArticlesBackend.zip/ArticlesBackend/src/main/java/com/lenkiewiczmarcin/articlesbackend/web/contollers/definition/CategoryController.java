package com.lenkiewiczmarcin.articlesbackend.web.contollers.definition;

import com.lenkiewiczmarcin.articlesbackend.data.dto.ResponsePage;
import com.lenkiewiczmarcin.articlesbackend.data.dto.categories.out.CategoryDto;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import static com.lenkiewiczmarcin.articlesbackend.web.contollers.ApiPaths.CATEGORIES;

@RequestMapping(CATEGORIES)
public interface CategoryController {
    @GetMapping
    ResponsePage<CategoryDto> getCategories(Pageable pageable);

    @GetMapping("{id}")
    CategoryDto getCategory(@PathVariable Integer id);
}
