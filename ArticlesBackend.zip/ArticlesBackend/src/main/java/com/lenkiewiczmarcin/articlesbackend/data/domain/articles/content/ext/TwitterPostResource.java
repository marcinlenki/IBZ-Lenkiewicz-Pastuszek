package com.lenkiewiczmarcin.articlesbackend.data.domain.articles.content.ext;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class TwitterPostResource extends AbstractChapterResource {
    private Long tweetId;
    private Integer widthInPixels = 325;
    private String theme = "dark";
}
