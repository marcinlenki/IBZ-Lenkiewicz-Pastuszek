package com.lenkiewiczmarcin.articlesbackend.web.filters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.Role;
import com.lenkiewiczmarcin.articlesbackend.data.domain.users.User;
import com.lenkiewiczmarcin.articlesbackend.data.repositories.UserRepository;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.JwtService;
import com.lenkiewiczmarcin.articlesbackend.logic.auth.WebContext;
import com.lenkiewiczmarcin.articlesbackend.logic.domain.users.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@SpringJUnitConfig
class JwtAuthFilterTest {
    private static final String AUTH_HEADER = "Authorization";

    @MockBean
    private JwtService jwtService;

    @MockBean
    private UserRepository userRepository;

    private JwtAuthFilter uut;

    @BeforeEach
    void setUp() {
        var objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        var userService = new UserService(userRepository, null);
        uut = new JwtAuthFilter(jwtService, userService, objectMapper);
    }

    @Test
    @DisplayName("Should not filter when authentication is present")
    void shouldNotFilterWhenAuthenticationIsPresent() {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            webContext.when(WebContext::getAuthentication).thenReturn(Optional.of(new Object()));
            var mockRequest = mock(HttpServletRequest.class);

            // when
            var result = uut.shouldNotFilter(mockRequest);

            // then
            assertTrue(result);
        }
    }

    @Test
    @DisplayName("Should not filter when auth header is missing")
    void shouldNotFilterWhenAuthHeaderIsMissing() {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            webContext.when(WebContext::getAuthentication).thenReturn(empty());
            var mockRequest = mock(HttpServletRequest.class);
            when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(null);

            // when
            var result = uut.shouldNotFilter(mockRequest);

            // then
            assertTrue(result);
            verify(mockRequest).getHeader(AUTH_HEADER);
        }
    }

    @Test
    @DisplayName("Should not filter when jwt is missing")
    void shouldNotFilterWhenJwtIsMissing() {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            webContext.when(WebContext::getAuthentication).thenReturn(empty());
            var mockRequest = mock(HttpServletRequest.class);
            var notJwt = "not jwt";
            when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(notJwt);

            // when
            var result = uut.shouldNotFilter(mockRequest);

            // then
            assertTrue(result);
            verify(mockRequest).getHeader(AUTH_HEADER);
        }
    }

    @Test
    @DisplayName("Should filter when authentication is not present and jwt is included")
    void shouldFilterWhenAuthenticationIsNotPresentAndJwtIsIncluded() {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            webContext.when(WebContext::getAuthentication).thenReturn(empty());
            var mockRequest = mock(HttpServletRequest.class);
            var jwt = "Bearer token jwt";
            when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(jwt);

            // when
            var result = uut.shouldNotFilter(mockRequest);

            // then
            assertFalse(result);
            verify(mockRequest).getHeader(AUTH_HEADER);
        }
    }

    @Test
    @DisplayName("Should not set authentication when jwt doesn't contain subject")
    void shouldNotSetAuthenticationWhenJwtDoesntContainSubject() throws ServletException, IOException {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            var mockRequest = mock(HttpServletRequest.class);
            var mockResponse = mock(HttpServletResponse.class);
            var mockFilterChain = mock(FilterChain.class);

            var jwt = "this is a jwt token";
            when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(jwt);

            when(jwtService.getUsername(jwt)).thenReturn(empty());

            // when
            uut.doFilterInternal(mockRequest, mockResponse, mockFilterChain);

            // then
            webContext.verifyNoInteractions();
            verify(mockFilterChain).doFilter(mockRequest, mockResponse);
        }
    }

    @Test
    @DisplayName("Should not set authentication when subject is no longer in system")
    void shouldNotSetAuthenticationWhenSubjectIsNoLongerInSystem() throws ServletException, IOException {
        try (var webContext = Mockito.mockStatic(WebContext.class)) {
            // given
            var mockRequest = mock(HttpServletRequest.class);
            var mockFilterChain = mock(FilterChain.class);
            var mockResponse = mock(HttpServletResponse.class);
            var mockWriter = mock(PrintWriter.class);
            when(mockResponse.getWriter()).thenReturn(mockWriter);

            var jwt = "this is a jwt token";
            when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(jwt);

            var username = "username";
            when(jwtService.getUsername(any())).thenReturn(of(username));
            when(userRepository.findByEmail(any())).thenReturn(empty());

            // when
            uut.doFilterInternal(mockRequest, mockResponse, mockFilterChain);

            // then
            webContext.verifyNoInteractions();
            verifyNoInteractions(mockFilterChain);
            verify(mockResponse).setContentType(APPLICATION_JSON_VALUE);
            verify(mockResponse).setStatus(BAD_REQUEST.value());
            verify(mockWriter).println(anyString());
        }
    }


    @Test
    @DisplayName("Should set authentication")
    void shouldSetAuthentication() throws ServletException, IOException {
        // given
        SecurityContextHolder.createEmptyContext();
        var mockRequest = mock(HttpServletRequest.class);
        var mockFilterChain = mock(FilterChain.class);
        var mockResponse = mock(HttpServletResponse.class);

        var jwt = "this is a jwt token";
        when(mockRequest.getHeader(AUTH_HEADER)).thenReturn(jwt);

        var username = "username";
        when(jwtService.getUsername(any())).thenReturn(of(username));

        var role = "AUTHOR";
        var user = User
                .builder()
                .email(username)
                .role(Role.builder().name(role).build())
                .build();

        when(userRepository.findByEmail(any())).thenReturn(of(user));

        // when
        uut.doFilterInternal(mockRequest, mockResponse, mockFilterChain);

        // then
        var currentUser = WebContext.currentUser();
        assertNotNull(currentUser);
        assertEquals(username, currentUser.getUsername());
        assertEquals(role, currentUser.getRoleName());
        verify(mockFilterChain).doFilter(mockRequest, mockResponse);
    }
}