package com.lenkiewiczmarcin.articlesbackend.web.contollers.implementation;

import com.lenkiewiczmarcin.articlesbackend.utils.Time;
import com.lenkiewiczmarcin.articlesbackend.utils.UuidGenerator;
import com.lenkiewiczmarcin.articlesbackend.web.contollers.ApiPaths;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.junit.jupiter.EnabledIf;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;
import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.time.LocalDateTime;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.testcontainers.containers.localstack.LocalStackContainer.Service.S3;


@SpringBootTest
@EnabledIf(expression = "#{environment['spring.profiles.active'] == 'integration_test'}")
@ActiveProfiles("integration_test")
@Testcontainers(disabledWithoutDocker = true)
@Transactional
class ArticleControllerImplTest {
    // test suite setup
    // --
    private static final LocalDateTime ARTICLE_CREATED_TS = LocalDateTime.of(2023, 11, 27, 11, 16);
    private static final String BUCKET_NAME = "test-bucket";
    private static final String TEMP_RESOURCE_DIR = "temp-resource-dir";
    private static final String TEMP_RESOURCE_NAME = "temp-resource";

    // used to create local instance of S3 service
    @Container
    static LocalStackContainer localstack = new LocalStackContainer(
            DockerImageName.parse("localstack/localstack:0.11.3")).withServices(S3);

    @DynamicPropertySource
    static void overrideProperties(DynamicPropertyRegistry registry) {
        // override properties to use localstack instead of real AWS
        registry.add("s3.bucket.name", () -> BUCKET_NAME);
        registry.add("s3.region.name", localstack::getRegion);
        registry.add("s3.url", () -> localstack.getEndpointOverride(S3).toString());
        registry.add("access.key.id", localstack::getAccessKey);
        registry.add("access.key.secret", localstack::getSecretKey);
        registry.add("jasypt.encryptor.password", () -> "dummy");
        registry.add("articles.uploads.directory", () -> TEMP_RESOURCE_DIR);
    }

    @BeforeAll
    static void beforeAll() throws IOException, InterruptedException {
        // create required bucket to store resources
        localstack.execInContainer("awslocal", "s3", "mb", "s3://" + BUCKET_NAME);
    }

    @AfterAll
    static void afterAll() throws IOException {
        FileUtils.deleteDirectory(new File(TEMP_RESOURCE_DIR));
    }

    // test cases setup
    // --
    private MockMvc mockMvc;

    @BeforeEach
    public void setUp(WebApplicationContext webApplicationContext) {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @AfterEach
    void tearDown() throws IOException {
        FileUtils.cleanDirectory(new File(TEMP_RESOURCE_DIR));
    }

    // tests
    // --
    @Test
    @WithMockAuthor
    void shouldCreateNewArticle() throws Exception {
        var snippetsDir = "create-simple";
        try (var timeUtil = Mockito.mockStatic(Time.class)) {
            timeUtil.when(Time::currentTime).thenReturn(ARTICLE_CREATED_TS);
            mockMvc.perform(MockMvcRequestBuilders
                        .multipart(getArticlesPath())
                        .file(getRequestFromJson(snippetsDir))
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                    )
                    .andExpect(status().isCreated())
                    .andExpect(content().json(getExpectedJson(snippetsDir)))
                    .andReturn();
        }
    }

    @Test
    @WithMockAuthor
    void shouldUpdateArticleWithNewResources() throws Exception {
        // define test data
        var snippetsDir = "update-with-resources";
        var mockFileContent = "caracal";

        // perform test
        mockMvc.perform(MockMvcRequestBuilders
                        .multipart(HttpMethod.PUT, getArticlesPath(1))  // perform PUT request to /articles/1 endpoint
                        .file(getRequestFromJson(snippetsDir))                  // with request body from snippets directory
                        .file(new MockMultipartFile(                            // and with new image resource
                                "files",
                                "caracal_image.png",
                                MediaType.IMAGE_PNG_VALUE,
                                mockFileContent.getBytes())
                        )
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                )
                .andExpect(status().isOk())                                     // expect 200 OK when article is updated
                .andDo(ignored -> {                                             // and resource is uploaded to S3
                    var filename = String.format("%s.%s", TEMP_RESOURCE_NAME, "png");
                    var fileContent = localstack.execInContainer(
                            "awslocal", "s3", "cp", "s3://" + BUCKET_NAME + "/" + filename, "-");
                    if (!fileContent.getStdout().equals(mockFileContent)) {
                        throw new AssertionError("File content is not equal to '" + mockFileContent + "'");
                    }
                })
                .andReturn();
    }

    private MockMultipartFile getRequestFromJson(String directory) {
        try {
            var separator = FileSystems.getDefault().getSeparator();
            var path = String.join(separator, "snippets", "articles", directory, "request.json");
            var body = new ClassPathResource(path).getContentAsByteArray();
            return new MockMultipartFile("article", directory, MediaType.APPLICATION_JSON_VALUE, body);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String getArticlesPath() {
        return "/" + ApiPaths.ARTICLES;
    }

    private String getArticlesPath(int articleId) {
        return "/" + ApiPaths.ARTICLES + "/" + articleId;
    }

    private String getExpectedJson(String directory) {
        var separator = FileSystems.getDefault().getSeparator();
        var path = String.join(separator, "snippets", "articles", directory, "response.json");
        try {
            return new ClassPathResource(path).getContentAsString(Charset.defaultCharset());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @TestConfiguration
    public static class TestConfig {
        @Bean
        @Primary
        public UuidGenerator uuidGenerator() {
            var generator = Mockito.mock(UuidGenerator.class);
            when(generator.createUUID()).thenReturn(TEMP_RESOURCE_NAME);
            return generator;
        }
    }
}

@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@WithUserDetails("jakub_autor@rg.com")
@interface WithMockAuthor {}
