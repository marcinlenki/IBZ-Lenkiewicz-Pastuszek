#! /bin/zsh

echo "[INFO] BUILDING EXECUTABLES"
gradle -p .. --build-cache clean check assemble >> /dev/null && echo "[INFO] BUILD SUCCESSFUL" || echo "[ERROR] BUILD FAILED"

echo "[INFO] STARTING STACK"
docker compose -p "digital-newspaper" up --build --wait && echo "[INFO] STACK STARTED" || echo "[ERROR] STACK FAILED TO START"
