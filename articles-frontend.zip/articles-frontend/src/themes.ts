import {createTheme} from "@mui/material";

export const globalTheme = createTheme({
    spacing: 8
})

export const publicTheme = createTheme(globalTheme, {
    ...globalTheme,
    palette: {},
    typography: {
        fontFamily: "'Playfair Display', serif"
    }
})

export const protectedTheme = createTheme({
    ...globalTheme
    // palette: {
    // },
    // typography: {
    //     fontFamily: "'Playfair Display', serif"
    // }

})

export const articleStyling = createTheme(publicTheme, {
    ...publicTheme,
    components: {
        MuiCard: {
            styleOverrides: {
                root: {
                    maxWidth: 800,
                    margin: 'auto',
                    marginBottom: globalTheme.spacing(4),
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                    borderRadius: 12,
                    overflow: 'hidden',
                    fontFamily: 'Playfair Display, serif',
                },
            },
        },
        MuiCardMedia: {
            styleOverrides: {
                root: {
                    height: 300,
                    objectFit: 'cover',
                },
            },
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    marginRight: globalTheme.spacing(1),
                    marginBottom: globalTheme.spacing(1),
                },
            },
        }
    }
});

export {}