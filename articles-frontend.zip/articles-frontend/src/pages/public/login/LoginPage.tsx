import * as React from 'react';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import loginPicture from "../../../assets/login-page-image.jpg";
import {AuthenticationRequest} from "../../../middleware/model";
import {useLogin} from "../../../hooks/authHooks";
import {LoadingButton} from '@mui/lab';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import IconButton from "@mui/material/IconButton";
import {useNavigate} from "react-router-dom";

export default function LoginPage() {
    const navigate = useNavigate()
    const loginAction = useLogin()

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        const authRequest: AuthenticationRequest = {
            email: data.get('email') as string,
            password: data.get('password') as string
        }
        loginAction.mutate(authRequest)
    };

    return (
        <Grid container component="main" sx={{height: '100vh'}}>
            <Grid
                item
                xs={false}
                sm={4}
                md={7}
                sx={{
                    backgroundImage: 'url(' + loginPicture + ')',
                    backgroundRepeat: 'no-repeat',
                    backgroundColor: (t) =>
                        t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                }}
            />

            <Grid item container xs={12} sm={8} md={5} component={Paper} elevation={6} square justifyContent={"center"}
                  alignItems={"center"}>
                <Box
                    component={Paper} elevation={1}
                    bgcolor={"#fafafa"}
                    padding={5}
                    width={"80%"}
                    sx={{
                        my: 8,
                        mx: 4,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                    }}
                >
                    <Grid item alignSelf={"flex-start"}>
                        <IconButton
                            onClick={() => {
                                navigate('/', {replace: true, relative: "path"})
                            }}
                        >
                            <KeyboardBackspaceIcon fontSize={"large"}/>
                        </IconButton>
                    </Grid>

                    <Typography component="h1" variant="h4">
                        Logowanie
                    </Typography>
                    <Box component="form" noValidate onSubmit={handleSubmit} sx={{mt: 3}}>
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            id="email"
                            label="Adres email"
                            name="email"
                            autoComplete="email"
                            autoFocus
                        />
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            name="password"
                            label="Hasło"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                        />
                        <LoadingButton
                            loading={loginAction.isLoading}
                            type='submit'
                            variant="contained"
                            fullWidth
                            sx={{
                                mt: 3,
                                mb: 2,
                                color: 'white',
                                fontSize: '18px',
                                textTransform: 'none',
                                padding: '4px 24px',
                                borderRadius: '8px'
                            }}
                        >
                            Zaloguj
                        </LoadingButton>
                        <Grid container justifyContent={"center"}>
                            <Typography variant="body2">
                                {"Nie masz jeszcze konta? "}
                                {/*TODO: Create and link to register page*/}
                                <Link href="#" variant="body2">
                                    Zarejestruj się
                                </Link>
                            </Typography>
                        </Grid>
                    </Box>
                </Box>
            </Grid>
        </Grid>
    );
}
