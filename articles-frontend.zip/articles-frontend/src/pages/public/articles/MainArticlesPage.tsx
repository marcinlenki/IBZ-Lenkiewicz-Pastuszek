import React, {useState} from 'react';
import {ArticlesFilterParams, ArticlesSort, useGetCategories, useGetMainPage} from "../../../hooks/articleHooks";
import {Divider, Stack} from "@mui/material";
import LoadingPage from "../../../components/common/LoadingPage";
import {getContent} from "../../../utils/modelUtils";
import ArticleThumbnail from "../../../components/public/ArticleThumbnail";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import {Pagination} from "@mui/lab";
import Box from "@mui/material/Box";
import {useSearchParams} from "react-router-dom";
import {ArticleResponse} from "../../../middleware/model";

const ARTICLES_DATE_SORT: ArticlesSort = {
    field: "createdTimestamp,desc"
}


const MainArticlesPage = () => {
    const [params, _] = useSearchParams()
    const categoryId = params.get('category_id')
    const subcategoryId = params.get('subcategory_id')
    const tags = params.get('tags')

    const [page, setPage] = useState(1);

    const articles = useGetMainPage({
        pageRequest: {number: page - 1},
        sort: ARTICLES_DATE_SORT,
        filterParams: createFilterParams()
    });


    if (articles.isLoading) {
        return <LoadingPage/>
    }

    const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
        setPage(value);
    };

    function createFilterParams(): ArticlesFilterParams {
        if (tags) {
            return {
                tags: tags.split(',')
            }
        }

        if (subcategoryId) {
            return {
                subcategoryId: parseInt(subcategoryId)
            }
        }

        if (categoryId) {
            return {
                categoryId: parseInt(categoryId)
            }
        }

        return {}
    }


    return (
        <Stack height={"100%"} marginX={8} mb={6} sx={{
            margin: "0 auto",
            width: '1300px',
        }}>
            <Headline categoryId={categoryId!} subcategoryId={subcategoryId!} tags={tags}/>
            <ArticleThumbnailList articles={getContent(articles)}/>

            {getContent(articles).length != 0 && (
                <Box alignSelf={"center"} mt={'auto'}>
                    <Pagination
                        shape={"rounded"}
                        count={articles.data!.totalPages}
                        page={page}
                        onChange={handleChange}
                    />
                </Box>
            )}
        </Stack>
    );
};

export default MainArticlesPage;


const ArticleThumbnailList = ({articles}: { articles: ArticleResponse[] }) => {
    return (
        <Grid container rowGap={2} mb={5}>
            {articles.map(article => (
                <Grid key={article.id} container item sm={12} md={4} justifyContent={"center"} alignItems={"flex-end"}>
                    <ArticleThumbnail
                        key={article.id}
                        articleId={article.id}
                        articleTitle={article.title}
                        thumbnailUrl={article.thumbnailUrl}
                        author={article.author}
                        createdAt={article.createdTimestamp}
                        introduction={article.introduction}
                    />
                </Grid>
            ))}
        </Grid>
    );
}

type HeadlineProps = {
    categoryId?: number | string,
    subcategoryId?: number | string
    tags: string | null
}

const Headline = ({categoryId, subcategoryId, tags}: HeadlineProps) => {
    const categories = useGetCategories()

    if (categories.isLoading) {
        return <LoadingPage/>
    }

    function getCategoryName(): string {
        return getContent(categories).find(category => category.id == categoryId)?.name!
    }

    function getSubcategoryName(): string {
        return getContent(categories)
            .flatMap(c => c.subcategories)
            .find(subcategory => subcategory.id == subcategoryId)?.name!
    }

    return (
        <>
            {!categoryId && !subcategoryId && !tags && (
                <Typography variant='h4' mb={5}>Aktualności</Typography>
            )}

            {tags && (
                <Typography variant='h4' mb={5}>Wyniki wyszukiwań...</Typography>
            )}

            {categoryId && (
                <Typography variant='h4' mb={5}>Przeglądasz artykuły z kategorii {getCategoryName()}</Typography>
            )}

            {subcategoryId && (
                <Typography variant='h4' mb={5}>Przeglądasz artykuły z podkategorii {getSubcategoryName()}</Typography>
            )}
        </>
    );
}