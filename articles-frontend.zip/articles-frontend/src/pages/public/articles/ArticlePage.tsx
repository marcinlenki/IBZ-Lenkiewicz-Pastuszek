import React, {useEffect} from 'react';
import {Divider, Stack, Typography,} from '@mui/material';
import {ArticleResponse, ChapterResponse} from "../../../middleware/model";
import {useGetArticle} from "../../../hooks/articleHooks";
import {useParams} from "react-router-dom";
import LoadingPage from "../../../components/common/LoadingPage";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Markdown from "react-markdown";


const ArticleHeader: React.FC<{
    title: string;
    introduction: string,
    thumbnail: string;
    author: string;
    createdTimestamp: Date
}> =
    ({title, introduction, thumbnail, author, createdTimestamp,}) => {
        return (
            <Stack>
                <Typography mb={2} variant="h3">{title}</Typography>
                <Typography paragraph><i>{introduction}</i></Typography>
                <Divider sx={{mb: 2}}/>
                <Typography mb={4} alignSelf={"center"}><img width={500} height={"auto"} src={thumbnail}
                                                             alt={introduction}/></Typography>
                <Typography variant="subtitle1" paragraph>
                    <b>Autorem tekstu jest <u>{author}</u></b>
                </Typography>
                <Divider sx={{mb: 2}}/>
            </Stack>
        );
    };

const ChapterList: React.FC<{ chapters: ChapterResponse[] }> = ({chapters}) => {
    return (
        <Stack>
            {chapters.map((chapter, index) => (
                <Stack key={chapter.id}>
                    {chapter.title ? (<Typography variant="h5">{chapter.title}</Typography>) : <Box></Box>}
                    <Box mb={2} sx={{fontSize: "16px", textShadow: "0 0 1px transparent"}}>
                        <Markdown skipHtml={true}>{chapter.text}</Markdown>
                        <Typography mb={3}/>

                        {chapter.chapterResources.map((resource, index) => (
                            <Stack key={index} direction={"column"} alignItems={"center"} gap={2}>
                                <img width={500} height={"auto"} src={resource.content.url} alt={resource.description}/>
                                <Typography paragraph>{resource.description}</Typography>
                            </Stack>
                        ))}
                    </Box>
                </Stack>
            ))}
        </Stack>
    );
};

export const ArticleDisplay: React.FC<{ article: ArticleResponse }> = ({article}) => {
    useEffect(() => {
        window.scrollTo(0, 177)
    }, [])

    const {
        title,
        author,
        thumbnailUrl,
        introduction,
        chapters,
        createdTimestamp,
    } = article;

    return (
        <Stack width={'700px'} alignItems={"center"} justifyContent={"center"} gap={2}>
            <ArticleHeader
                title={title}
                introduction={introduction}
                thumbnail={thumbnailUrl}
                author={author.name}
                createdTimestamp={createdTimestamp}
            />
            <ChapterList chapters={chapters}/>
        </Stack>
    );
};

export const ArticlePage = () => {
    const {articleId} = useParams()
    const article = useGetArticle({id: articleId})

    if (article.isLoading) {
        return <LoadingPage/>
    }

    return (
        <Grid container justifyContent={"center"} mt={3}>
            <ArticleDisplay article={article.data!}/>
        </Grid>
    );
};

export default ArticlePage;
