import React from 'react';
import {useNavigate, useSearchParams} from "react-router-dom";
import {useGetArticle, useGetCategories, useGetTags} from "../../hooks/articleHooks";
import ArticleEditView from "../../components/protected/article-edit/ArticleEditView";
import {getContent} from "../../utils/modelUtils";
import LoadingPage from "../../components/common/LoadingPage";
import {capitalize} from "../../utils/stringUtils";

const ArticleEditPage = () => {
    const navigate = useNavigate()

    const [params, _] = useSearchParams()
    const articleId = params.get('article_id')
    const categories = useGetCategories()
    const tags = useGetTags()
    const article = useGetArticle({enabled: articleId != null, id: articleId!})

    if (article.isLoading || tags.isLoading || categories.isLoading) {
        return <LoadingPage/>
    }

    if (article.isError || tags.isError || categories.isError) {
        navigate('/dashboard/articles')
    }

    return (
        <ArticleEditView
            categories={getContent(categories)}
            tags={getContent(tags).map(t => capitalize(t.name))}
            article={article.data}
        />
    );
};

export default ArticleEditPage;