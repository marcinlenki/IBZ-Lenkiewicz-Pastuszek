import React from 'react';
import Box from "@mui/material/Box";
import {useNavigate} from "react-router-dom";
import {LoadingButton} from "@mui/lab";
import {ArticlesFilterParams, useGetArticles, usePickForReview} from "../../hooks/articleHooks";
import {getUser} from "../../middleware/storage";
import {Role} from "../../middleware/auth";
import {getContent} from "../../utils/modelUtils";
import ArticleList from "../../components/protected/article-list/ArticleList";
import {ArticleResponse} from "../../middleware/model";

export enum Statuses {
    CREATED = 1,
    WAITING_FOR_REVIEW = 2,
    IN_REVIEW = 3
}

const ArticleListPage = () => {
    const navigate = useNavigate()
    const currentUser = getUser()!
    const isAuthor = currentUser.role === Role.AUTHOR

    const articles = useGetArticles(getQueryParams())

    const pickForReviewAction = usePickForReview()

    function getQueryParams(): ArticlesFilterParams {
        return {
            authorId: isAuthor ? currentUser.id : undefined,
            editorId: !isAuthor ? currentUser.id : undefined,
            statusId: isAuthor ?
                [Statuses.CREATED, Statuses.WAITING_FOR_REVIEW, Statuses.IN_REVIEW] :
                [Statuses.WAITING_FOR_REVIEW, Statuses.IN_REVIEW]
        }
    }

    function editArticle(article: ArticleResponse) {
        navigate(`/dashboard/manage/?article_id=${article.id}`)
    }


    if (articles.isLoading) {
        return <LoadingButton/>
    }

    return (
        <Box
            width={'50%'}
            height={'fit-content'}
            display={'flex'}
            flexDirection={'column'}
            margin={'0 25%'}
            gap={'20px'}
        >
            {
                isAuthor ?
                    <LoadingButton
                        variant='contained'
                        sx={{
                            color: 'white',
                            textTransform: 'none',
                            fontWeight: '700',
                            fontSize: '25px',
                            width: 'fit-content',
                            alignSelf: 'center',
                            marginBottom: '30px'
                        }}
                        onClick={() => {
                            navigate(`/dashboard/manage`)
                        }}
                    >
                        Utwórz nowy artykuł
                    </LoadingButton>
                    : null
            }
            {isAuthor && (
                <ArticleList
                    articles={getContent(articles).filter(a => a.status.id === Statuses.CREATED)}
                    onClick={editArticle}
                    listTitle={'Artykuły w trakcie tworzenia'}
                    actionName={'Edytuj artykuł'}
                />
            )}

            <ArticleList
                articles={getContent(articles).filter(a => a.status.id === Statuses.WAITING_FOR_REVIEW)}
                onClick={isAuthor ? editArticle : (a) => pickForReviewAction.mutate(a.id)}
                listTitle={'Czekające na recenzję'}
                actionName={isAuthor ? 'Edytuj artykuł' : 'Pobierz do recenzji'}
            />

            <ArticleList
                articles={getContent(articles).filter(a => a.status.id === Statuses.IN_REVIEW)}
                onClick={editArticle}
                listTitle={'W trakcie redakcji'}
                actionName={'Edytuj artykuł'}
            />
        </Box>
    );
};

export default ArticleListPage;