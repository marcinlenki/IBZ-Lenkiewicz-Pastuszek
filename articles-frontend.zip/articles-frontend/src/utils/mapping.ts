import {ArticleChangeRequest, ArticleResponse, CategoryDto} from "../middleware/model";

export function empty(availableCategories: CategoryDto[]): ArticleChangeRequest {
    return {
        id: undefined,
        title: '',
        thumbnailUrl: '',
        category: {
            categoryId: availableCategories[0].id,
            subcategoryId: availableCategories[0].subcategories[0].id
        },
        tags: [],
        introduction: '',
        chapters: []
    }
}

export function fromArticleResponse(article: ArticleResponse): ArticleChangeRequest {
    return {
        id: article.id,
        title: article.title,
        thumbnailUrl: article.thumbnailUrl,
        category: {
            categoryId: article.category.id,
            subcategoryId: article.category.subcategory.id
        },
        tags: article.tags,
        introduction: article.introduction,
        chapters: article.chapters
            .map(chapter => (
                {
                    id: chapter.id,
                    title: chapter.title,
                    text: chapter.text,
                    chapterResources: chapter.chapterResources
                        .map(resource => (
                            {
                                id: resource.id,
                                description: resource.description,
                                content: resource.content
                            }
                        ))
                }
            ))
    }
}

