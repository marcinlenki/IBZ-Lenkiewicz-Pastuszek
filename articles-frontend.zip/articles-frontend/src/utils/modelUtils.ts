import {UseQueryResult} from "react-query";
import {ResponsePage} from "../middleware/model";

// get raw content from paged response
export function getContent<T>(queryRes: UseQueryResult<ResponsePage<T>>) {
    return queryRes.data?.content ?? []
}

export function getExceptionMessage(exceptionResponse: any) {
    return exceptionResponse?.response?.data?.message ?? "Wystąpił błąd"
}