import React from 'react';
import {QueryClient, QueryClientProvider} from "react-query";
import {RoutingTable} from "./RoutingTable";
import {Toaster} from "react-hot-toast";

function App() {
    const queryClient = new QueryClient()

    return (
        <>
            <QueryClientProvider client={queryClient}>
                <Toaster position='top-left'/>
                <RoutingTable/>
            </QueryClientProvider>
        </>
    );
}

export default App;
