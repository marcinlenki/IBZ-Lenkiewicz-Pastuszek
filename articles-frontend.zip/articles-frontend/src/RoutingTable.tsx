import {Route, Routes} from 'react-router-dom'
import LoginPage from "./pages/public/login/LoginPage";
import MainArticlesPage from "./pages/public/articles/MainArticlesPage";
import ArticleEditPage from "./pages/protected/ArticleEditPage";
import Template from "./components/common/Template";
import Layout from "./components/common/Layout";
import Public from "./components/public/Public";
import Protected from "./components/protected/Protected";
import ArticleListPage from "./pages/protected/ArticleListPage";
import React from "react";
import ArticlePage from "./pages/public/articles/ArticlePage";

export const RoutingTable = () => {
    return (
        <Routes>
            <Route path='/' element={<Layout/>}>
                <Route element={<Template/>}>

                    <Route element={<Public/>}>
                        <Route index element={<MainArticlesPage/>}/>
                        <Route path={"/read/:articleId"} element={<ArticlePage/>}/>
                    </Route>

                    <Route path='dashboard' element={<Protected/>}>
                        <Route index element={<ArticleListPage/>}/>
                        <Route path='articles' element={<ArticleListPage/>}/>
                        <Route path='manage' element={<ArticleEditPage/>}/>
                    </Route>
                </Route>

                <Route path='login' element={<LoginPage/>}/>
            </Route>
        </Routes>
    )
}