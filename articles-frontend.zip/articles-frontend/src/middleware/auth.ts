import {AuthenticationResponse} from "./model";
import {jwtDecode} from "jwt-decode";
import {getUser, setUser} from "./storage";
import {createContext} from "react";

export enum Role {
    AUTHOR = 'AUTHOR',
    EDITOR = 'EDITOR',
    ADMIN = 'ADMINISTRATOR',
    CLIENT = 'USER'
}

export const isAuthenticated = () => {
    return getUser() !== null
}

export const isEmployee = () => {
    return isAuthenticated() && getUser()!.role !== Role.CLIENT
}


export function handleAuthenticationResponse(
    data: AuthenticationResponse,
    onClient?: () => void,
    onEmployee?: () => void
) {
    const token = data.jwt
    if (!token) {
        return
    }
    const payload = jwtDecode(token) as any
    setUser({
        id: payload.id,
        email: payload.sub,
        role: payload.role,
        associatedToken: token
    })

    if (payload.role === Role.CLIENT) {
        onClient?.()
    } else {
        onEmployee?.()
    }
}
