import {Role} from "./auth";
import {createContext} from "react";

export type UserInternalDto = { id: number, email: string, role: Role, associatedToken: string }

export const getUser = () => {
    const u = sessionStorage.getItem('user')
    return u ? JSON.parse(u) as UserInternalDto : null
}

export function setUser(user: { id: number, email: string, role: string, associatedToken: string }) {
    sessionStorage.setItem('user', JSON.stringify(user))
}

export const removeUser = () => sessionStorage.removeItem('user')
