import axios from 'axios'
import axiosRetry from 'axios-retry'
import {
    ArticleChangeRequest,
    ArticleResponse,
    AuthenticationRequest,
    AuthenticationResponse,
    CategoryDto,
    ResponsePage,
    TagDto
} from "./model";
import {getUser} from "./storage";
import {ArticlesFilterParams, ArticlesSort, PageRequest} from "../hooks/articleHooks";

const getFromEnv = () => {
    if (process.env.NODE_ENV == 'production') {
        return process.env.REACT_APP_API_URL_PROD
    } else {
        return process.env.REACT_APP_API_URL_DEV
    }
}

const axiosInstance = axios.create({
    baseURL: getFromEnv()
})

axiosInstance.interceptors.response.use(
    ({data}) => data
)

axiosRetry(axiosInstance, {retries: 3, retryDelay: () => 100})

export namespace Api {
    interface RequestConfig {
        withAuth?: boolean
    }

    export function login(credentials: AuthenticationRequest): Promise<AuthenticationResponse> {
        return axiosInstance.put("/auth/login", credentials)
    }

    export function forwardArticle(article: ArticleChangeRequest, files: File[], action: string): Promise<ArticleResponse> {
        const formData = createFormData(article, files)
        return axiosInstance.put(`/articles/${article.id!}/${action}`, formData, {
            headers: {
                'Authorization': `Bearer ${getUser()?.associatedToken}`,
                'Content-Type': 'multipart/form-data'
            }
        })
    }

    export function reviewArticle(articleId: number): Promise<ArticleResponse> {
        return axiosInstance.patch(`/articles/${articleId}/review`, null, {
            headers: {
                'Authorization': `Bearer ${getUser()?.associatedToken}`
            }
        })
    }

    export function saveArticle(article: ArticleChangeRequest, files: File[]): Promise<ArticleResponse> {
        const formData = createFormData(article, files)
        return article.id ? updateArticle(article, formData) : createArticle(formData)
    }

    function updateArticle(article: ArticleChangeRequest, formData: FormData): Promise<ArticleResponse> {
        return axiosInstance.put(`/articles/${article.id!}`, formData, {
            headers: {
                'Authorization': `Bearer ${getUser()?.associatedToken}`,
                'Content-Type': 'multipart/form-data'
            }
        })
    }

    function createArticle(formData: FormData): Promise<ArticleResponse> {
        return axiosInstance.post(`/articles`, formData, {
            headers: {
                'Authorization': `Bearer ${getUser()?.associatedToken}`,
                'Content-Type': 'multipart/form-data'
            }
        })
    }

    export function deleteArticle(articleId: number): Promise<void> {
        return axiosInstance.delete(`/articles/${articleId}`, {
                headers: {
                    'Authorization': `Bearer ${getUser()?.associatedToken}`
                }
            }
        )
    }

    export async function getArticles(params?: ArticlesFilterParams, sort?: ArticlesSort, pageRequest?: PageRequest): Promise<ResponsePage<ArticleResponse>> {
        return axiosInstance.get(`/articles`, {
            headers: {
                'Authorization': `Bearer ${getUser()?.associatedToken ?? ""}`
            },
            params: {
                ...params,
                sort: sort?.field,
                page: pageRequest?.number ?? 0,
                size: pageRequest?.size ?? 10
            },
            paramsSerializer: paramsSerializer
        })
    }

    export async function getArticle(id?: string | number): Promise<ArticleResponse> {
        return get(`/articles/${id}`, {withAuth: true})
    }

    export async function getArticleCategories(): Promise<ResponsePage<CategoryDto>> {
        return get('/categories')
    }

    export async function getArticleTags(): Promise<ResponsePage<TagDto>> {
        return get('/tags')
    }

    function get<T>(url: string, config?: RequestConfig): Promise<T> {
        const auth = getUser()?.associatedToken
        if (auth) {
            const authHeader = config?.withAuth ? {
                'Authorization': `Bearer ${getUser()?.associatedToken}`
            } : {}
            return axiosInstance.get(url, {headers: {...authHeader}})

        } else {
            return axiosInstance.get(url)
        }
    }

    function createFormData(article: ArticleChangeRequest, files: File[]): FormData {
        const formData = new FormData()
        formData.append("article", new Blob([JSON.stringify(article)], {type: 'application/json'}))
        files.forEach(file => formData.append("files", file))
        return formData
    }

    const paramsSerializer = (params: Record<string, any>): string => {
        const paramArray: string[] = [];

        for (const key in params) {
            if (key == null || params[key] == null) continue;

            if (Object.hasOwn(params, key)) {
                const paramValue = params[key];
                if (Array.isArray(paramValue)) {
                    paramArray.push(`${key}=${paramValue.join(',')}`);
                } else {
                    paramArray.push(`${key}=${paramValue}`);
                }
            }
        }

        return paramArray.join('&');
    };
}