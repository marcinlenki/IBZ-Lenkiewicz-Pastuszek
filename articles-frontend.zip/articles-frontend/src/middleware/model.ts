export type ArticleChangeRequest = {
    id?: number;
    title: string;
    thumbnailUrl?: string;
    category: ArticleCategoryChangeRequest;
    tags: string[];
    introduction?: string;
    chapters: ChapterChangeRequest[];
};

export type ArticleCategoryChangeRequest = {
    categoryId: number;
    subcategoryId: number;
    name?: string;
};

export type ChapterChangeRequest = {
    id?: number;
    title: string;
    text: string;
    chapterResources: ChapterResourceChangeRequest[];
};

export type ChapterResourceChangeRequest = {
    id?: number;
    description: string;
    attachment?: string;
    content: any;
};

export type ArticleResponse = {
    id: number;
    title: string;
    author: AuthorDto;
    category: ArticleResponseCategoryDto;
    tags: string[];
    thumbnailUrl: string;
    introduction: string;
    chapters: ChapterResponse[];
    status: ArticleStatusResponse;
    createdTimestamp: Date;
};

export type AuthorDto = {
    id: number;
    name: string;
};

export type ArticleResponseCategoryDto = {
    id: number;
    name: string;
    subcategory: SubcategoryDto;
};

export type CategoryDto = {
    id: number;
    name: string;
    subcategories: SubcategoryDto[];
}

export type SubcategoryDto = {
    id: number;
    name: string;
};

export type ChapterResponse = {
    id: number;
    title: string;
    text: string;
    chapterResources: ResourceResponse[];
};

export type ResourceResponse = {
    id: number;
    description: string;
    content: any;
};

export type ArticleStatusResponse = {
    id: number;
    name: string;
};

export type TagDto = {
    id: number;
    name: string;
}

export type AuthenticationRequest = {
    email: string;
    password: string;
};

export type AuthenticationResponse = {
    jwt: string;
    refreshToken: string;
};

export type ExceptionMessage = {
    errorCode: string;
    exceptionIdentifier: string;
    message: string;
    timestamp: Date;
    exceptionItem?: any;
};

export type SimpleExceptionMessage = {
    messages: string[];
    timestamp: Date;
};

export type HealthcheckResponse = {
    message: string;
    date: Date;
};

export type ResponsePage<T> = {
    content: T[];
    totalPages: number;
    page: DefaultPageable;
};

export type DefaultPageable = {
    number: number;
    size: number;
    elements: number;
    first: boolean;
    last: boolean;
};

export {};