import {useNavigate} from "react-router-dom";
import {useMutation} from "react-query";
import {AuthenticationRequest} from "../middleware/model";
import {Api} from "../middleware/api";
import {handleAuthenticationResponse} from "../middleware/auth";
import toast from "react-hot-toast";
import {getExceptionMessage} from "../utils/modelUtils";
import login = Api.login;


export const useLogin = () => {
    const navigate = useNavigate()

    return useMutation(['login'], (data: AuthenticationRequest) => login(data), {
        onSuccess: response => {
            (handleAuthenticationResponse(response,
                () => (
                    navigate('/', {replace: true})

                ), () => (
                    navigate('/dashboard', {replace: true})
                )
            ))
        },

        onError: (err: any) => {
            toast.error(getExceptionMessage(err))
        }
    })
}
