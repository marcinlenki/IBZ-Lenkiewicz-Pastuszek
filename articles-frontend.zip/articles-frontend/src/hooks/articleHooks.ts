import {useMutation, useQuery, useQueryClient} from 'react-query'
import {Api} from "../middleware/api";
import {ArticleChangeRequest, ArticleResponse, CategoryDto, ResponsePage, TagDto} from "../middleware/model";
import toast from "react-hot-toast";
import {getExceptionMessage} from "../utils/modelUtils";
import {useNavigate} from "react-router-dom";
import {Simulate} from "react-dom/test-utils";
import getArticleCategories = Api.getArticleCategories;
import getArticle = Api.getArticle;
import getArticleTags = Api.getArticleTags;
import saveArticle = Api.saveArticle;
import forwardArticle = Api.forwardArticle;
import deleteArticle = Api.deleteArticle;
import getArticles = Api.getArticles;
import reviewArticle = Api.reviewArticle;

type Options = {
    id?: number | string,
    enabled?: boolean
}

type ArticleChangeRequestData = {
    article: ArticleChangeRequest,
    files: File[]
}

type ArticleForwardRequest = ArticleChangeRequestData & {
    action: string
}

export type ArticlesSort = {
    field: string,
    direction?: string
}

export type PageRequest = {
    number?: number
    size?: number
}

export type ArticlesFilterParams = {
    statusId?: number[] | string[],
    authorId?: number | string,
    editorId?: number | string,
    categoryId?: number | string,
    subcategoryId?: number | string
    tags?: string[]
}

export type MainPageRequestProps = {
    filterParams?: ArticlesFilterParams,
    sort?: ArticlesSort,
    pageRequest?: PageRequest
}

export const useCreateArticle = () => {
    const client = useQueryClient()
    const navigate = useNavigate()

    return useMutation(
        ['create_article'],
        (data: ArticleChangeRequestData) => saveArticle(data.article, data.files), {
            onSuccess: (response: ArticleResponse) => {
                client.invalidateQueries(['articles'])
                client.invalidateQueries(['article', response.id])
                navigate(`/dashboard/manage?article_id=${response.id}`, {replace: true})
                toast.success('Zapisano zmiany')
            },

            onError: (err: any) => {
                toast.error(getExceptionMessage(err))
            }
        })
}

export const useSaveArticle = () => {
    const client = useQueryClient()

    return useMutation(
        ['save_article'],
        async (data: ArticleChangeRequestData) => saveArticle(data.article, data.files), {
            onSuccess: (response: ArticleResponse) => {
                client.invalidateQueries(['articles'])
                // client.setQueryData(['article', response.id], response)
                // client.invalidateQueries(['article', response.id])
                window.location.reload()
                toast.success('Zapisano zmiany');
            },

            onError: (err: any) => {
                toast.error(getExceptionMessage(err))
            }
        })
}

export const useForwardArticle = () => {
    const client = useQueryClient()
    const navigate = useNavigate()

    return useMutation(['forward_article'], (data: ArticleForwardRequest) =>
        forwardArticle(data.article, data.files, data.action), {
        onSuccess: response => {
            client.invalidateQueries(['articles'])
            client.refetchQueries()
            const newStatus = response.status.name.toUpperCase()
            if (newStatus === "WAITING_FOR_REVIEW") {
                toast.success('Artykuł został przekazany do redakcji')
            } else if (newStatus === "PUBLISHED") {
                toast.success('Artykuł został opublikowany')
            }
            navigate(`/dashboard/articles`, {replace: true})
        },

        onError: (err: any) => {
            toast.error(getExceptionMessage(err))
        }
    })
}

export const usePickForReview = () => {
    const navigate = useNavigate()
    const client = useQueryClient()

    return useMutation(['pick_for_review'], (articleId: number) => reviewArticle(articleId), {
        onSuccess: response => {
            client.invalidateQueries(['articles'])
            toast.success('Artykuł został pobrany do recenzji')
            navigate(`/dashboard/manage?article_id=${response.id}`, {replace: true})
        },

        onError: (err: any) => {
            toast.error(getExceptionMessage(err))
        }
    })
}

export const useDeleteArticle = (articleId: number) => {
    const client = useQueryClient()
    const navigate = useNavigate()

    return useMutation(['delete_article', articleId], (articleId: number) => deleteArticle(articleId), {
        onSuccess: response => {
            client.invalidateQueries(['articles'])
            toast.success('Artykuł został usunięty')
            navigate('/dashboard/articles', {replace: true})
        },

        onError: (err: any) => {
            toast.error(getExceptionMessage(err))
        }
    })
}


export const useGetMainPage = ({filterParams, pageRequest, sort}: MainPageRequestProps) => {
    return useQuery<ResponsePage<ArticleResponse>>(
        ['articles', pageRequest?.number, filterParams],
        () => getArticles(filterParams, sort, pageRequest)
    )
}

export const useGetArticles = (filterParams?: ArticlesFilterParams) => {
    return useQuery<ResponsePage<ArticleResponse>>(['articles'], () => getArticles(filterParams))
}

export const useGetArticle = (options: Options) => {
    return useQuery<ArticleResponse>(['article', options.id], () => getArticle(options.id), {
        enabled: options.enabled ?? true,
        refetchOnWindowFocus: false
    })
}

export const useGetCategories = () => {
    return useQuery<ResponsePage<CategoryDto>>(['categories'], getArticleCategories)
}

export const useGetTags = () => {
    return useQuery<ResponsePage<TagDto>>(['tags'], getArticleTags)
}

