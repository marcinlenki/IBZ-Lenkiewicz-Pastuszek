import React from 'react';
import {ArticleResponse} from "../../../middleware/model";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {LoadingButton} from "@mui/lab";
import {Stack} from "@mui/material";

type Props = {
    articles: ArticleResponse[]
    onClick: (article: ArticleResponse) => void,
    listTitle: string,
    actionName: string
}

const ArticleList = ({articles, onClick, listTitle, actionName}: Props) => {
    return (
        <>
            {articles.length !== 0 && (
                <Stack mb={5} gap={2}>
                    <Typography variant='h4' marginBottom={'10px'}>{listTitle}</Typography>
                    {articles.map((article) =>
                        <Box
                            key={article.id}
                            padding={'10px'}
                            border={'1px solid #000'}
                            borderRadius={'10px'}
                            bgcolor={'#F0F0F0'}
                        >
                            <Typography variant='h5' marginBottom={'10px'}>
                                {article.title}
                            </Typography>
                            <Typography variant='body2'>
                                {article.introduction}
                            </Typography>
                            <Box
                                display={'flex'}
                                justifyContent={'flex-end'}
                            >
                                <LoadingButton
                                    variant='contained'
                                    sx={{
                                        color: 'white',
                                        textTransform: 'none',
                                        fontWeight: '700'
                                    }}
                                    onClick={() => onClick(article)}
                                >
                                    {actionName}
                                </LoadingButton>
                            </Box>
                        </Box>
                    )
                    }
                </Stack>
            )}
        </>
    );
};

export default ArticleList;