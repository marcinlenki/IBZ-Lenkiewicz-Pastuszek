import React from 'react';
import {ThemeProvider} from "@mui/material";
import {protectedTheme} from "../../themes";
import {Navigate, Outlet, useNavigate} from "react-router-dom";
import {isEmployee} from "../../middleware/auth";

// Root container for all employee pages
const Protected = () => {
    if (!isEmployee()) {
        return <Navigate to="/" replace />;
    }

    return (
        <ThemeProvider theme={protectedTheme}>
            <Outlet/>
        </ThemeProvider>
    );
};

export default Protected;