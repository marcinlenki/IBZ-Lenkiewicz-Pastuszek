import {Box, Button, Grid, Input, Stack, TextField, Tooltip, Typography} from '@mui/material';
import CancelIcon from '@mui/icons-material/Cancel';
import IconButton from "@mui/material/IconButton";
import {Field, FieldArray, useField} from 'formik';
import {ChapterChangeRequest, ChapterResourceChangeRequest} from "../../../../middleware/model";
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import React, {useState} from "react";
import AddCircleIcon from '@mui/icons-material/AddCircle';


type Props = {
    chapter: ChapterChangeRequest
    index: number
    onDelete: () => void
    onAttachmentChange: (files: File[]) => void
}

export const ChapterBlock = (props: Props) => {
    const [files, setFiles] = useState<File[]>([])

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, chapterResource: ChapterResourceChangeRequest, index: number) => {
        if (e.target.files) {
            const file = e.target.files[0];
            const newFiles = [...files]
            newFiles[index] = file
            setFiles([...newFiles]);
            props.onAttachmentChange(newFiles.filter(file => file !== undefined))
            chapterResource.attachment = file.name
            chapterResource.content.contentType = file.type
        }
    };

    return (
        <Grid
            key={props.index}
            container item
            direction={'column'}
            width={'100%'}
            padding={'4px 10px 4px 10px'}
            gap={'16px'}
        >
            <Box
                display={'flex'}
                flexDirection={'row'}
                justifyContent={'space-between'}
                alignItems={'center'}
                flexGrow={1}
            >
                <Typography sx={{
                    fontSize: '18px',
                    fontStyle: 'bold',
                    fontWeight: '700'
                }}>
                    Rozdział {props.index + 1}
                </Typography>
                <IconButton onClick={props.onDelete}>
                    <CancelIcon style={{color: 'red'}}/>
                </IconButton>
            </Box>

            <Field
                name={`chapters[${props.index}].title`}
                as={SubtitleTextField}
            />
            <Field
                name={`chapters[${props.index}].text`}
                as={TextTextField}
            />

            <Typography sx={{
                fontSize: '14px',
                fontStyle: 'bold',
                fontWeight: '700'
            }}>
                Zasoby
            </Typography>
            <FieldArray
                name={`chapters[${props.index}].chapterResources`}
                render={(arrayHelpers) => (
                    <Box
                        display={'flex'}
                        flexDirection={'column'}
                        sx={{border: '1px solid'}}
                        marginTop={'20px'}
                        width={'100%'}
                    >
                        <Stack direction={"row"} justifyContent={"flex-end"}>
                            <Tooltip title="Dodaj nowy zasób">
                                <IconButton onClick={() => arrayHelpers.push({
                                    description: '',
                                    attachment: '',
                                    content: {type: 'image', resizeModifier: 1}
                                })}>
                                    <AddCircleIcon/>
                                </IconButton>
                            </Tooltip>
                        </Stack>

                        {props.chapter.chapterResources.map((resource, index) =>
                            <Stack
                                padding={3}
                                gap={1}
                                m={3}
                                key={index}
                                border={'1px solid'}
                                position={"relative"}
                            >
                                <Box alignSelf={"flex-end"} position={"absolute"} right={"0"} top={"0"}>
                                    <IconButton onClick={() => {
                                        arrayHelpers.remove(index)
                                        setFiles(files.filter((_, i) => i !== index))
                                        props.onAttachmentChange(files)
                                    }}>
                                        <CancelIcon style={{color: 'red'}}/>
                                    </IconButton>
                                </Box>

                                <Field
                                    name={`chapters[${props.index}].chapterResources[${index}].description`}
                                    as={ResourceDescriptionTextField}
                                />

                                {resource.content.url ? (
                                    <img src={resource.content.url} alt={resource.description} width={"100%"}
                                         height={"auto"}/>
                                ) : (
                                    <>
                                        {files[index] ? (
                                            <Typography>Załączono plik = {files[index].name}</Typography>
                                        ) : (
                                            <Button component="label" variant="contained"
                                                    startIcon={<CloudUploadIcon/>}>
                                                Załącz
                                                <Box display={"none"}>
                                                    <Input
                                                        type="file"
                                                        inputProps={{accept: 'image/png, image/jpeg'}}
                                                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleFileChange(e, resource, index)}
                                                    />
                                                </Box>
                                            </Button>
                                        )}
                                    </>
                                )}
                            </Stack>
                        )}
                    </Box>
                )}
            />
        </Grid>
    )
}

const SubtitleTextField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <TextField
            error={meta.error}
            {...props}
            size="small"
            label={meta.error ?? `Tytuł`}
            sx={{background: 'white', '.MuiInputBase-input': {fontSize: '14px'}}}
            fullWidth
        />
    )
}

const TextTextField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <TextField
            error={meta.error}
            {...props}
            fullWidth
            multiline
            sx={{backgroundColor: 'white'}}
            label={`Tekst`}
        />
    )
}

const ResourceDescriptionTextField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <TextField
            error={meta.error}
            {...props}
            multiline
            fullWidth
            sx={{backgroundColor: 'white'}}
            label={`Opis`}
        />
    )
}
