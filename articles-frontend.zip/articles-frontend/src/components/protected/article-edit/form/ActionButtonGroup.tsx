import React, {useState} from 'react';
import {Stack} from "@mui/material";
import {LoadingButton} from "@mui/lab";
import {getUser} from "../../../../middleware/storage";
import {Role} from "../../../../middleware/auth";
import {useCreateArticle, useSaveArticle} from "../../../../hooks/articleHooks";
import {Statuses} from "../../../../pages/protected/ArticleListPage";
import {ArticleChangeRequest, ArticleResponse} from "../../../../middleware/model";
import ConfirmDeleteDialog from "./ConfirmDeleteDialog";

type Props = {
    articleChangeRequest: ArticleChangeRequest,
    articleAttachments: File[],
    article?: ArticleResponse,
    isWaitingForReview: boolean
}

const ActionButtonGroup = ({articleChangeRequest, articleAttachments, article, isWaitingForReview}: Props) => {
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

    const createArticleAction = useCreateArticle()
    const saveArticleAction = useSaveArticle()

    function isInReview(): boolean {
        return article?.status.id === Statuses.IN_REVIEW
    }

    function shouldDisplayDeleteButton() {
        return article && !(getUser()?.role === Role.AUTHOR && isInReview())
    }

    function handlePreviewAction(saveRequest: ArticleChangeRequest) {
        // TODO: Handle preview action
        console.log(saveRequest)
        console.log(articleAttachments)
    }

    function handleSaveAction(saveRequest: ArticleChangeRequest) {
        if (article) {
            saveArticleAction.mutate({article: saveRequest, files: articleAttachments})
        } else {
            createArticleAction.mutate({article: saveRequest, files: articleAttachments})
        }
    }

    return (
        <Stack direction={"row"} gap={2} mb={3}>
            <LoadingButton
                loading={saveArticleAction.isLoading}
                variant='contained'
                sx={{
                    color: 'white',
                    textTransform: 'none',
                    fontWeight: '700'
                }}
                onClick={() => handlePreviewAction(articleChangeRequest)}
            >
                Podgląd
            </LoadingButton>

            <LoadingButton
                loading={article ? saveArticleAction.isLoading : createArticleAction.isLoading}
                variant='contained'
                sx={{
                    color: 'white',
                    textTransform: 'none',
                    fontWeight: '700'
                }}
                onClick={() => handleSaveAction(articleChangeRequest)}
            >
                Zapisz
            </LoadingButton>

            {(article && !isWaitingForReview) && (
                <LoadingButton
                    variant='contained'
                    type='submit'
                    sx={{
                        color: 'white',
                        textTransform: 'none',
                        fontWeight: '700'
                    }}
                >
                    {getUser()?.role === Role.EDITOR ? 'Opublikuj' : 'Zgłoś do redakcji'}
                </LoadingButton>
            )}

            {
                shouldDisplayDeleteButton() && (
                    <>
                        <LoadingButton
                            variant='contained'
                            sx={{
                                color: 'white',
                                textTransform: 'none',
                                fontWeight: '700',
                                backgroundColor: 'red',
                                ':hover': {
                                    backgroundColor: 'darkred'
                                }
                            }}
                            onClick={() => setDeleteDialogOpen(true)}
                        >
                            Usuń
                        </LoadingButton>
                        <ConfirmDeleteDialog
                            onClose={() => setDeleteDialogOpen(false)}
                            open={deleteDialogOpen}
                            articleId={article!.id}
                            articleTitle={article!.title}
                        />
                    </>
                )}
        </Stack>
    );
};


export default ActionButtonGroup;