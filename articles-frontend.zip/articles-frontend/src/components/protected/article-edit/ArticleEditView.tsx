import React, {useState} from 'react';
import {ArticleChangeRequest, ArticleResponse, CategoryDto, SubcategoryDto} from "../../../middleware/model";
import {Field, FieldArray, Form, Formik, useField} from "formik";
import {Autocomplete, Box, Button, Chip, Divider, Stack, TextField, Typography} from "@mui/material";
import {empty, fromArticleResponse} from "../../../utils/mapping";
import {ChapterBlock} from "./form/ChapterBlock";
import {useForwardArticle} from "../../../hooks/articleHooks";
import {getUser} from "../../../middleware/storage";
import {Role} from "../../../middleware/auth";
import {Statuses} from "../../../pages/protected/ArticleListPage";
import ActionButtonGroup from "./form/ActionButtonGroup";


type Props = {
    article?: ArticleResponse
    categories: CategoryDto[]
    tags: string[]
}

const ArticleEditView = ({article, categories, tags}: Props) => {
    const forwardArticleAction = useForwardArticle()

    const [selectedCategory, setSelectedCategory] = useState<CategoryDto>(
        article ? categories.find(c => c.id === article?.category.id)! : categories[0])

    const [selectedSubcategory, setSelectedSubcategory] = useState<SubcategoryDto>(
        selectedCategory.subcategories.find(s => s.id === article?.category.subcategory.id) ?? selectedCategory.subcategories[0]
    )

    const [thumbnail, setThumbnail] = useState<File | undefined>(undefined)
    const [articleAttachments, setArticleAttachments] = useState<File[][]>([])

    function handleOnAttachmentChange(chapterAttachments: File[], index: number) {
        const newFiles = [...articleAttachments]
        newFiles[index] = chapterAttachments
        setArticleAttachments([...newFiles])
    }

    function getAction(): string {
        return getUser()!.role === Role.AUTHOR ? "submit" : "publish"
    }

    function getUploadFiles() {
        return thumbnail ? [...articleAttachments.flat(), thumbnail] : articleAttachments.flat()
    }


    return (
        <Box width={"100%"} height={"100%"}>
            <Formik<ArticleChangeRequest>
                initialValues={article ? fromArticleResponse(article) : empty(categories)}
                onSubmit={data => {
                    forwardArticleAction.mutate({action: getAction(), article: data, files: getUploadFiles()})
                }}
                validateOnChange={false}
                validateOnBlur={false}
                // enableReinitialize={true}
            >
                {(formData) => (
                    <Form>
                        <Stack direction={"row"} width={"100%"} gap={4}
                               divider={<Divider orientation="vertical" flexItem/>}>
                            <Stack flexGrow={5} alignItems={"center"}>
                                <Stack gap={2} width={"700px"} height={"100%"} padding={3}>
                                    <Field name='introduction' as={LongTextField}/>

                                    <FieldArray
                                        name='chapters'
                                        render={(arrayHelpers) => (
                                            <Box
                                                display={'flex'}
                                                flexDirection={'column'}
                                                sx={{backgroundColor: 'lightgray', border: '1px solid'}}
                                                marginTop={'20px'}
                                                width={'100%'}
                                                height={'542px'}
                                                overflow={'auto'}
                                                gap={'24px'}
                                            >
                                                {formData.values.chapters.map((chapter, index) =>
                                                    <div key={index}>
                                                        <ChapterBlock
                                                            chapter={chapter}
                                                            index={index}
                                                            onDelete={() => {
                                                                arrayHelpers.remove(index)
                                                                handleOnAttachmentChange([], index)
                                                            }}
                                                            onAttachmentChange={files => handleOnAttachmentChange(files, index)}
                                                        />
                                                        <Divider/>
                                                    </div>
                                                )}
                                                <Button
                                                    variant='contained'
                                                    sx={{
                                                        alignSelf: 'center',
                                                        width: '200px',
                                                        margin: '16px',
                                                        color: 'white',
                                                        textTransform: 'none',
                                                        fontWeight: '700'
                                                    }}
                                                    onClick={() => arrayHelpers.push({
                                                        title: '',
                                                        text: '',
                                                        chapterResources: []
                                                    })}
                                                >
                                                    Dodaj rozdział
                                                </Button>
                                            </Box>
                                        )}
                                    />
                                </Stack>
                            </Stack>

                            <Stack gap={3} flexGrow={1} paddingX={3}>
                                <ActionButtonGroup
                                    articleChangeRequest={formData.values}
                                    articleAttachments={getUploadFiles()}
                                    article={article}
                                    isWaitingForReview={article?.status.id === Statuses.WAITING_FOR_REVIEW}
                                />

                                <Field name='title' as={TitleTextField}/>

                                <Field as={CategoryAutocompleteField}
                                       name='category'
                                       size="small"
                                       fullWidth
                                       disableClearable
                                       onChange={(_: any, category: CategoryDto) => {
                                           setSelectedCategory(category)
                                           setSelectedSubcategory(category.subcategories[0])
                                           formData.values.category.categoryId = category.id
                                       }}
                                       getOptionLabel={(option: CategoryDto | undefined) => option?.name ?? ''}
                                       options={categories}
                                       value={selectedCategory}
                                />

                                <Field as={SubcategoryAutocompleteField}
                                       name="subcategory"
                                       size="small"
                                       fullWidth
                                       freeSolo
                                       disableClearable
                                       onChange={(_: any, subcategory: SubcategoryDto) => {
                                           setSelectedSubcategory(subcategory)
                                           formData.values.category.subcategoryId = subcategory.id
                                       }}
                                       getOptionLabel={(option: SubcategoryDto | undefined) => option?.name ?? ''}
                                       options={selectedCategory.subcategories}
                                       value={selectedSubcategory}
                                />

                                <Autocomplete
                                    multiple
                                    fullWidth
                                    id="tags-filled"
                                    options={tags}
                                    defaultValue={article?.tags}
                                    onChange={(_: any, tags: string[]) => formData.values.tags = tags}
                                    freeSolo
                                    renderTags={(value: readonly string[], getTagProps) =>
                                        value.map((option: string, index: number) => (
                                            <Chip variant="outlined" label={option} {...getTagProps({index})} />
                                        ))
                                    }
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Tagi"
                                            placeholder="Tagi"
                                        />
                                    )}
                                />

                                <Stack border={"1px lightgray"} gap={1}>
                                    <Typography mb={1}>Miniatura</Typography>
                                    {article?.thumbnailUrl && (
                                        <img src={article?.thumbnailUrl} alt={"Miniatura"} width={"400px"}
                                             height={"auto"}/>
                                    )}
                                    <input
                                        type={"file"}
                                        accept="image/png, image/jpeg"
                                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                            if (e.target.files) {
                                                const file = e.target.files[0]
                                                if (file) {
                                                    setThumbnail(file)
                                                    formData.values.thumbnailUrl = file.name
                                                }
                                            }
                                        }}
                                    />
                                </Stack>
                            </Stack>
                        </Stack>
                    </Form>
                )}
            </Formik>
        </Box>
    );

};

export default ArticleEditView;

const CategoryAutocompleteField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <Autocomplete
            {...props}
            isOptionEqualToValue={(option: CategoryDto, value: CategoryDto) => option.id === value.id}
            renderInput={(params: any) =>
                <TextField {...params} name='category' label={meta.error ?? 'Kategoria'} error={meta.error}/>
            }
        />
    )
}

const SubcategoryAutocompleteField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <Autocomplete
            {...props}
            // isOptionEqualToValue={(option: SubcategoryDto, value: SubcategoryDto) => option.id === value.id}
            renderInput={(params: any) =>
                <TextField {...params} name='subcategory' label={meta.error ?? 'Podkategoria'} error={meta.error}/>
            }
        />
    )
}


const LongTextField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <TextField
            error={meta.error}
            {...props}
            multiline
            fullWidth
            minRows={4}
            label={meta.error ?? 'Wstęp'}
        />
    )
}

const TitleTextField = (props: any) => {
    const [input, meta, helpers] = useField(props)

    return (
        <TextField
            error={meta.error}
            {...props}
            size="small"
            label={meta.error ?? 'Tytuł'}
            fullWidth
        />
    )
}
