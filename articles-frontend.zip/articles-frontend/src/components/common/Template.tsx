import React, {createContext, useContext, useState} from 'react';
import Footer from "./Footer";
import {Outlet} from "react-router-dom";
import {styled} from "@mui/material/styles";
import LeftDrawer from "./drawer/LeftDrawer";
import ArticlesNavbar from "./navbar/ArticlesNavbar";
import Box from "@mui/material/Box";
import {isEmployee} from "../../middleware/auth";


const Main = styled('main', {shouldForwardProp: (prop) => prop !== 'open'})<{
    open?: boolean;
}>(({theme, open}) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
        marginLeft: 0,
    }),
}));

const Template = () => {
    const [open, setOpen] = React.useState(false);
    const [isEmp, setIsEmp] = useState<boolean>(isEmployee())

    const handleDrawerOpen = () => {
        setOpen(true);
    };

    const handleDrawerClose = () => {
        setOpen(false);
    };

    return (
        <Box
            display={'flex'}
            flexDirection={'column'}
            width={'100%'}
            height={'100vh'}
        >
            <ArticlesNavbar open={open} handleDrawerOpen={handleDrawerOpen} isEmp={isEmp} setIsEmp={setIsEmp}/>
            <LeftDrawer open={open} handleDrawerOpen={handleDrawerOpen} handleDrawerClose={handleDrawerClose}/>
            <Main open={open}>
                <Outlet/>
            </Main>
            <Footer/>
        </Box>
    );
};


export default Template;