import React from 'react';
import {CssBaseline} from "@mui/material";
import Box from "@mui/material/Box";
import {Outlet} from "react-router-dom";

const Layout = () => {
    return (
        <>
            <CssBaseline/>
            <Box
                width={'100%'}
                height={'100vh'}
                sx={{display: 'flex'}}
            >
                <Outlet/>
            </Box>
        </>
    );
};

export default Layout;