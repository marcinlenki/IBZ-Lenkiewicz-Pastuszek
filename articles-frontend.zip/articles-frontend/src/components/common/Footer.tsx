import React from 'react';
import Box from "@mui/material/Box";

const Footer = () => {
    return (
        <Box>
        </Box>
    );
};

export default Footer;