import React, {useState} from "react";
import {Autocomplete, Chip, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle} from "@mui/material";
import TextField from "@mui/material/TextField";
import {useGetTags} from "../../hooks/articleHooks";
import {getContent} from "../../utils/modelUtils";
import {LoadingButton} from "@mui/lab";
import {useNavigate} from "react-router-dom";

type Props = {
    open: boolean;
    onClose: () => void;
}

const SearchDialog = ({open, onClose}: Props) => {
    const [selectedTags, setSelectedTags] = useState<string[]>([]);
    const tags = useGetTags();
    const navigate = useNavigate();

    if (tags.isLoading) {
        return null;
    }

    return (
        <>
            <Dialog open={open} onClose={onClose} fullWidth>
                <DialogTitle>Wyszukaj artykuły</DialogTitle>
                <DialogContent dividers sx={{}}>
                    <DialogContentText mb={2}>
                        Aby wyszukać artykuły, wybierz interesujące tagi.
                    </DialogContentText>
                    <Autocomplete
                        id="search-tags"
                        loading={tags.isLoading}
                        multiple
                        fullWidth
                        options={getContent(tags).map(tag => tag.name)}
                        defaultValue={[]}
                        onChange={(_: any, tags: string[]) => setSelectedTags(tags)}
                        renderTags={(value: string[], getTagProps) =>
                            value.map((option: string, index: number) => (
                                <Chip variant="outlined" label={option} {...getTagProps({index})} />
                            ))
                        }
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Tagi"
                                placeholder="Tagi"
                            />
                        )}
                    />
                </DialogContent>
                <DialogActions>
                    <LoadingButton
                        loading={tags.isLoading}
                        fullWidth
                        variant='contained'
                        sx={{
                            color: 'white',
                            textTransform: 'none',
                            fontWeight: '700'
                        }}
                        onClick={() => {
                            navigate(`/?tags=${selectedTags.join(',')}`)
                            onClose()
                        }}
                    >
                        Wyszukaj
                    </LoadingButton>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default SearchDialog;