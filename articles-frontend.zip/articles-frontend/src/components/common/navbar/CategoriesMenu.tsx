import React from 'react';
import {Stack} from "@mui/material";
import {useGetCategories} from "../../../hooks/articleHooks";
import CategoryItem from "./CategoryItem";
import LoadingPage from "../LoadingPage";
import {getContent} from "../../../utils/modelUtils";
import {useNavigate} from "react-router-dom";


export const CategoriesMenu = () => {
    const navigate = useNavigate();
    const categories = useGetCategories();


    if (categories.isLoading) {
        return <LoadingPage/>
    }

    if (categories.error) {
        navigate('/')
    }

    return (
        <Stack alignSelf={"center"} direction={"row"} justifyContent={"space-around"} width={"50%"}>
            {getContent(categories).map(category => (
                <CategoryItem categoryDto={category} key={category.id}/>)
            )}
        </Stack>
    );
};
