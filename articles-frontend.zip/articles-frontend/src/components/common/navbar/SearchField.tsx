import React, {useState} from "react";
import {styled} from "@mui/material/styles";
import {alpha,} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import SearchDialog from "../SearchDialog";

const SearchField = () => {
    const [isSearchOpen, setIsSearchOpen] = useState(false);


    function handleSearchClick() {
        setIsSearchOpen(!isSearchOpen);
    }

    return (
        <>
            <Search onClick={handleSearchClick}>
                <SearchIconWrapper>
                    <SearchIcon/>
                </SearchIconWrapper>
            </Search>
            <SearchDialog open={isSearchOpen} onClose={handleSearchClick}/>
        </>
    );
};

export default SearchField;

const Search = styled('div')(({theme}) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    '&:hover': {
        backgroundColor: alpha(theme.palette.common.white, 0.10),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '40px', // Set a static width
    display: 'flex',
    alignItems: 'center',
    [theme.breakpoints.up('sm')]: {
        marginLeft: theme.spacing(3),
        width: 'auto',
    },
}));

const SearchIconWrapper = styled('div')(({theme}) => ({
    padding: theme.spacing(0, 1),
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer'
}));
