import React from 'react';
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import PersonPinIcon from "@mui/icons-material/PersonPin";
import {Avatar, Divider, ListItemIcon, Menu, MenuItem, Stack, Typography} from "@mui/material";
import {Navigate, useNavigate} from "react-router-dom";
import {isAuthenticated} from "../../../middleware/auth";
import {getUser, removeUser} from "../../../middleware/storage";
import {Logout, Settings} from "@mui/icons-material";
import toast from "react-hot-toast";

type Props = {
    setIsEmp: React.Dispatch<React.SetStateAction<boolean>>;
}

const AccountIcon = ({ setIsEmp }: Props) => {
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const isMenuOpen = Boolean(anchorEl);
    const navigate = useNavigate()

    const handleProfileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleLoginItemClick = () => {
        setAnchorEl(null);
        navigate("/login", {replace: true})
    };

    const handleLogoutItemClick = () => {
        setAnchorEl(null);
        removeUser()
        setIsEmp(false)
        navigate('/', {replace: true})
        toast.success("Wylogowano pomyślnie")
    }

    const renderMenu = (
        <Menu
            anchorEl={anchorEl}
            id={"primary-search-account-menu"}
            keepMounted
            anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
            }}
            transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
            }}
            open={isMenuOpen}
            onClose={handleMenuClose}
        >
            {isAuthenticated() ? (
                <Stack>
                    <Stack direction={"row"} padding={1} alignItems={"center"} gap={2} paddingX={2}>
                        <Avatar sx={{width: 25, height: 25}}> {getUser()?.email.charAt(0).toUpperCase()} </Avatar>
                        <Typography> {getUser()?.email} </Typography>
                    </Stack>
                    <Divider sx={{mb: 2}}/>
                    <MenuItem>
                        <ListItemIcon>
                            <Settings fontSize="small"/>
                        </ListItemIcon>
                        Ustawienia
                    </MenuItem>

                    <MenuItem onClick={handleLogoutItemClick}>
                        <ListItemIcon>
                            <Logout fontSize="small"/>
                        </ListItemIcon>
                        Wyloguj
                    </MenuItem>
                </Stack>

            ) : (
                <MenuItem sx={{paddingX: 3}} onClick={handleLoginItemClick}>Zaloguj</MenuItem>
            )}
        </Menu>
    );

    return (
        <Box sx={{display: 'flex'}}>
            <IconButton
                size="large"
                edge="end"
                aria-label="account of current user"
                aria-controls="primary-search-account-menu"
                aria-haspopup="true"
                onClick={handleProfileMenuOpen}
                color="inherit"
            >
                <PersonPinIcon/>
            </IconButton>
            {renderMenu}
        </Box>
    );
};

export default AccountIcon;
