import React from 'react';
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import {Stack} from "@mui/material";
import Box from "@mui/material/Box";
import AccountIcon from "./AccountIcon";
import SearchField from "./SearchField";

type Props = {
    open: boolean;
    handleDrawerOpen: () => void;
    isEmp: boolean;
    setIsEmp: React.Dispatch<React.SetStateAction<boolean>>;
}

const NavbarTopRow = ({open, handleDrawerOpen, isEmp, setIsEmp}: Props) => {
    return (
        <Stack direction={"row"} sx={{ml: 2, mr: 2}}>
            <IconButton
                color="inherit"
                aria-label="open drawer"
                onClick={handleDrawerOpen}
                edge="start"
                sx={{mr: 2, ...(open && {display: 'none'})}}
            >
                <MenuIcon/>
            </IconButton>
            <SearchField/>
            <Box sx={{flexGrow: 1}}/>
            <AccountIcon setIsEmp={setIsEmp} />
        </Stack>
    );
};

export default NavbarTopRow;