import * as React from 'react';

import {AppBar, Divider, Stack} from "@mui/material";
import NavbarTopRow from "./NavbarTopRow";
import {Logo} from "./Logo";
import {CategoriesMenu} from "./CategoriesMenu";
import {isEmployee} from "../../../middleware/auth";
import {useContext} from "react";

type Props = {
    open: boolean;
    handleDrawerOpen: () => void;
    isEmp: boolean;
    setIsEmp: React.Dispatch<React.SetStateAction<boolean>>;
}

export default function ArticlesNavbar({open, handleDrawerOpen, isEmp, setIsEmp}: Props) {
    return (
        <AppBar position="static">
            <Stack>
                <NavbarTopRow open={open} handleDrawerOpen={handleDrawerOpen} isEmp={isEmp} setIsEmp={setIsEmp}/>
                <Logo/>
                <Divider/>
                {!isEmp && (
                    <CategoriesMenu/>
                )}
            </Stack>
        </AppBar>
    );
}
