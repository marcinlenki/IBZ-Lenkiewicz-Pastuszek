import React, {useState} from 'react';
import {CategoryDto} from "../../../middleware/model";
import {Link, Menu, MenuItem, Stack} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {capitalize} from "../../../utils/stringUtils";
import Box from "@mui/material/Box";
import {useNavigate} from "react-router-dom";
import {styled} from "@mui/material/styles";

const CustomLink = styled(Link)(({theme}) => ({
    '&:hover': {
        cursor: 'pointer'
    },
}));

type Props = {
    categoryDto: CategoryDto
}

const CategoryItem = ({categoryDto}: Props) => {
    const [showMore, setShowMore] = useState(false)
    const navigate = useNavigate();

    function handleMouseEnter() {
        setShowMore(true)
    }

    function handleMouseLeave() {
        setShowMore(false)
    }

    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);

    const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <Box onMouseLeave={handleClose}>
            <Stack
                direction={"row"}
                alignItems={"center"}
                sx={{padding: 2}}
            >
                <CustomLink zIndex={1} flex={2} underline={"hover"} sx={{color: "white"}} onClick={() => {
                    navigate(`/?category_id=${categoryDto.id}`)
                }}>
                    {capitalize(categoryDto.name)}
                </CustomLink>

                <Stack height={"100%"} onMouseEnter={handleClick}>
                    <ExpandMoreIcon/>
                </Stack>
            </Stack>

            <Menu
                id="subcategories-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                MenuListProps={{
                    'aria-labelledby': 'basic-button',
                }}
            >
                {categoryDto.subcategories.map(subcategory => (
                    <MenuItem
                        key={subcategory.id}
                        sx={{justifyContent: "flex-start", paddingX: 3, paddingY: 1}}
                        onClick={() => {
                            navigate(`/?subcategory_id=${subcategory.id}`)
                            handleClose()
                        }}
                    >
                        {capitalize(subcategory.name)}
                    </MenuItem>
                ))}
            </Menu>
        </Box>
    );
};

export default CategoryItem;