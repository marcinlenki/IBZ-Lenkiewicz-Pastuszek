import React from 'react';
import Box from "@mui/material/Box";
import {Typography} from "@mui/material";
import {isEmployee} from "../../../middleware/auth";
import {useNavigate} from "react-router-dom";
import {styled} from "@mui/material/styles";

const CustomLogo = styled(Typography)(({theme}) => ({
    '&:hover': {
        cursor: 'pointer'
    },
}));

export const Logo = () => {
    const navigate = useNavigate();

    function handleOnClick() {
        if (isEmployee()) {
            navigate('/dashboard');
        } else {
            navigate('/');
        }
    }

    return (
        <Box textAlign={"center"}>
            <CustomLogo
                variant="h3"
                noWrap sx={{marginBottom: 2}}
                onClick={handleOnClick}
                aria-label="Trybuna Ludu"
            >
                Trybuna Ludu
            </CustomLogo>

            {isEmployee() && (
                <Typography variant="h6" noWrap sx={{marginBottom: 2}}>
                    Portal pracowniczy
                </Typography>
            )}
        </Box>
    );
};
