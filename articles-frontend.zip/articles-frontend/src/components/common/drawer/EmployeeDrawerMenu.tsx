import React from 'react';
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import ListItemText from "@mui/material/ListItemText";
import {useNavigate} from "react-router-dom";

type MenuItems = {
    title: string,
    icon: React.FC,
    onClick: () => void
}

type Props = {
    handleDrawerClose: () => void;
}

const EmployeeDrawerMenu = ({handleDrawerClose}: Props) => {
    const navigate = useNavigate()

    const menuOptions: MenuItems[] = [
        {
            title: "Artykuły",
            icon: AutoStoriesIcon,
            onClick: () => navigate('/dashboard/articles')
        }
    ]

    return (
        <List>
            {menuOptions.map((item) => (
                <ListItem key={item.title} disablePadding>
                    <ListItemButton onClick={() => {
                        item.onClick()
                        handleDrawerClose()
                    }}>
                        <ListItemIcon>
                            <item.icon/>
                        </ListItemIcon>
                        <ListItemText primary={item.title}/>
                    </ListItemButton>
                </ListItem>
            ))}
        </List>
    );
};

export default EmployeeDrawerMenu;