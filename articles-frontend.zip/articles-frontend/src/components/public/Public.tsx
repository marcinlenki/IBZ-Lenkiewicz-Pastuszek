import React from 'react';
import {ThemeProvider} from "@mui/material";
import {publicTheme} from "../../themes";
import {Outlet} from "react-router-dom";

// Root container for all public pages (except login)
const Public = () => {
    return (
        <ThemeProvider theme={publicTheme}>
            <Outlet/>
        </ThemeProvider>
    );
};

export default Public;