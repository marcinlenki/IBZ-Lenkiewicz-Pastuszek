import React from 'react';
import {AuthorDto} from "../../middleware/model";
import {Card, CardActionArea, CardContent, CardMedia, Stack} from "@mui/material";
import Typography from "@mui/material/Typography";
import {useNavigate} from "react-router-dom";

type Props = {
    articleId: number,
    articleTitle: string,
    thumbnailUrl: string,
    author: AuthorDto,
    createdAt: Date,
    introduction: string
}

const ArticleThumbnail = ({articleId, articleTitle, thumbnailUrl, author, createdAt, introduction}: Props) => {
    const navigate = useNavigate()

    return (
        <Card sx={{maxWidth: 345, width: '345px'}}>
            <CardActionArea onClick={() => {
                navigate(`/read/${articleId}`)
            }}>
                <CardMedia
                    sx={{height: "200px"}}
                    image={thumbnailUrl}
                    title={articleTitle}
                />
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                        {articleTitle}
                    </Typography>
                    <Typography sx={{height: "100px"}} gutterBottom variant="body2" color="text.secondary" mb={3}>
                        {introduction}
                    </Typography>
                    <Stack direction={"row"} gap={2}>
                        <Typography><i>{author.name}</i></Typography>
                        <Typography>{createdAt.toString()}</Typography>
                    </Stack>
                </CardContent>
            </CardActionArea>
        </Card>
    );
};

export default ArticleThumbnail;